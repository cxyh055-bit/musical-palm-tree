import { Capacitor } from '@capacitor/core';
import { Haptics, ImpactStyle } from '@capacitor/haptics';

export function haptic(kind: 'light' | 'medium' = 'light') {
  try {
    if (Capacitor.isNativePlatform()) {
      void Haptics.impact({ style: kind === 'medium' ? ImpactStyle.Medium : ImpactStyle.Light }).catch(() => undefined);
    } else if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      navigator.vibrate(kind === 'medium' ? 18 : 10);
    }
  } catch {
    /* haptics are best-effort */
  }
}

/** Light vibration on every tap of a button, link or tab. */
export function initGlobalHaptics() {
  document.addEventListener(
    'click',
    (e) => {
      const el = (e.target as HTMLElement | null)?.closest?.('button, a[href], [role="button"], [role="tab"], summary');
      if (!el) return;
      if ((el as HTMLButtonElement).disabled || el.getAttribute('aria-disabled') === 'true') return;
      haptic('light');
    },
    true
  );
}
