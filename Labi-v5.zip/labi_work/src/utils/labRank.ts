import type { DentalLab } from '../types';
import { calculateDistanceKm } from './geo';
import type { LabRatingSummary } from './ratings';
import type { LabService } from './services';

export type SortKey = 'nearest' | 'cheapest' | 'fastest' | 'rated';

export const SORT_LABELS: Record<SortKey, string> = {
  nearest: 'الأقرب',
  cheapest: 'الأرخص',
  fastest: 'الأسرع',
  rated: 'الأعلى تقييماً',
};

export interface LabRow {
  lab: DentalLab;
  distanceKm: number | null;
  minPrice: number | null;
  days: number;
  rating: number | null;
  ratingCount: number;
  services: LabService[];
  thumb: string;
}

export function buildRows(
  labs: DentalLab[],
  lat: number | undefined,
  lng: number | undefined,
  ratings: Record<string, LabRatingSummary>,
  services: Record<string, LabService[]>
): LabRow[] {
  return labs.map((lab) => {
    const list = services[lab.id] ?? [];
    const prices = list.map((s) => s.priceEgp).filter((p) => p > 0);
    const fallback = lab.priceList?.zirconiaCrown;
    const minPrice = prices.length ? Math.min(...prices) : fallback && fallback > 0 ? fallback : null;
    const r = ratings[lab.id];
    return {
      lab,
      distanceKm: calculateDistanceKm(lat, lng, lab.latitude, lab.longitude),
      minPrice,
      days: lab.turnaroundDays,
      rating: r ? r.avg : null,
      ratingCount: r ? r.count : 0,
      services: list,
      thumb: list.find((s) => s.photoDataUrl)?.photoDataUrl ?? '',
    };
  });
}

function cmpNullLast(a: number | null, b: number | null, dir: 1 | -1 = 1) {
  if (a === null && b === null) return 0;
  if (a === null) return 1;
  if (b === null) return -1;
  return (a - b) * dir;
}

export function sortRows(rows: LabRow[], key: SortKey): LabRow[] {
  const copy = [...rows];
  copy.sort((a, b) => {
    switch (key) {
      case 'cheapest':
        return cmpNullLast(a.minPrice, b.minPrice) || a.lab.name.localeCompare(b.lab.name);
      case 'fastest':
        return a.days - b.days || cmpNullLast(a.distanceKm, b.distanceKm);
      case 'rated':
        return cmpNullLast(a.rating, b.rating, -1) || b.ratingCount - a.ratingCount;
      default:
        return cmpNullLast(a.distanceKm, b.distanceKm) || a.lab.name.localeCompare(b.lab.name);
    }
  });
  return copy;
}

export const fmtPrice = (n: number) => `${Math.round(n).toLocaleString('en-US')} ج`;
export const fmtKm = (km: number) => `${km < 10 ? km.toFixed(1) : Math.round(km)} كم`;
