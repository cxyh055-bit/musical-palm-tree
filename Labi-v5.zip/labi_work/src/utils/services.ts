import { collection, getDocs, query, where } from 'firebase/firestore';
import { db } from '../firebase';

export interface LabService {
  id: string;
  labId: string;
  ownerUid: string;
  name: string;
  category: string;
  priceEgp: number;
  days: number;
  description: string;
  photoDataUrl: string;
  createdAt: unknown;
  createdMs: number;
}

export const SERVICE_CATEGORIES = ['زيركون', 'إيماكس', 'بورسلين', 'زراعة', 'تقويم', 'أطقم', 'أخرى'];

function toService(id: string, d: Record<string, unknown>): LabService {
  const created = d.createdAt as { toMillis?: () => number } | undefined;
  return {
    id,
    labId: String(d.labId ?? ''),
    ownerUid: String(d.ownerUid ?? ''),
    name: String(d.name ?? ''),
    category: String(d.category ?? ''),
    priceEgp: Number(d.priceEgp ?? 0),
    days: Number(d.days ?? 0),
    description: String(d.description ?? ''),
    photoDataUrl: String(d.photoDataUrl ?? ''),
    createdAt: d.createdAt,
    createdMs: created?.toMillis?.() ?? 0,
  };
}

export async function fetchAllServices(): Promise<Record<string, LabService[]>> {
  const snap = await getDocs(collection(db, 'labServices'));
  const out: Record<string, LabService[]> = {};
  snap.forEach((d) => {
    const s = toService(d.id, d.data());
    (out[s.labId] ??= []).push(s);
  });
  for (const list of Object.values(out)) list.sort((a, b) => a.createdMs - b.createdMs);
  return out;
}

export async function fetchLabServices(labId: string): Promise<LabService[]> {
  const snap = await getDocs(query(collection(db, 'labServices'), where('labId', '==', labId)));
  const list: LabService[] = [];
  snap.forEach((d) => list.push(toService(d.id, d.data())));
  return list.sort((a, b) => a.createdMs - b.createdMs);
}
