import { BarChart3, Building2, ClipboardList, FlaskConical, House, LayoutGrid, Receipt } from 'lucide-react';

export type TabId = 'home' | 'cases' | 'invoices' | 'labs' | 'analytics' | 'my-lab' | 'account' | 'more';

const ICONS = {
  home: House,
  labs: FlaskConical,
  cases: ClipboardList,
  invoices: Receipt,
  analytics: BarChart3,
  'my-lab': Building2,
  more: LayoutGrid,
} as const;

interface Props {
  role: 'doctor' | 'lab';
  active: TabId;
  onSelect: (t: TabId) => void;
}

export function BottomNav({ role, active, onSelect }: Props) {
  const items: { id: keyof typeof ICONS; label: string }[] =
    role === 'lab'
      ? [
          { id: 'cases', label: 'الطلبات' },
          { id: 'my-lab', label: 'خدماتي' },
          { id: 'invoices', label: 'الفواتير' },
          { id: 'analytics', label: 'التحليلات' },
          { id: 'more', label: 'المزيد' },
        ]
      : [
          { id: 'home', label: 'الرئيسية' },
          { id: 'labs', label: 'المعامل' },
          { id: 'cases', label: 'طلباتي' },
          { id: 'invoices', label: 'الفواتير' },
          { id: 'more', label: 'المزيد' },
        ];
  const current: TabId = active === 'account' ? 'more' : active;

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-40 border-t border-white/80 bg-white/90 backdrop-blur-xl lg:hidden"
      style={{ paddingBottom: 'max(env(safe-area-inset-bottom, 0px), 6px)' }}
    >
      <div className="mx-auto grid max-w-xl grid-cols-5">
        {items.map(({ id, label }) => {
          const Icon = ICONS[id];
          const on = current === id;
          return (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={on}
              onClick={() => onSelect(id)}
              className={`relative flex flex-col items-center gap-0.5 pt-2.5 pb-1.5 text-[11px] font-bold ${on ? 'text-[#002B6B]' : 'text-[#7a90a8]'}`}
            >
              {on && <span className="absolute top-0 h-[3px] w-8 rounded-full bg-[#00A8B5]" />}
              <Icon className={`h-5 w-5 ${on ? 'animate-pop' : ''}`} strokeWidth={on ? 2.4 : 2} />
              {label}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
