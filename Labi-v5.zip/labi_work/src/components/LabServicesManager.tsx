import { useEffect, useState, type ChangeEvent } from 'react';
import { deleteDoc, doc, serverTimestamp, setDoc } from 'firebase/firestore';
import { Camera, Pencil, Plus, Trash2, X } from 'lucide-react';
import { auth, db } from '../firebase';
import type { DentalLab } from '../types';
import { fmtPrice } from '../utils/labRank';
import { processImageUpload } from '../utils/imageUpload';
import { fetchLabServices, SERVICE_CATEGORIES, type LabService } from '../utils/services';

interface Form {
  id?: string;
  createdAt?: unknown;
  name: string;
  category: string;
  price: string;
  days: string;
  description: string;
  photo: string;
}

const EMPTY: Form = { name: '', category: SERVICE_CATEGORIES[0], price: '', days: '3', description: '', photo: '' };

export function LabServicesManager({ lab }: { lab: DentalLab }) {
  const [items, setItems] = useState<LabService[]>([]);
  const [form, setForm] = useState<Form | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refresh = () => fetchLabServices(lab.id).then(setItems).catch(() => undefined);

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lab.id]);

  const pickPhoto = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !form) return;
    setError(null);
    try {
      const dataUrl = await processImageUpload(file, { maxDimension: 700, maxDataUrlChars: 250000 });
      setForm({ ...form, photo: dataUrl });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'ما قدرناش نجهز الصورة.');
    }
  };

  const save = async () => {
    if (!form) return;
    const uid = auth.currentUser?.uid;
    if (!uid) return;
    const price = Number(form.price);
    const days = Number(form.days);
    if (!form.name.trim()) return setError('اكتب اسم الخدمة.');
    if (!Number.isFinite(price) || price < 0) return setError('اكتب السعر بالأرقام.');
    if (!Number.isFinite(days) || days < 0 || days > 90) return setError('مدة التسليم لازم تكون بين 0 و90 يوم.');
    if (!form.id && items.length >= 40) return setError('الحد الأقصى 40 خدمة.');
    setBusy(true);
    setError(null);
    try {
      const id = form.id ?? `svc_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      await setDoc(doc(db, 'labServices', id), {
        id,
        labId: lab.id,
        ownerUid: uid,
        name: form.name.trim(),
        category: form.category,
        priceEgp: Math.round(price),
        days: Math.round(days),
        description: form.description.trim(),
        photoDataUrl: form.photo,
        createdAt: form.id ? form.createdAt : serverTimestamp(),
      });
      setForm(null);
      await refresh();
    } catch {
      setError('ما قدرناش نحفظ الخدمة. اتأكد إن قواعد Firebase اتحدثت.');
    } finally {
      setBusy(false);
    }
  };

  const remove = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'labServices', id));
      await refresh();
    } catch {
      setError('ما قدرناش نمسح الخدمة.');
    }
  };

  const input =
    'w-full rounded-2xl border border-[#CFE0EE] bg-white px-4 py-3 text-base text-[#0B1E3B] placeholder:text-[#8aa0b8] focus:outline-none focus:ring-2 focus:ring-[#00A8B5]';

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between px-1">
        <div>
          <div className="text-lg font-extrabold text-[#002B6B]">خدماتي وأسعاري</div>
          <div className="text-xs text-[#4b6483]">اللي بتضيفه هنا بيظهر للدكاترة مع صورته وسعره.</div>
        </div>
        <button
          type="button"
          onClick={() => {
            setError(null);
            setForm({ ...EMPTY });
          }}
          className="flex items-center gap-1.5 rounded-2xl bg-[#002B6B] px-4 py-2.5 text-sm font-bold text-white"
        >
          <Plus className="h-4 w-4" />
          إضافة
        </button>
      </div>

      {error && !form && <div className="rounded-2xl border border-red-200 bg-red-50 p-3 text-sm text-red-800">{error}</div>}

      {items.length === 0 ? (
        <div className="rounded-3xl bg-white/80 p-8 text-center text-sm text-[#4b6483]">
          لسه ما ضفتش خدمات. اضغط "إضافة" وابدأ بأول خدمة (زيركون، إيماكس، بورسلين...).
        </div>
      ) : (
        items.map((s) => (
          <div key={s.id} className="flex items-center gap-3 rounded-3xl bg-white/90 border border-white p-3 shadow-[0_6px_18px_rgba(0,43,107,0.07)]">
            <div className="h-16 w-16 shrink-0 overflow-hidden rounded-2xl bg-[#EEF5FA]">
              {s.photoDataUrl && <img src={s.photoDataUrl} alt="" className="h-full w-full object-cover" />}
            </div>
            <div className="min-w-0 flex-1">
              <div className="truncate text-[15px] font-bold text-[#002B6B]">{s.name}</div>
              <div className="text-[11px] text-[#4b6483]">{s.category} · {s.days} أيام</div>
              <div className="text-sm font-extrabold text-[#002B6B]">{fmtPrice(s.priceEgp)}</div>
            </div>
            <button
              type="button"
              aria-label="تعديل"
              onClick={() => {
                setError(null);
                setForm({
                  id: s.id,
                  createdAt: s.createdAt,
                  name: s.name,
                  category: s.category,
                  price: String(s.priceEgp),
                  days: String(s.days),
                  description: s.description,
                  photo: s.photoDataUrl,
                });
              }}
              className="rounded-xl p-2 text-[#002B6B]"
            >
              <Pencil className="h-4 w-4" />
            </button>
            <button type="button" aria-label="مسح" onClick={() => remove(s.id)} className="rounded-xl p-2 text-red-600">
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        ))
      )}

      {form && (
        <div className="fixed inset-0 z-[90] flex items-end bg-black/45 animate-tab-in" onClick={() => !busy && setForm(null)}>
          <div
            className="max-h-[92dvh] w-full overflow-y-auto rounded-t-[32px] bg-[#F7FBFE] px-5 pt-5"
            style={{ paddingBottom: 'max(env(safe-area-inset-bottom, 0px), 20px)' }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-4 flex items-center justify-between">
              <div className="text-lg font-extrabold text-[#002B6B]">{form.id ? 'تعديل خدمة' : 'إضافة خدمة جديدة'}</div>
              <button type="button" onClick={() => setForm(null)} aria-label="إغلاق" className="rounded-xl p-2 text-[#4b6483]">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="mb-1 block text-xs font-bold text-[#002B6B]">اسم الخدمة *</label>
                <input className={input} placeholder="مثال: Zirconia Max" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </div>
              <div>
                <label className="mb-1 block text-xs font-bold text-[#002B6B]">النوع</label>
                <div className="flex flex-wrap gap-2">
                  {SERVICE_CATEGORIES.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setForm({ ...form, category: c })}
                      className={`rounded-full px-3.5 py-1.5 text-sm font-bold ${form.category === c ? 'bg-[#002B6B] text-white' : 'bg-white border border-[#CFE0EE] text-[#002B6B]'}`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="mb-1 block text-xs font-bold text-[#002B6B]">السعر (جنيه) *</label>
                  <input className={input} inputMode="numeric" placeholder="1800" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value.replace(/[^0-9]/g, '') })} />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-bold text-[#002B6B]">مدة التسليم (أيام)</label>
                  <input className={input} inputMode="numeric" value={form.days} onChange={(e) => setForm({ ...form, days: e.target.value.replace(/[^0-9]/g, '') })} />
                </div>
              </div>
              <div>
                <label className="mb-1 block text-xs font-bold text-[#002B6B]">وصف الخدمة</label>
                <textarea className={input} rows={3} maxLength={400} placeholder="تفاصيل الخدمة..." value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
              </div>
              <div>
                <label className="mb-1 block text-xs font-bold text-[#002B6B]">صورة الخدمة</label>
                <label className="flex h-32 cursor-pointer flex-col items-center justify-center gap-1 overflow-hidden rounded-2xl border-2 border-dashed border-[#9CC3E4] bg-white text-sm text-[#31496a]">
                  {form.photo ? (
                    <img src={form.photo} alt="" className="h-full w-full object-cover" />
                  ) : (
                    <>
                      <Camera className="h-6 w-6 text-[#00A8B5]" />
                      اضغط لرفع الصورة
                    </>
                  )}
                  <input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={pickPhoto} />
                </label>
              </div>
              {error && <div className="rounded-2xl border border-red-200 bg-red-50 p-3 text-sm text-red-800">{error}</div>}
              <button
                type="button"
                disabled={busy}
                onClick={save}
                className="w-full rounded-2xl bg-[#002B6B] py-3.5 text-[15px] font-bold text-white shadow-[0_8px_20px_rgba(0,43,107,0.3)] disabled:opacity-60"
              >
                {busy ? 'استنى...' : 'حفظ الخدمة'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
