import { MapPin, Star } from 'lucide-react';
import { fmtKm, fmtPrice, type LabRow } from '../utils/labRank';

interface Props {
  row: LabRow;
  badge?: string;
  onClick: () => void;
  compact?: boolean;
}

export function LabCard({ row, badge, onClick, compact }: Props) {
  const { lab } = row;
  return (
    <button
      type="button"
      onClick={onClick}
      className={`text-start rounded-3xl bg-white/90 border border-white shadow-[0_8px_24px_rgba(0,43,107,0.08)] overflow-hidden ${
        compact ? 'w-64 shrink-0' : 'w-full'
      }`}
    >
      <div className={`flex gap-3 p-3 ${compact ? 'flex-col' : 'items-center'}`}>
        <div
          className={`relative shrink-0 overflow-hidden rounded-2xl bg-[linear-gradient(135deg,#002B6B,#00A8B5)] flex items-center justify-center text-white text-2xl font-bold ${
            compact ? 'h-28 w-full' : 'h-20 w-20'
          }`}
        >
          {row.thumb ? (
            <img src={row.thumb} alt="" className="h-full w-full object-cover" />
          ) : (
            <span>{lab.name.trim().charAt(0).toUpperCase()}</span>
          )}
          {badge && (
            <span className="absolute bottom-1.5 start-1.5 rounded-full bg-[#00A8B5] px-2 py-0.5 text-[10px] font-bold text-white">
              {badge}
            </span>
          )}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center justify-between gap-2">
            <div className="truncate text-[15px] font-bold text-[#002B6B]">{lab.name}</div>
            <div className="flex shrink-0 items-center gap-0.5 text-xs font-bold text-[#0B1E3B]">
              <Star className="h-3.5 w-3.5 fill-[#F5B301] text-[#F5B301]" />
              {row.rating !== null ? row.rating.toFixed(1) : 'جديد'}
            </div>
          </div>
          <div className="mt-0.5 truncate text-[11px] text-[#4b6483]">
            {[lab.area, lab.city].filter(Boolean).join('، ')}
          </div>
          <div className="mt-2 flex flex-wrap items-center gap-1.5 text-[11px]">
            {row.distanceKm !== null && (
              <span className="inline-flex items-center gap-1 rounded-full bg-[#EEF5FA] px-2 py-1 font-semibold text-[#007a84]">
                <MapPin className="h-3 w-3" />
                {fmtKm(row.distanceKm)}
              </span>
            )}
            {row.minPrice !== null && (
              <span className="rounded-full bg-[#EEF5FA] px-2 py-1 font-semibold text-[#002B6B]">
                من {fmtPrice(row.minPrice)}
              </span>
            )}
            <span className="rounded-full bg-[#EEF5FA] px-2 py-1 font-semibold text-[#31496a]">
              {row.days} أيام
            </span>
          </div>
        </div>
      </div>
    </button>
  );
}
