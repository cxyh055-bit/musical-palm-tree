import { useState } from 'react';
import { ArrowRight, MapPin, MessageSquarePlus, Star } from 'lucide-react';
import { fmtKm, fmtPrice, type LabRow } from '../utils/labRank';
import { LabGalleryStrip } from './LabGallery';

interface Props {
  row: LabRow;
  onBack: () => void;
  onRequest: (labId: string) => void;
}

export function LabDetailView({ row, onBack, onRequest }: Props) {
  const { lab } = row;
  const [tab, setTab] = useState<'services' | 'about'>('services');
  const [zoom, setZoom] = useState<string | null>(null);

  return (
    <div className="space-y-4">
      <button type="button" onClick={onBack} className="flex items-center gap-1 text-sm font-semibold text-[#002B6B]">
        <ArrowRight className="h-4 w-4" />
        رجوع للمعامل
      </button>

      <div className="rounded-3xl bg-white/90 border border-white p-5 text-center shadow-[0_8px_24px_rgba(0,43,107,0.08)]">
        <div className="mx-auto flex h-20 w-20 items-center justify-center overflow-hidden rounded-3xl bg-[linear-gradient(135deg,#002B6B,#00A8B5)] text-3xl font-bold text-white">
          {row.thumb ? <img src={row.thumb} alt="" className="h-full w-full object-cover" /> : lab.name.trim().charAt(0).toUpperCase()}
        </div>
        <div className="mt-3 text-xl font-extrabold text-[#002B6B]">{lab.name}</div>
        <div className="mt-1 text-xs text-[#4b6483]">{[lab.area, lab.city].filter(Boolean).join('، ')}</div>
        <div className="mt-2 flex items-center justify-center gap-1 text-sm font-bold text-[#0B1E3B]">
          <Star className="h-4 w-4 fill-[#F5B301] text-[#F5B301]" />
          {row.rating !== null ? row.rating.toFixed(1) : 'جديد'}
          {row.ratingCount > 0 && <span className="text-xs font-normal text-[#4b6483]">({row.ratingCount} تقييم)</span>}
        </div>
        <div className="mt-3 flex justify-center gap-2 text-xs font-semibold">
          {row.distanceKm !== null && (
            <span className="inline-flex items-center gap-1 rounded-full bg-[#EEF5FA] px-3 py-1.5 text-[#007a84]">
              <MapPin className="h-3 w-3" />
              {fmtKm(row.distanceKm)}
            </span>
          )}
          <span className="rounded-full bg-[#EEF5FA] px-3 py-1.5 text-[#31496a]">تسليم {row.days} أيام</span>
        </div>
        <button
          type="button"
          onClick={() => onRequest(lab.id)}
          className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-[#002B6B] py-3.5 text-[15px] font-bold text-white shadow-[0_8px_20px_rgba(0,43,107,0.3)]"
        >
          <MessageSquarePlus className="h-4 w-4" />
          إرسال طلب لهذا المعمل
        </button>
      </div>

      <div className="grid grid-cols-2 gap-1 rounded-2xl bg-[#E4EEF7] p-1">
        {(
          [
            ['services', 'الخدمات'],
            ['about', 'نبذة عن المعمل'],
          ] as const
        ).map(([k, label]) => (
          <button
            key={k}
            type="button"
            role="tab"
            onClick={() => setTab(k)}
            className={`rounded-xl py-2.5 text-sm font-bold ${tab === k ? 'bg-[#002B6B] text-white' : 'text-[#002B6B]'}`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === 'services' ? (
        row.services.length === 0 ? (
          <div className="rounded-3xl bg-white/80 p-8 text-center text-sm text-[#4b6483]">
            المعمل لسه ما ضافش خدمات. تقدر تبعتله طلب وتتفق معاه على السعر.
          </div>
        ) : (
          <div className="space-y-2.5">
            {row.services.map((s) => (
              <div key={s.id} className="flex items-center gap-3 rounded-3xl bg-white/90 border border-white p-3 shadow-[0_6px_18px_rgba(0,43,107,0.07)]">
                <button
                  type="button"
                  disabled={!s.photoDataUrl}
                  onClick={() => setZoom(s.photoDataUrl)}
                  className="h-16 w-16 shrink-0 overflow-hidden rounded-2xl bg-[#EEF5FA]"
                >
                  {s.photoDataUrl && <img src={s.photoDataUrl} alt="" className="h-full w-full object-cover" />}
                </button>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[15px] font-bold text-[#002B6B]">{s.name}</div>
                  {s.description && <div className="line-clamp-2 text-[11px] text-[#4b6483]">{s.description}</div>}
                  <div className="mt-1 text-[11px] font-semibold text-[#007a84]">{s.days} أيام</div>
                </div>
                <div className="shrink-0 text-end text-sm font-extrabold text-[#002B6B]">{fmtPrice(s.priceEgp)}</div>
              </div>
            ))}
          </div>
        )
      ) : (
        <div className="space-y-3 rounded-3xl bg-white/90 border border-white p-5 text-sm text-[#31496a]">
          {lab.summary && <p className="leading-7">{lab.summary}</p>}
          {lab.specialties.length > 0 && <div><b className="text-[#002B6B]">التخصصات: </b>{lab.specialties.join('، ')}</div>}
          {lab.materials.length > 0 && <div><b className="text-[#002B6B]">الخامات: </b>{lab.materials.join('، ')}</div>}
          {lab.scannerSupport.length > 0 && <div><b className="text-[#002B6B]">السكانرز: </b>{lab.scannerSupport.join('، ')}</div>}
          <LabGalleryStrip labId={lab.id} />
          {lab.latitude != null && lab.longitude != null && (
            <a
              href={`https://www.google.com/maps/search/?api=1&query=${lab.latitude},${lab.longitude}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 rounded-2xl border border-[#CFE0EE] py-3 font-bold text-[#002B6B]"
            >
              <MapPin className="h-4 w-4" />
              افتح الموقع في خرائط جوجل
            </a>
          )}
        </div>
      )}

      {zoom && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 p-4" onClick={() => setZoom(null)}>
          <img src={zoom} alt="" className="max-h-full max-w-full rounded-2xl" />
        </div>
      )}
    </div>
  );
}
