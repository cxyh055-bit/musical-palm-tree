import { useState, type FormEvent } from 'react';
import { MapPin, Search, Trophy, Wallet, Zap } from 'lucide-react';
import { SORT_LABELS, sortRows, type LabRow, type SortKey } from '../utils/labRank';
import { LabCard } from './LabCard';

interface Props {
  displayName: string;
  rows: LabRow[];
  onGoLabs: (sort: SortKey) => void;
  onSearch: (q: string) => void;
  onOpenLab: (labId: string) => void;
}

const TILES: { key: SortKey; Icon: typeof MapPin }[] = [
  { key: 'nearest', Icon: MapPin },
  { key: 'cheapest', Icon: Wallet },
  { key: 'fastest', Icon: Zap },
  { key: 'rated', Icon: Trophy },
];

export function HomeView({ displayName, rows, onGoLabs, onSearch, onOpenLab }: Props) {
  const [q, setQ] = useState('');
  const featured = sortRows(rows, 'rated').slice(0, 6);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    onSearch(q);
  };

  return (
    <div className="space-y-6">
      <div className="px-1">
        <div className="text-xs text-[#4b6483]">أهلاً بيك</div>
        <div className="text-lg font-bold text-[#002B6B]">{displayName}</div>
      </div>

      <div className="rounded-3xl bg-[linear-gradient(150deg,#002B6B_0%,#0A4FA8_60%,#00A8B5_150%)] p-5 text-white shadow-[0_16px_36px_rgba(0,43,107,0.35)]">
        <div className="text-2xl font-extrabold leading-tight">جودة أعلى..<br />وقت أقل</div>
        <div className="mt-1 text-xs text-white/80">اختار أنسب معمل لشغلك في ثواني</div>
        <form onSubmit={submit} className="relative mt-4">
          <Search className="pointer-events-none absolute top-1/2 start-4 h-4 w-4 -translate-y-1/2 text-[#6a84a0]" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="ابحث عن معمل أو خدمة..."
            className="w-full rounded-2xl bg-white py-3.5 ps-11 pe-4 text-base text-[#0B1E3B] placeholder:text-[#8aa0b8] focus:outline-none"
          />
        </form>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {TILES.map(({ key, Icon }) => (
          <button
            key={key}
            type="button"
            onClick={() => onGoLabs(key)}
            className="flex flex-col items-center gap-2 rounded-3xl bg-white/90 border border-white py-5 shadow-[0_8px_24px_rgba(0,43,107,0.08)]"
          >
            <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#EEF5FA] text-[#002B6B]">
              <Icon className="h-5 w-5" />
            </span>
            <span className="text-sm font-bold text-[#002B6B]">{SORT_LABELS[key]}</span>
          </button>
        ))}
      </div>

      {featured.length > 0 && (
        <div>
          <div className="mb-3 flex items-center justify-between px-1">
            <div className="text-base font-bold text-[#002B6B]">المعامل المميزة</div>
            <button type="button" onClick={() => onGoLabs('rated')} className="text-xs font-semibold text-[#007a84]">
              عرض الكل
            </button>
          </div>
          <div className="no-scrollbar -mx-4 flex gap-3 overflow-x-auto px-4 pb-2">
            {featured.map((r) => (
              <LabCard key={r.lab.id} row={r} compact onClick={() => onOpenLab(r.lab.id)} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
