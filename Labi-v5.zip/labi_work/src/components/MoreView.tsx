import type { ReactNode } from 'react';
import { BarChart3, Building2, ChevronLeft, Languages, LogOut, Receipt, Settings2 } from 'lucide-react';
import { useLang } from '../i18n';
import type { UserProfile } from '../types';
import type { TabId } from './BottomNav';

interface Props {
  profile: UserProfile;
  role: 'doctor' | 'lab';
  onNavigate: (t: TabId) => void;
  onSignOut: () => void;
}

function Row({ icon, label, onClick, danger }: { icon: ReactNode; label: string; onClick: () => void; danger?: boolean }) {
  return (
    <button type="button" onClick={onClick} className="flex w-full items-center gap-3 px-4 py-4 text-start">
      <span className={danger ? 'text-red-600' : 'text-[#002B6B]'}>{icon}</span>
      <span className={`flex-1 text-[15px] font-bold ${danger ? 'text-red-600' : 'text-[#002B6B]'}`}>{label}</span>
      {!danger && <ChevronLeft className="h-4 w-4 text-[#9bb0c6]" />}
    </button>
  );
}

export function MoreView({ profile, role, onNavigate, onSignOut }: Props) {
  const { lang, setLang } = useLang();
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4 rounded-3xl bg-[linear-gradient(150deg,#002B6B_0%,#0A4FA8_100%)] p-5 text-white shadow-[0_16px_36px_rgba(0,43,107,0.3)]">
        <div className="flex h-16 w-16 items-center justify-center overflow-hidden rounded-full bg-white/20 text-2xl font-bold">
          {profile.profilePhotoUrl ? (
            <img src={profile.profilePhotoUrl} alt="" className="h-full w-full object-cover" />
          ) : (
            (profile.displayName || '?').trim().charAt(0).toUpperCase()
          )}
        </div>
        <div className="min-w-0">
          <div className="truncate text-lg font-extrabold">{profile.displayName}</div>
          <div className="truncate text-xs text-white/80">
            {role === 'lab' ? 'معمل أسنان' : 'طبيب أسنان'}
            {profile.organizationName ? ` · ${profile.organizationName}` : ''}
          </div>
        </div>
      </div>

      <div className="divide-y divide-[#E4EEF7] overflow-hidden rounded-3xl bg-white/90 border border-white shadow-[0_8px_24px_rgba(0,43,107,0.08)]">
        {role === 'lab' && (
          <Row icon={<Building2 className="h-5 w-5" />} label="بروفايل معملي" onClick={() => onNavigate('my-lab')} />
        )}
        <Row icon={<Receipt className="h-5 w-5" />} label="الفواتير والمدفوعات" onClick={() => onNavigate('invoices')} />
        {role === 'lab' && (
          <Row icon={<BarChart3 className="h-5 w-5" />} label="تحليلات المعمل" onClick={() => onNavigate('analytics')} />
        )}
        <Row icon={<Settings2 className="h-5 w-5" />} label="حسابي واللوكيشن" onClick={() => onNavigate('account')} />
        <Row
          icon={<Languages className="h-5 w-5" />}
          label={lang === 'ar' ? 'English' : 'العربية'}
          onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}
        />
      </div>

      <div className="overflow-hidden rounded-3xl bg-white/90 border border-white shadow-[0_8px_24px_rgba(0,43,107,0.08)]">
        <Row icon={<LogOut className="h-5 w-5" />} label="تسجيل الخروج" onClick={onSignOut} danger />
      </div>
    </div>
  );
}
