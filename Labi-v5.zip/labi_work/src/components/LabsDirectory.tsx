import { Search } from 'lucide-react';
import { SORT_LABELS, sortRows, type LabRow, type SortKey } from '../utils/labRank';
import { LabCard } from './LabCard';

interface Props {
  rows: LabRow[];
  sort: SortKey;
  onSortChange: (s: SortKey) => void;
  query: string;
  onQueryChange: (q: string) => void;
  onOpenLab: (labId: string) => void;
}

const ORDER: SortKey[] = ['nearest', 'cheapest', 'fastest', 'rated'];

export function LabsDirectory({ rows, sort, onSortChange, query, onQueryChange, onOpenLab }: Props) {
  const q = query.trim().toLowerCase();
  const filtered = rows.filter((r) => {
    if (!q) return true;
    return (
      r.lab.name.toLowerCase().includes(q) ||
      (r.lab.area ?? '').toLowerCase().includes(q) ||
      r.lab.city.toLowerCase().includes(q) ||
      r.services.some((s) => s.name.toLowerCase().includes(q) || s.category.toLowerCase().includes(q)) ||
      r.lab.specialties.some((s) => s.toLowerCase().includes(q))
    );
  });
  const sorted = sortRows(filtered, sort);

  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="pointer-events-none absolute top-1/2 start-4 h-4 w-4 -translate-y-1/2 text-[#6a84a0]" />
        <input
          value={query}
          onChange={(e) => onQueryChange(e.target.value)}
          placeholder="ابحث عن معمل أو خدمة..."
          className="w-full rounded-2xl border border-[#CFE0EE] bg-white py-3.5 ps-11 pe-4 text-base text-[#0B1E3B] placeholder:text-[#8aa0b8] focus:outline-none focus:ring-2 focus:ring-[#00A8B5]"
        />
      </div>

      <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 pb-1">
        {ORDER.map((k) => (
          <button
            key={k}
            type="button"
            role="tab"
            onClick={() => onSortChange(k)}
            className={`shrink-0 rounded-full px-4 py-2 text-sm font-bold ${
              sort === k
                ? 'bg-[#002B6B] text-white shadow-[0_6px_16px_rgba(0,43,107,0.3)]'
                : 'bg-white text-[#002B6B] border border-[#CFE0EE]'
            }`}
          >
            {SORT_LABELS[k]}
          </button>
        ))}
      </div>

      {sorted.length === 0 ? (
        <div className="rounded-3xl bg-white/80 p-8 text-center text-sm text-[#4b6483]">
          مفيش معامل مطابقة للبحث.
        </div>
      ) : (
        <div className="space-y-3">
          {sorted.map((r, i) => (
            <LabCard
              key={r.lab.id}
              row={r}
              badge={i === 0 ? SORT_LABELS[sort] : undefined}
              onClick={() => onOpenLab(r.lab.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}
