import { useState, type FormEvent } from 'react';
import { doc, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import { CheckCircle2 } from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { useLang } from '../i18n';
import {
  LAB_ACCREDITATIONS_LIST,
  LAB_IMAGES,
  LAB_SERVICES_LIST,
  MATERIAL_TYPES,
  SCANNER_SOURCES,
  sanitizeIdSegment,
  VALIDATION,
  type CurrencyCode,
  type DentalLab,
  type LabImageKey,
  type PriceTier,
  type UserProfile,
} from '../types';
import { AREA_PRESETS } from '../utils/geo';
import { LabGalleryManager } from './LabGallery';
import { LocationPicker } from './LocationPicker';
import { SafeImage } from './SafeImage';

interface LabProfileEditorProps {
  profile: UserProfile;
  existingLab: DentalLab | null;
  onSaved: () => void;
}

export function LabProfileEditor({ profile, existingLab, onSaved }: LabProfileEditorProps) {
  const { lang } = useLang();
  const isAr = lang === 'ar';

  const [name, setName] = useState(existingLab?.name || `${profile.organizationName}`);
  const [city, setCity] = useState(existingLab?.city || profile.city || AREA_PRESETS[0].city);
  const [area, setArea] = useState(existingLab?.area || profile.area || AREA_PRESETS[0].areaAr);
  const [latitude, setLatitude] = useState<number>(
    existingLab?.latitude ?? profile.latitude ?? AREA_PRESETS[0].lat
  );
  const [longitude, setLongitude] = useState<number>(
    existingLab?.longitude ?? profile.longitude ?? AREA_PRESETS[0].lng
  );
  const [turnaroundDays, setTurnaroundDays] = useState(
    existingLab?.turnaroundDays ?? profile.turnaroundDays ?? 3
  );
  const [expressHours, setExpressHours] = useState(existingLab?.expressHours ?? 24);
  const [priceTier, setPriceTier] = useState<PriceTier>(existingLab?.priceTier || 'Boutique');
  const [currency, setCurrency] = useState<CurrencyCode>(
    existingLab?.priceList?.currency || 'EGP'
  );
  const [zirconiaCrown, setZirconiaCrown] = useState(
    existingLab?.priceList?.zirconiaCrown ?? 1800
  );
  const [emaxVeneer, setEmaxVeneer] = useState(existingLab?.priceList?.emaxVeneer ?? 2400);
  const [implantAbutment, setImplantAbutment] = useState(
    existingLab?.priceList?.implantAbutment ?? 3500
  );
  const [clearAligner, setClearAligner] = useState(existingLab?.priceList?.clearAligner ?? 6500);
  const [denture, setDenture] = useState(existingLab?.priceList?.denture ?? 4500);
  const [rushFee, setRushFee] = useState(existingLab?.priceList?.rushFee ?? 400);

  const [imageKey, setImageKey] = useState<LabImageKey>(existingLab?.imageKey || 'ceramics');
  const [acceptingCases, setAcceptingCases] = useState(existingLab?.acceptingCases ?? true);
  const [specialties, setSpecialties] = useState<string[]>(
    existingLab?.specialties || profile.services || ['Esthetic Ceramics', 'Monolithic Zirconia']
  );
  const [materials, setMaterials] = useState<string[]>(
    existingLab?.materials || ['Monolithic Zirconia', 'Layered E.max', 'Titanium Custom']
  );
  const [scannerSupport, setScannerSupport] = useState<string[]>(
    existingLab?.scannerSupport || ['3Shape TRIOS', 'iTero Element', 'Medit i700']
  );
  const [accreditations, setAccreditations] = useState<string[]>(
    existingLab?.accreditations || profile.accreditations || ['CDT Certified Lab']
  );
  const [summary, setSummary] = useState(
    existingLab?.summary ||
      'معمل تركيبات رقمي متخصص في الزيركون والإيماكس ودعامات الزراعة مع مندوب سريع لاستلام وتسليم الحالات.'
  );
  const [saving, setSaving] = useState(false);
  const [savedBanner, setSavedBanner] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const toggleItem = (
    list: string[],
    setter: (v: string[]) => void,
    item: string,
    max: number,
    min = 1
  ) => {
    if (list.includes(item)) {
      if (list.length > min) setter(list.filter((i) => i !== item));
    } else if (list.length < max) {
      setter([...list, item]);
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSavedBanner(false);

    const cleanName = name.trim();
    const cleanCity = city.trim();
    const cleanArea = area.trim();
    const cleanSummary = summary.trim();

    if (cleanName.length < 2 || cleanName.length > VALIDATION.ORG_NAME_MAX) {
      setError(
        isAr
          ? `اسم المعمل لازم يكون من ٢ لـ ${VALIDATION.ORG_NAME_MAX} حرف.`
          : `Laboratory name must be 2–${VALIDATION.ORG_NAME_MAX} characters.`
      );
      return;
    }
    if (cleanCity.length < 2 || cleanCity.length > VALIDATION.CITY_MAX) {
      setError(
        isAr
          ? `المدينة لازم تكون من ٢ لـ ${VALIDATION.CITY_MAX} حرف.`
          : `City must be 2–${VALIDATION.CITY_MAX} characters.`
      );
      return;
    }
    if (cleanSummary.length < 10 || cleanSummary.length > VALIDATION.LAB_SUMMARY_MAX) {
      setError(
        isAr
          ? `ملخص خدمات المعمل لازم يكون من ١٠ لـ ${VALIDATION.LAB_SUMMARY_MAX} حرف.`
          : `Summary must be 10–${VALIDATION.LAB_SUMMARY_MAX} characters.`
      );
      return;
    }

    const labId = existingLab?.id || `lab-${sanitizeIdSegment(profile.uid)}`;
    const path = `labs/${labId}`;
    setSaving(true);

    const priceList = {
      zirconiaCrown: Math.min(200000, Math.max(0, Number(zirconiaCrown) || 0)),
      emaxVeneer: Math.min(200000, Math.max(0, Number(emaxVeneer) || 0)),
      implantAbutment: Math.min(200000, Math.max(0, Number(implantAbutment) || 0)),
      clearAligner: Math.min(200000, Math.max(0, Number(clearAligner) || 0)),
      denture: Math.min(200000, Math.max(0, Number(denture) || 0)),
      rushFee: Math.min(50000, Math.max(0, Number(rushFee) || 0)),
      currency,
    };

    try {
      const payload = {
        name: cleanName,
        city: cleanCity,
        area: cleanArea.slice(0, VALIDATION.AREA_MAX),
        latitude,
        longitude,
        turnaroundDays: Math.min(30, Math.max(1, Number(turnaroundDays) || 3)),
        expressHours: Math.min(72, Math.max(0, Number(expressHours) || 24)),
        specialties,
        materials,
        scannerSupport,
        accreditations,
        priceTier,
        priceList,
        summary: cleanSummary,
        imageKey,
        acceptingCases,
        updatedAt: serverTimestamp(),
      };

      if (existingLab) {
        await updateDoc(doc(db, 'labs', labId), payload);
      } else {
        await setDoc(doc(db, 'labs', labId), {
          id: labId,
          ownerUid: profile.uid,
          ...payload,
          createdAt: serverTimestamp(),
        });
      }
      setSavedBanner(true);
      onSaved();
    } catch (err) {
      handleFirestoreError(err, existingLab ? OperationType.UPDATE : OperationType.CREATE, path);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-4xl space-y-6">
      <div>
        <h2 className="font-display text-xl font-bold text-[#002B6B]">
          {existingLab
            ? isAr
              ? 'إدارة بيانات وأسعار المعمل'
              : 'Laboratory Directory Listing'
            : isAr
              ? 'سجّل معملك في دليل لابي'
              : 'Publish a Dental Laboratory Listing'}
        </h2>
        <p className="text-sm text-slate-600 mt-1">
          {isAr
            ? 'حدد لوكيشن المعمل، أسعار التركيبات، وقت التسليم العادي والمستعجل، والاعتمادات عشان تظهر للدكاترة القريبين منك.'
            : 'Specify your laboratory location, pricing menu, turnaround SLA, and accreditations for nearby dental clinics.'}
        </p>
      </div>

      <form
        onSubmit={handleSubmit}
        className="glass-panel rounded-2xl p-6 space-y-6"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="lab-name" className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5">
              {isAr ? 'اسم المعمل' : 'Laboratory Name'}
            </label>
            <input
              id="lab-name"
              type="text"
              required
              maxLength={VALIDATION.ORG_NAME_MAX}
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 text-sm glass-input rounded-xl text-[#0B1E3B]"
            />
          </div>

          <div>
            <label htmlFor="lab-city" className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5">
              {isAr ? 'المدينة / المحافظة' : 'City / Governorate'}
            </label>
            <input
              id="lab-city"
              type="text"
              required
              maxLength={VALIDATION.CITY_MAX}
              value={city}
              onChange={(e) => setCity(e.target.value)}
              className="w-full px-3 py-2 text-sm glass-input rounded-xl text-[#0B1E3B]"
            />
          </div>
        </div>

        {/* Geo Location Picker */}
        <LocationPicker
          area={area}
          city={city}
          latitude={latitude}
          longitude={longitude}
          onChange={(loc) => {
            setArea(loc.area);
            setCity(loc.city);
            setLatitude(loc.latitude);
            setLongitude(loc.longitude);
          }}
        />

        {existingLab && <LabGalleryManager labId={existingLab.id} />}

        {/* Turnaround & Tier */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
          <div>
            <label
              htmlFor="lab-turnaround"
              className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
            >
              {isAr ? 'بيسلم في كام يوم؟' : 'Standard Turnaround (Days)'}
            </label>
            <input
              id="lab-turnaround"
              type="number"
              min={1}
              max={30}
              value={turnaroundDays}
              onChange={(e) => setTurnaroundDays(Number(e.target.value))}
              className="w-full px-3 py-2 text-sm font-mono tabular-nums glass-input rounded-xl text-[#0B1E3B]"
            />
          </div>

          <div>
            <label
              htmlFor="lab-express"
              className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
            >
              {isAr ? 'تسليم مستعجل (ساعة)' : 'Express Rush (Hours)'}
            </label>
            <input
              id="lab-express"
              type="number"
              min={0}
              max={72}
              value={expressHours}
              onChange={(e) => setExpressHours(Number(e.target.value))}
              className="w-full px-3 py-2 text-sm font-mono tabular-nums glass-input rounded-xl text-[#0B1E3B]"
            />
          </div>

          <div>
            <label htmlFor="lab-tier" className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5">
              {isAr ? 'فئة المعمل' : 'Pricing Tier'}
            </label>
            <select
              id="lab-tier"
              value={priceTier}
              onChange={(e) => setPriceTier(e.target.value as PriceTier)}
              className="w-full px-3 py-2 text-sm glass-input rounded-xl text-[#0B1E3B]"
            >
              <option value="Standard">{isAr ? 'اقتصادي (Standard)' : 'Standard'}</option>
              <option value="Boutique">{isAr ? 'تجميلي متقدم (Boutique)' : 'Boutique'}</option>
              <option value="Enterprise">{isAr ? 'مركز متكامل (Enterprise)' : 'Enterprise'}</option>
            </select>
          </div>

          <div>
            <label htmlFor="lab-image" className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5">
              {isAr ? 'صورة تخصص المعمل' : 'Showcase Photo'}
            </label>
            <select
              id="lab-image"
              value={imageKey}
              onChange={(e) => setImageKey(e.target.value as LabImageKey)}
              className="w-full px-3 py-2 text-sm glass-input rounded-xl text-[#0B1E3B]"
            >
              <option value="ceramics">{isAr ? 'خزف وإيماكس' : 'Porcelain & Ceramics'}</option>
              <option value="cad">{isAr ? 'طحن CAD/CAM' : '5-Axis CAD/CAM Milling'}</option>
              <option value="implants">{isAr ? 'تركيبات زراعة' : 'Implant Prosthetics'}</option>
              <option value="studio">{isAr ? 'معمل متكامل' : 'Full Digital Bench'}</option>
            </select>
          </div>
        </div>

        {/* Price List Section */}
        <div className="glass-surface rounded-xl p-4 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <div className="text-xs font-semibold text-[#002B6B]">
                {isAr ? 'قائمة أسعار المعمل للعيادات' : 'Laboratory Price List'}
              </div>
              <p className="text-xs text-slate-600">
                {isAr
                  ? 'الدكتور بيشوف أسعارك مباشرة قبل ما يبعت الحالة.'
                  : 'Shown to doctors in the directory and used to estimate prescription fees.'}
              </p>
            </div>
            <select
              aria-label="Currency"
              value={currency}
              onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
              className="px-2.5 py-1 text-xs font-mono glass-input rounded-lg text-[#0B1E3B]"
            >
              <option value="EGP">EGP (ج.م)</option>
              <option value="USD">USD ($)</option>
            </select>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div>
              <label htmlFor="pl-zirc" className="block text-xs text-slate-700 mb-1">
                {isAr ? 'طربوش زيركون' : 'Zirconia Crown'}
              </label>
              <input
                id="pl-zirc"
                type="number"
                min={0}
                value={zirconiaCrown}
                onChange={(e) => setZirconiaCrown(Number(e.target.value))}
                className="w-full px-3 py-1.5 text-sm font-mono tabular-nums glass-input rounded-xl text-[#0B1E3B]"
              />
            </div>
            <div>
              <label htmlFor="pl-emax" className="block text-xs text-slate-700 mb-1">
                {isAr ? 'عدسة إيماكس' : 'E.max Veneer'}
              </label>
              <input
                id="pl-emax"
                type="number"
                min={0}
                value={emaxVeneer}
                onChange={(e) => setEmaxVeneer(Number(e.target.value))}
                className="w-full px-3 py-1.5 text-sm font-mono tabular-nums glass-input rounded-xl text-[#0B1E3B]"
              />
            </div>
            <div>
              <label htmlFor="pl-imp" className="block text-xs text-slate-700 mb-1">
                {isAr ? 'دعامة زراعة' : 'Implant Abutment'}
              </label>
              <input
                id="pl-imp"
                type="number"
                min={0}
                value={implantAbutment}
                onChange={(e) => setImplantAbutment(Number(e.target.value))}
                className="w-full px-3 py-1.5 text-sm font-mono tabular-nums glass-input rounded-xl text-[#0B1E3B]"
              />
            </div>
            <div>
              <label htmlFor="pl-align" className="block text-xs text-slate-700 mb-1">
                {isAr ? 'تقويم شفاف (فك)' : 'Clear Aligner Arch'}
              </label>
              <input
                id="pl-align"
                type="number"
                min={0}
                value={clearAligner}
                onChange={(e) => setClearAligner(Number(e.target.value))}
                className="w-full px-3 py-1.5 text-sm font-mono tabular-nums glass-input rounded-xl text-[#0B1E3B]"
              />
            </div>
            <div>
              <label htmlFor="pl-dent" className="block text-xs text-slate-700 mb-1">
                {isAr ? 'طقم أسنان كامل' : 'Full Denture'}
              </label>
              <input
                id="pl-dent"
                type="number"
                min={0}
                value={denture}
                onChange={(e) => setDenture(Number(e.target.value))}
                className="w-full px-3 py-1.5 text-sm font-mono tabular-nums glass-input rounded-xl text-[#0B1E3B]"
              />
            </div>
            <div>
              <label htmlFor="pl-rush" className="block text-xs text-slate-700 mb-1">
                {isAr ? 'إضافي الاستعجال' : 'Rush Surcharge'}
              </label>
              <input
                id="pl-rush"
                type="number"
                min={0}
                value={rushFee}
                onChange={(e) => setRushFee(Number(e.target.value))}
                className="w-full px-3 py-1.5 text-sm font-mono tabular-nums glass-input rounded-xl text-[#0B1E3B]"
              />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-3.5 rounded-xl glass-surface">
            <div className="text-xs font-semibold text-[#002B6B] mb-2">
              {isAr ? 'خدمات المعمل (١–٨)' : 'Lab Services (1–8)'}
            </div>
            <div className="space-y-1.5">
              {LAB_SERVICES_LIST.map((spec) => (
                <label
                  key={spec}
                  className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={specialties.includes(spec)}
                    onChange={() => toggleItem(specialties, setSpecialties, spec, 8, 1)}
                    className="rounded border-slate-300 accent-[#002B6B]"
                  />
                  <span>{spec}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="p-3.5 rounded-xl glass-surface">
            <div className="text-xs font-semibold text-[#002B6B] mb-2">
              {isAr ? 'الخامات المتاحة (١–٨)' : 'Materials (1–8)'}
            </div>
            <div className="space-y-1.5">
              {MATERIAL_TYPES.map((mat) => (
                <label
                  key={mat}
                  className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={materials.includes(mat)}
                    onChange={() => toggleItem(materials, setMaterials, mat, 8, 1)}
                    className="rounded border-slate-300 accent-[#002B6B]"
                  />
                  <span>{mat}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="p-3.5 rounded-xl glass-surface">
            <div className="text-xs font-semibold text-[#002B6B] mb-2">
              {isAr ? 'الاسكانر المدعوم' : 'Scanners Supported'}
            </div>
            <div className="space-y-1.5">
              {SCANNER_SOURCES.map((scan) => (
                <label
                  key={scan}
                  className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={scannerSupport.includes(scan)}
                    onChange={() => toggleItem(scannerSupport, setScannerSupport, scan, 6, 1)}
                    className="rounded border-slate-300 accent-[#002B6B]"
                  />
                  <span>{scan}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="p-3.5 rounded-xl glass-surface">
            <div className="text-xs font-semibold text-[#002B6B] mb-2">
              {isAr ? 'الشهادات والاعتمادات' : 'Accreditations'}
            </div>
            <div className="space-y-1.5">
              {LAB_ACCREDITATIONS_LIST.map((acc) => (
                <label
                  key={acc}
                  className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={accreditations.includes(acc)}
                    onChange={() => toggleItem(accreditations, setAccreditations, acc, 6, 0)}
                    className="rounded border-slate-300 accent-[#002B6B]"
                  />
                  <span>{acc}</span>
                </label>
              ))}
            </div>
          </div>
        </div>

        <div>
          <label htmlFor="lab-summary" className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5">
            {isAr ? 'نبذة عن المعمل وخدمة المندوب' : 'Clinical Capability Summary'}
          </label>
          <textarea
            id="lab-summary"
            rows={3}
            required
            maxLength={VALIDATION.LAB_SUMMARY_MAX}
            value={summary}
            onChange={(e) => setSummary(e.target.value)}
            className="w-full px-3 py-2 text-sm glass-input rounded-xl text-[#0B1E3B]"
          />
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-3 border-t border-[#002B6B]/10">
          <label className="flex items-center gap-2.5 text-sm text-[#0B1E3B] cursor-pointer">
            <input
              type="checkbox"
              checked={acceptingCases}
              onChange={(e) => setAcceptingCases(e.target.checked)}
              className="rounded border-slate-300 accent-[#002B6B]"
            />
            <span>
              {isAr
                ? 'المعمل متاح ويستقبل حالات جديدة دلوقتي'
                : 'Listing active and accepting new clinic prescriptions'}
            </span>
          </label>

          <button
            type="submit"
            disabled={saving}
            className="btn-glass-primary px-5 py-2.5 text-sm font-semibold rounded-xl disabled:opacity-60 cursor-pointer whitespace-nowrap shrink-0"
          >
            {saving
              ? isAr
                ? 'جاري الحفظ...'
                : 'Saving...'
              : existingLab
                ? isAr
                  ? 'حفظ بيانات وأسعار المعمل'
                  : 'Update Lab Listing'
                : isAr
                  ? 'نشر المعمل في الدليل'
                  : 'Publish Lab Listing'}
          </button>
        </div>

        {savedBanner && (
          <div
            role="status"
            className="p-3 rounded-xl border border-emerald-200/90 bg-emerald-50/85 text-xs text-emerald-800 flex items-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>
              {isAr
                ? 'تم حفظ بيانات المعمل والأسعار واللوكيشن بنجاح.'
                : 'Laboratory listing saved and visible to prescribing doctors.'}
            </span>
          </div>
        )}

        {error && (
          <div role="alert" className="p-3 rounded-xl border border-red-200 bg-red-50/90 text-xs text-red-800">
            {error}
          </div>
        )}
      </form>

      <div className="glass-panel rounded-2xl p-5 flex items-center gap-5">
        <div className="w-32 h-24 rounded-xl overflow-hidden border border-white/80 shrink-0 bg-white/60 shadow-xs">
          <SafeImage
            src={LAB_IMAGES[imageKey].src}
            alt={LAB_IMAGES[imageKey].alt}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="text-xs text-slate-600 space-y-1">
          <div className="font-semibold text-[#002B6B]">
            {isAr ? 'معاينة بطاقة المعمل' : 'Directory Visual Preview'}
          </div>
          <p>{name} · {area || city}</p>
          <p className="font-mono tabular-nums text-[#008C99] font-medium">
            {turnaroundDays}d SLA · {zirconiaCrown} {currency} Zirconia · {emaxVeneer} {currency} E.max
          </p>
        </div>
      </div>
    </div>
  );
}
