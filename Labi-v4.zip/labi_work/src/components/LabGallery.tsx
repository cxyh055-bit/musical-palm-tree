import { useEffect, useState, type ChangeEvent } from 'react';
import { collection, deleteDoc, doc, getDocs, query, serverTimestamp, setDoc, where } from 'firebase/firestore';
import { Camera, Trash2, X } from 'lucide-react';
import { auth, db } from '../firebase';
import { useLang } from '../i18n';
import { processImageUpload } from '../utils/imageUpload';

interface Photo {
  id: string;
  dataUrl: string;
  createdMs: number;
}

async function loadPhotos(labId: string): Promise<Photo[]> {
  const snap = await getDocs(query(collection(db, 'labGallery'), where('labId', '==', labId)));
  const list: Photo[] = [];
  snap.forEach((d) => {
    const data = d.data() as { dataUrl?: string; createdAt?: { toMillis?: () => number } };
    if (data.dataUrl) {
      list.push({ id: d.id, dataUrl: data.dataUrl, createdMs: data.createdAt?.toMillis?.() ?? 0 });
    }
  });
  return list.sort((a, b) => b.createdMs - a.createdMs);
}

/** Read-only strip shown to doctors under the selected lab. */
export function LabGalleryStrip({ labId }: { labId: string }) {
  const { lang } = useLang();
  const isAr = lang === 'ar';
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [open, setOpen] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    setPhotos([]);
    loadPhotos(labId)
      .then((p) => alive && setPhotos(p.slice(0, 8)))
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [labId]);

  if (photos.length === 0) return null;

  return (
    <div className="w-full">
      <div className="mb-1 text-[11px] font-semibold text-[#002B6B]">
        {isAr ? 'صور من شغل المعمل' : 'Lab work samples'}
      </div>
      <div className="flex gap-2 overflow-x-auto pb-1">
        {photos.map((p) => (
          <button key={p.id} type="button" onClick={() => setOpen(p.dataUrl)} className="shrink-0">
            <img src={p.dataUrl} alt="" className="h-16 w-16 rounded-lg object-cover border border-[#D3E2EF]" />
          </button>
        ))}
      </div>
      {open && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 p-4"
          onClick={() => setOpen(null)}
        >
          <img src={open} alt="" className="max-h-full max-w-full rounded-xl" />
        </div>
      )}
    </div>
  );
}

/** Upload / delete UI for the lab owner inside the lab profile editor. */
export function LabGalleryManager({ labId }: { labId: string }) {
  const { lang } = useLang();
  const isAr = lang === 'ar';
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refresh = () => loadPhotos(labId).then(setPhotos).catch(() => undefined);

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [labId]);

  const onPick = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    const uid = auth.currentUser?.uid;
    if (!uid) return;
    if (photos.length >= 8) {
      setError(isAr ? 'الحد الأقصى 8 صور.' : 'Maximum 8 photos.');
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const dataUrl = await processImageUpload(file, { maxDimension: 900, maxDataUrlChars: 250000 });
      const id = `ph_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      await setDoc(doc(db, 'labGallery', id), {
        id,
        labId,
        ownerUid: uid,
        caption: '',
        dataUrl,
        createdAt: serverTimestamp(),
      });
      await refresh();
    } catch (err) {
      setError(
        err instanceof Error && err.message.includes('Image')
          ? err.message
          : isAr
            ? 'ما قدرناش نرفع الصورة. اتأكد إن قواعد Firebase اتحدثت.'
            : 'Could not upload. Make sure the Firebase rules are updated.'
      );
    } finally {
      setBusy(false);
    }
  };

  const remove = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'labGallery', id));
      await refresh();
    } catch {
      setError(isAr ? 'ما قدرناش نمسح الصورة.' : 'Could not delete the photo.');
    }
  };

  return (
    <div className="glass-surface rounded-xl p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div className="text-xs font-semibold text-[#002B6B]">
          {isAr ? 'صور من شغل المعمل (بتظهر للدكاترة)' : 'Lab work photos (visible to doctors)'}
        </div>
        <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-xl btn-glass-teal px-3 py-1.5 text-xs font-semibold">
          <Camera className="w-3.5 h-3.5" />
          {busy ? '...' : isAr ? 'أضف صورة' : 'Add photo'}
          <input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={onPick} disabled={busy} />
        </label>
      </div>
      {error && <div className="text-xs text-red-700">{error}</div>}
      <div className="grid grid-cols-4 gap-2">
        {photos.map((p) => (
          <div key={p.id} className="relative">
            <img src={p.dataUrl} alt="" className="aspect-square w-full rounded-lg object-cover" />
            <button
              type="button"
              onClick={() => remove(p.id)}
              aria-label="delete"
              className="absolute -top-1.5 -right-1.5 rounded-full bg-white p-1 shadow"
            >
              <Trash2 className="w-3 h-3 text-red-600" />
            </button>
          </div>
        ))}
      </div>
      {photos.length === 0 && (
        <div className="flex items-center gap-1 text-[11px] text-slate-500">
          <X className="w-3 h-3" />
          {isAr ? 'لسه ما ضفتش صور.' : 'No photos yet.'}
        </div>
      )}
    </div>
  );
}
