import { useEffect, useState } from 'react';
import { doc, getDoc, serverTimestamp, setDoc } from 'firebase/firestore';
import { Star } from 'lucide-react';
import { db } from '../firebase';
import { useLang } from '../i18n';
import type { DentalCase } from '../types';

export function RateLabCard({ dentalCase }: { dentalCase: DentalCase }) {
  const { lang } = useLang();
  const isAr = lang === 'ar';
  const [loaded, setLoaded] = useState(false);
  const [existing, setExisting] = useState<{ stars: number; comment?: string } | null>(null);
  const [stars, setStars] = useState(0);
  const [comment, setComment] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    getDoc(doc(db, 'ratings', dentalCase.id))
      .then((snap) => {
        if (!alive) return;
        setExisting(snap.exists() ? (snap.data() as { stars: number; comment?: string }) : null);
        setLoaded(true);
      })
      .catch(() => {
        if (alive) setLoaded(true);
      });
    return () => {
      alive = false;
    };
  }, [dentalCase.id]);

  const submit = async () => {
    if (stars < 1) {
      setError(isAr ? 'اختار عدد النجوم الأول.' : 'Pick a star rating first.');
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const trimmed = comment.trim().slice(0, 300);
      await setDoc(doc(db, 'ratings', dentalCase.id), {
        caseId: dentalCase.id,
        labId: dentalCase.labId,
        doctorUid: dentalCase.doctorUid,
        stars,
        ...(trimmed ? { comment: trimmed } : {}),
        createdAt: serverTimestamp(),
      });
      setExisting({ stars, comment: trimmed });
    } catch {
      setError(
        isAr
          ? 'ما قدرناش نحفظ التقييم. اتأكد إن قواعد Firebase اتحدثت وجرّب تاني.'
          : 'Could not save the rating. Make sure the Firebase rules are updated.'
      );
    } finally {
      setBusy(false);
    }
  };

  if (!loaded) return null;

  return (
    <div className="glass-surface rounded-xl p-4 space-y-3">
      <div className="text-xs font-semibold text-[#002B6B]">
        {isAr ? 'قيّم المعمل' : 'Rate the laboratory'}
      </div>
      {existing ? (
        <div className="flex items-center gap-1 text-sm text-[#0B1E3B]">
          {[1, 2, 3, 4, 5].map((n) => (
            <Star
              key={n}
              className={`w-5 h-5 ${n <= existing.stars ? 'fill-[#F5B301] text-[#F5B301]' : 'text-slate-300'}`}
            />
          ))}
          <span className="mx-2 text-xs text-slate-600">
            {isAr ? 'شكراً على تقييمك' : 'Thanks for your rating'}
          </span>
        </div>
      ) : (
        <>
          <div className="flex items-center gap-1.5">
            {[1, 2, 3, 4, 5].map((n) => (
              <button key={n} type="button" onClick={() => setStars(n)} aria-label={`${n}`} className="p-0.5">
                <Star
                  className={`w-8 h-8 ${n <= stars ? 'fill-[#F5B301] text-[#F5B301]' : 'text-slate-300'}`}
                />
              </button>
            ))}
          </div>
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            maxLength={300}
            rows={2}
            placeholder={isAr ? 'تعليق (اختياري)' : 'Comment (optional)'}
            className="w-full px-3 py-2 text-sm glass-input rounded-xl text-[#0B1E3B]"
          />
          {error && <div className="text-xs text-red-700">{error}</div>}
          <button
            type="button"
            disabled={busy}
            onClick={submit}
            className="px-4 py-2 text-xs font-semibold btn-glass-teal rounded-xl disabled:opacity-60"
          >
            {busy ? '...' : isAr ? 'ابعت التقييم' : 'Submit rating'}
          </button>
        </>
      )}
    </div>
  );
}
