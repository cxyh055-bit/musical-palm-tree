import { useEffect, useMemo, useState, type ChangeEvent, type FormEvent } from 'react';
import { doc, serverTimestamp, setDoc } from 'firebase/firestore';
import { motion } from 'motion/react';
import { Trash2, Upload, X } from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { MATERIAL_LABELS_AR, RESTORATION_LABELS_AR, useLang } from '../i18n';
import {
  estimateLabPriceForRestoration,
  MATERIAL_TYPES,
  RESTORATION_TYPES,
  SCANNER_SOURCES,
  VALIDATION,
  VITA_SHADES,
  type DentalLab,
  type MaterialType,
  type RestorationType,
  type ScannerSource,
  type UserProfile,
  type XrayAttachment,
} from '../types';
import { recordCaseAuditEvent } from '../utils/auditLog';
import { generateCaseEncryptionKeyB64 } from '../utils/crypto';
import { calculateDistanceKm } from '../utils/geo';
import { processImageUpload } from '../utils/imageUpload';
import { sendCaseStatusNotification } from '../utils/notifications';
import { fetchLabRatings, type LabRatingSummary } from '../utils/ratings';
import { LabGalleryStrip } from './LabGallery';
import { ToothChart } from './ToothChart';

interface NewCaseModalProps {
  profile: UserProfile;
  labs: DentalLab[];
  initialLabId?: string;
  onClose: () => void;
  onCreated: () => void;
}

function defaultDueDate(daysAhead: number): string {
  const d = new Date();
  d.setDate(d.getDate() + Math.max(2, daysAhead));
  return d.toISOString().slice(0, 10);
}

export function NewCaseModal({
  profile,
  labs,
  initialLabId,
  onClose,
  onCreated,
}: NewCaseModalProps) {
  const { lang } = useLang();
  const isAr = lang === 'ar';

  const acceptingLabs = useMemo(() => {
    const active = labs.filter((l) => l.acceptingCases);
    return [...active].sort((a, b) => {
      const da = calculateDistanceKm(profile.latitude, profile.longitude, a.latitude, a.longitude);
      const dbDist = calculateDistanceKm(
        profile.latitude,
        profile.longitude,
        b.latitude,
        b.longitude
      );
      if (da !== null && dbDist !== null) return da - dbDist;
      if (da !== null) return -1;
      if (dbDist !== null) return 1;
      return a.name.localeCompare(b.name);
    });
  }, [labs, profile.latitude, profile.longitude]);

  const defaultLab =
    acceptingLabs.find((l) => l.id === initialLabId) || acceptingLabs[0] || null;

  const [labId, setLabId] = useState(defaultLab?.id || '');
  const [ratings, setRatings] = useState<Record<string, LabRatingSummary>>({});

  useEffect(() => {
    let alive = true;
    fetchLabRatings()
      .then((r) => alive && setRatings(r))
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, []);
  const [patientInitials, setPatientInitials] = useState('');
  const [patientChartRef, setPatientChartRef] = useState('');
  const [patientAgeGroup, setPatientAgeGroup] = useState<'Adult' | 'Pediatric'>('Adult');
  const [restorationType, setRestorationType] = useState<RestorationType>('Crown');
  const [material, setMaterial] = useState<MaterialType>('Monolithic Zirconia');
  const [requiredLabWork, setRequiredLabWork] = useState('');
  const [toothNumbers, setToothNumbers] = useState<string[]>(['14']);
  const [shade, setShade] = useState('A2');
  const [scannerSource, setScannerSource] = useState<ScannerSource>('3Shape TRIOS');
  const [scanReference, setScanReference] = useState('');
  const [xrayAttachments, setXrayAttachments] = useState<XrayAttachment[]>([]);
  const [xrayError, setXrayError] = useState<string | null>(null);
  const [priority, setPriority] = useState<'Standard' | 'Rush'>('Standard');
  const [dueDate, setDueDate] = useState(defaultDueDate(defaultLab?.turnaroundDays ?? 3));
  const [clinicalNotes, setClinicalNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const selectedLab = acceptingLabs.find((l) => l.id === labId) || null;
  const selectedLabDistance = selectedLab
    ? calculateDistanceKm(
        profile.latitude,
        profile.longitude,
        selectedLab.latitude,
        selectedLab.longitude
      )
    : null;

  const priceQuote = estimateLabPriceForRestoration(
    selectedLab,
    restorationType,
    toothNumbers.length,
    priority
  );

  const toggleTooth = (tooth: string) => {
    setToothNumbers((prev) =>
      prev.includes(tooth) ? prev.filter((t) => t !== tooth) : [...prev, tooth]
    );
  };

  const handleLabChange = (nextLabId: string) => {
    setLabId(nextLabId);
    const nextLab = acceptingLabs.find((l) => l.id === nextLabId);
    if (nextLab) {
      setDueDate(defaultDueDate(nextLab.turnaroundDays));
    }
  };

  const handleXrayUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setXrayError(null);

    const remainingSlots = VALIDATION.XRAY_MAX_COUNT - xrayAttachments.length;
    if (remainingSlots <= 0) {
      setXrayError(
        isAr
          ? `أقصى عدد صور أشعة هو ${VALIDATION.XRAY_MAX_COUNT} للحالة الواحدة.`
          : `Maximum of ${VALIDATION.XRAY_MAX_COUNT} X-ray files per prescription.`
      );
      return;
    }

    const toProcess = Array.from(files).slice(0, remainingSlots);
    try {
      const processed: XrayAttachment[] = [];
      for (const file of toProcess) {
        const dataUrl = await processImageUpload(file, {
          maxDimension: 960,
          maxDataUrlChars: VALIDATION.XRAY_MAX_CHARS,
          initialQuality: 0.82,
        });
        processed.push({
          id: `xray-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
          name: file.name.slice(0, 80),
          dataUrl,
          uploadedAt: new Date().toISOString().slice(0, 19),
        });
      }
      setXrayAttachments((prev) => [...prev, ...processed]);
    } catch (err) {
      setXrayError(err instanceof Error ? err.message : 'Unable to attach X-ray file.');
    }
    e.target.value = '';
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!selectedLab) {
      setError(isAr ? 'اختر معمل الأول قبل إرسال الحالة.' : 'Select a dental lab before submitting.');
      return;
    }

    const cleanInitials = patientInitials.trim();
    const cleanChartRef = patientChartRef.trim();
    const cleanShade = shade.trim();
    const cleanScanRef = scanReference.trim();
    const cleanLabWork = requiredLabWork.trim();
    const cleanNotes = clinicalNotes.trim();

    if (!VALIDATION.INITIALS_PATTERN.test(cleanInitials)) {
      setError(
        isAr
          ? 'حروف اسم المريض لازم تكون من ١ لـ ٦ حروف (مثلاً: م.ك أو M.K.).'
          : 'Patient initials must be 1–6 letters/periods (e.g. M.K.).'
      );
      return;
    }
    if (cleanChartRef.length < 2 || cleanChartRef.length > VALIDATION.CHART_REF_MAX) {
      setError(
        isAr
          ? `رقم ملف المريض لازم يكون من ٢ لـ ${VALIDATION.CHART_REF_MAX} حرف.`
          : `Chart reference must be 2–${VALIDATION.CHART_REF_MAX} characters.`
      );
      return;
    }
    if (toothNumbers.length === 0) {
      setError(
        isAr
          ? 'اختر سنة واحدة على الأقل من خريطة الأسنان.'
          : 'Select at least one tooth on the dental chart.'
      );
      return;
    }
    if (!VALIDATION.DATE_PATTERN.test(dueDate)) {
      setError(isAr ? 'اختر ميعاد تسليم صحيح.' : 'Enter a valid target date.');
      return;
    }

    const caseId = `case-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const caseCode = `LABI-${Math.floor(100000 + Math.random() * 899999)}`;
    const encryptionKeyB64 = generateCaseEncryptionKeyB64();

    setSubmitting(true);
    try {
      await setDoc(doc(db, 'cases', caseId), {
        id: caseId,
        caseCode,
        doctorUid: profile.uid,
        doctorName: profile.displayName,
        clinicName: profile.organizationName,
        labId: selectedLab.id,
        labName: selectedLab.name,
        labOwnerUid: selectedLab.ownerUid,
        patientInitials: cleanInitials,
        patientChartRef: cleanChartRef,
        patientAgeGroup,
        restorationType,
        material,
        requiredLabWork: (
          cleanLabWork || `${restorationType} (${material}, Shade ${cleanShade})`
        ).slice(0, VALIDATION.REQUIRED_WORK_MAX),
        toothNumbers,
        shade: cleanShade.slice(0, VALIDATION.SHADE_MAX),
        scannerSource,
        scanReference: (
          cleanScanRef || `${scannerSource.split(' ')[0].toUpperCase()}-${cleanChartRef}.stl`
        ).slice(0, VALIDATION.SCAN_REF_MAX),
        xrayAttachments,
        priority,
        dueDate,
        clinicalNotes: cleanNotes.slice(0, VALIDATION.NOTES_MAX),
        status: 'submitted',
        trackingCode: '',
        courierName: '',
        courierPhone: '',
        courierEta: '',
        trackingNote: isAr ? 'في انتظار استلام المندوب من العيادة' : 'Awaiting courier pickup',
        estimatedFee: priceQuote.amount,
        currency: priceQuote.currency,
        encryptionKeyB64,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      await recordCaseAuditEvent({
        caseId,
        doctorUid: profile.uid,
        labOwnerUid: selectedLab.ownerUid,
        actorUid: profile.uid,
        actorName: profile.displayName,
        actorRole: 'doctor',
        action: 'CASE_SUBMITTED',
        summary: `Submitted ${caseCode} (${restorationType}, ${xrayAttachments.length} X-ray(s)) to ${selectedLab.name}`,
      });

      await sendCaseStatusNotification({
        recipientUid: selectedLab.ownerUid,
        senderUid: profile.uid,
        caseId,
        caseCode,
        labName: selectedLab.name,
        clinicName: profile.organizationName,
        newStatus: 'submitted',
      });

      onCreated();
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `cases/${caseId}`);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.16 }}
      className="fixed inset-0 z-50 bg-[#002B6B]/25 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="new-case-title"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.97, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.2 }}
        className="glass-modal rounded-2xl max-w-3xl w-full max-h-[92vh] flex flex-col overflow-hidden"
      >
        <div className="px-6 py-4 border-b border-[#002B6B]/10 flex items-center justify-between gap-4">
          <div>
            <h2 id="new-case-title" className="font-display text-lg font-bold text-[#002B6B]">
              {isAr ? 'روشتة معمل جديدة' : 'New Digital Lab Prescription'}
            </h2>
            <p className="text-xs text-slate-500">
              {profile.organizationName} ({profile.displayName}) ·{' '}
              {isAr
                ? 'المعامل مرتبة حسب الأقرب لعيادتك'
                : 'Laboratories sorted by proximity to your clinic'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close prescription form"
            className="p-2 text-slate-500 hover:text-[#002B6B] rounded-xl hover:bg-white/70 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6">
          {/* Lab & Patient Ref */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <label
                htmlFor="case-lab"
                className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
              >
                {isAr ? 'اختار المعمل (مرتبين بالأقرب)' : 'Assign to Dental Lab (By Proximity)'}
              </label>
              <select
                id="case-lab"
                value={labId}
                onChange={(e) => handleLabChange(e.target.value)}
                required
                className="w-full px-3 py-2 text-sm glass-input rounded-xl text-[#0B1E3B]"
              >
                {acceptingLabs.length === 0 && (
                  <option value="">
                    {isAr ? 'مفيش معامل متاحة حالياً' : 'No labs accepting cases yet'}
                  </option>
                )}
                {acceptingLabs.map((lab) => {
                  const dist = calculateDistanceKm(
                    profile.latitude,
                    profile.longitude,
                    lab.latitude,
                    lab.longitude
                  );
                  const distLabel =
                    dist !== null ? (isAr ? `${dist} كم` : `${dist} km`) : lab.city;
                  return (
                    <option key={lab.id} value={lab.id}>
                      {lab.name}
                      {ratings[lab.id] ? ` ★${ratings[lab.id].avg.toFixed(1)}` : ''} ({distLabel} ·{' '}
                      {lab.turnaroundDays}
                      {isAr ? ' أيام' : 'd'})
                    </option>
                  );
                })}
              </select>
              {selectedLab && (
                <div className="text-[11px] text-slate-500 mt-1 flex flex-wrap items-center gap-2">
                  {selectedLabDistance !== null && (
                    <span className="text-[#008C99] font-medium">
                      {isAr
                        ? `يبعد ${selectedLabDistance} كم عن عيادتك`
                        : `${selectedLabDistance} km from clinic`}
                    </span>
                  )}
                  <span aria-hidden="true">·</span>
                  <span>
                    {isAr
                      ? `التسليم خلال ${selectedLab.turnaroundDays} أيام`
                      : `${selectedLab.turnaroundDays}-day SLA`}
                  </span>
                  {ratings[selectedLab.id] && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="font-semibold text-[#8a6100]">
                        {`★ ${ratings[selectedLab.id].avg.toFixed(1)} (${ratings[selectedLab.id].count})`}
                      </span>
                    </>
                  )}
                  {selectedLab.latitude != null && selectedLab.longitude != null && (
                    <>
                      <span aria-hidden="true">·</span>
                      <a
                        href={`https://www.google.com/maps/search/?api=1&query=${selectedLab.latitude},${selectedLab.longitude}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[#002B6B] font-semibold underline"
                      >
                        {isAr ? 'افتح الموقع في خرائط جوجل' : 'Open in Google Maps'}
                      </a>
                    </>
                  )}
                  <LabGalleryStrip labId={selectedLab.id} />
                </div>
              )}
            </div>

            <div>
              <label
                htmlFor="case-initials"
                className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
              >
                {isAr ? 'حروف اسم المريض' : 'Patient Initials'}
              </label>
              <input
                id="case-initials"
                type="text"
                required
                maxLength={6}
                value={patientInitials}
                onChange={(e) => setPatientInitials(e.target.value)}
                placeholder={isAr ? 'م.ك.' : 'M.K.'}
                className="w-full px-3 py-2 text-sm glass-input rounded-xl text-[#0B1E3B]"
              />
            </div>

            <div>
              <label
                htmlFor="case-chart"
                className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
              >
                {isAr ? 'رقم ملف العيادة' : 'Chart ID'}
              </label>
              <input
                id="case-chart"
                type="text"
                required
                maxLength={VALIDATION.CHART_REF_MAX}
                value={patientChartRef}
                onChange={(e) => setPatientChartRef(e.target.value)}
                placeholder="CH-4092"
                className="w-full px-3 py-2 text-sm font-mono glass-input rounded-xl text-[#0B1E3B]"
              />
            </div>
          </div>

          {/* Tooth Chart */}
          <div>
            <label className="block text-xs font-medium text-[#0B1E3B]/80 mb-2">
              {isAr ? 'اختار الأسنان المطلوبة' : 'Target Tooth Selection'}
            </label>
            <ToothChart selectedTeeth={toothNumbers} onToggleTooth={toggleTooth} />
          </div>

          {/* Clinical Specifications */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div>
              <label
                htmlFor="case-restoration"
                className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
              >
                {isAr ? 'نوع التركيبة' : 'Restoration Type'}
              </label>
              <select
                id="case-restoration"
                value={restorationType}
                onChange={(e) => setRestorationType(e.target.value as RestorationType)}
                className="w-full px-3 py-2 text-sm glass-input rounded-xl text-[#0B1E3B]"
              >
                {RESTORATION_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {isAr ? RESTORATION_LABELS_AR[t] || t : t}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="case-material"
                className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
              >
                {isAr ? 'الخامة' : 'Material'}
              </label>
              <select
                id="case-material"
                value={material}
                onChange={(e) => setMaterial(e.target.value as MaterialType)}
                className="w-full px-3 py-2 text-sm glass-input rounded-xl text-[#0B1E3B]"
              >
                {MATERIAL_TYPES.map((m) => (
                  <option key={m} value={m}>
                    {isAr ? MATERIAL_LABELS_AR[m] || m : m}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="case-shade"
                className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
              >
                {isAr ? 'درجة اللون (Shade)' : 'Vita Shade'}
              </label>
              <select
                id="case-shade"
                value={shade}
                onChange={(e) => setShade(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono glass-input rounded-xl text-[#0B1E3B]"
              >
                {VITA_SHADES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="case-age-group"
                className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
              >
                {isAr ? 'الفئة العمرية' : 'Patient Group'}
              </label>
              <select
                id="case-age-group"
                value={patientAgeGroup}
                onChange={(e) => setPatientAgeGroup(e.target.value as 'Adult' | 'Pediatric')}
                className="w-full px-3 py-2 text-sm glass-input rounded-xl text-[#0B1E3B]"
              >
                <option value="Adult">{isAr ? 'بالغ' : 'Adult'}</option>
                <option value="Pediatric">{isAr ? 'أطفال' : 'Pediatric'}</option>
              </select>
            </div>
          </div>

          {/* Live Price Quote from Lab's Price List */}
          <div className="p-3.5 rounded-xl glass-surface flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="text-slate-700">
              {isAr
                ? `التكلفة التقديرية حسب أسعار ${selectedLab?.name || 'المعمل'} (${toothNumbers.length} سنة):`
                : `Estimated quote from ${selectedLab?.name || 'lab'} (${toothNumbers.length} unit(s)):`}
            </span>
            <span className="font-mono tabular-nums text-sm font-bold text-[#002B6B]">
              {priceQuote.amount.toLocaleString()} {priceQuote.currency === 'EGP' ? (isAr ? 'ج.م' : 'EGP') : 'USD'}
            </span>
          </div>

          <div>
            <label
              htmlFor="case-required-work"
              className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
            >
              {isAr ? 'تفاصيل الشغل المطلوب من المعمل' : 'Required Lab Work Specification'}
            </label>
            <input
              id="case-required-work"
              type="text"
              maxLength={VALIDATION.REQUIRED_WORK_MAX}
              value={requiredLabWork}
              onChange={(e) => setRequiredLabWork(e.target.value)}
              placeholder={
                isAr
                  ? 'مثال: طربوش زيركون كامل للسنة ١٤، تواصل خفيف مع المقابل'
                  : 'e.g. Full-contour zirconia crown #14, light occlusal contact'
              }
              className="w-full px-3 py-2 text-sm glass-input rounded-xl text-[#0B1E3B]"
            />
          </div>

          {/* X-Ray Upload */}
          <div className="glass-surface rounded-xl p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <div className="text-xs font-semibold text-[#002B6B]">
                  {isAr
                    ? `صور الأشعة (اختياري، بحد أقصى ${VALIDATION.XRAY_MAX_COUNT})`
                    : `Dental X-Rays & Radiographs (Max ${VALIDATION.XRAY_MAX_COUNT})`}
                </div>
                <p className="text-xs text-slate-600">
                  {isAr
                    ? 'ارفع أشعة البانوراما أو البري إبيكال (JPEG, PNG, WebP).'
                    : 'Attach periapical, bitewing, or panoramic radiographs.'}
                </p>
              </div>
              <label className="btn-glass-secondary inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#002B6B] rounded-lg cursor-pointer">
                <Upload className="w-3.5 h-3.5 text-[#00A8B5]" />
                <span>{isAr ? 'رفع صورة أشعة' : 'Upload X-Ray'}</span>
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  multiple
                  onChange={handleXrayUpload}
                  className="sr-only"
                />
              </label>
            </div>

            {xrayError && <div className="text-xs text-red-700">{xrayError}</div>}

            {xrayAttachments.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {xrayAttachments.map((xray) => (
                  <div
                    key={xray.id}
                    className="bg-white/80 border border-white/90 rounded-xl overflow-hidden shadow-xs"
                  >
                    <div className="h-24 bg-slate-900 overflow-hidden">
                      <img
                        src={xray.dataUrl}
                        alt={xray.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="px-2.5 py-2 flex items-center justify-between gap-2">
                      <span className="text-[11px] font-mono text-slate-700 truncate">
                        {xray.name}
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          setXrayAttachments((prev) => prev.filter((x) => x.id !== xray.id))
                        }
                        aria-label={`Remove ${xray.name}`}
                        className="text-slate-400 hover:text-red-600 cursor-pointer shrink-0"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Scanner & Schedule */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="sm:col-span-2">
              <label
                htmlFor="case-scanner"
                className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
              >
                {isAr ? 'طريقة أخذ المقاس / الاسكانر' : 'Intraoral Scanner / Intake'}
              </label>
              <select
                id="case-scanner"
                value={scannerSource}
                onChange={(e) => setScannerSource(e.target.value as ScannerSource)}
                className="w-full px-3 py-2 text-sm glass-input rounded-xl text-[#0B1E3B]"
              >
                {SCANNER_SOURCES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="case-priority"
                className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
              >
                {isAr ? 'الأولوية' : 'Priority'}
              </label>
              <select
                id="case-priority"
                value={priority}
                onChange={(e) => setPriority(e.target.value as 'Standard' | 'Rush')}
                className="w-full px-3 py-2 text-sm glass-input rounded-xl text-[#0B1E3B]"
              >
                <option value="Standard">{isAr ? 'عادي' : 'Standard'}</option>
                <option value="Rush">{isAr ? 'مستعجل (Rush)' : 'Rush (+Express)'}</option>
              </select>
            </div>

            <div>
              <label
                htmlFor="case-due"
                className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
              >
                {isAr ? 'ميعاد التسليم المطلوب' : 'Target Seat Date'}
              </label>
              <input
                id="case-due"
                type="date"
                required
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono tabular-nums glass-input rounded-xl text-[#0B1E3B]"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="case-scan-ref"
              className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
            >
              {isAr ? 'رقم المقاس أو ملف الـ STL' : 'Scan File / Case Portal Reference'}
            </label>
            <input
              id="case-scan-ref"
              type="text"
              maxLength={VALIDATION.SCAN_REF_MAX}
              value={scanReference}
              onChange={(e) => setScanReference(e.target.value)}
              placeholder="TRIOS-2026-4092-UPPER.stl"
              className="w-full px-3 py-2 text-sm font-mono glass-input rounded-xl text-[#0B1E3B]"
            />
          </div>

          <div>
            <label
              htmlFor="case-notes"
              className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
            >
              {isAr ? 'ملاحظات إضافية للفني' : 'Clinical Notes'}
            </label>
            <textarea
              id="case-notes"
              rows={3}
              maxLength={VALIDATION.NOTES_MAX}
              value={clinicalNotes}
              onChange={(e) => setClinicalNotes(e.target.value)}
              placeholder={
                isAr
                  ? 'أي تفاصيل عن الحواف (Margins) أو الإطباق أو لون الدعامة...'
                  : 'Light occlusal contact, chamfer margin, match adjacent shade...'
              }
              className="w-full px-3 py-2 text-sm glass-input rounded-xl text-[#0B1E3B]"
            />
          </div>

          {error && (
            <div
              role="alert"
              className="p-3 rounded-xl border border-red-200 bg-red-50/90 text-xs text-red-800"
            >
              {error}
            </div>
          )}

          <div className="pt-3 border-t border-[#002B6B]/10 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="btn-glass-secondary px-4 py-2 text-sm font-medium text-[#002B6B] rounded-xl cursor-pointer"
            >
              {isAr ? 'إلغاء' : 'Cancel'}
            </button>
            <button
              type="submit"
              disabled={submitting || acceptingLabs.length === 0}
              className="btn-glass-primary px-5 py-2 text-sm font-semibold rounded-xl disabled:opacity-60 cursor-pointer"
            >
              {submitting
                ? isAr
                  ? 'جاري الإرسال...'
                  : 'Submitting Rx...'
                : isAr
                  ? 'إرسال الحالة للمعمل'
                  : 'Submit Prescription'}
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
}
