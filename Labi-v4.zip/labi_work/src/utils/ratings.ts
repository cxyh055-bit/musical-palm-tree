import { collection, getDocs } from 'firebase/firestore';
import { db } from '../firebase';

export interface LabRatingSummary {
  avg: number;
  count: number;
}

/** Loads all ratings once and averages them per lab (fine for a pilot-sized network). */
export async function fetchLabRatings(): Promise<Record<string, LabRatingSummary>> {
  const snap = await getDocs(collection(db, 'ratings'));
  const sums: Record<string, { total: number; count: number }> = {};
  snap.forEach((d) => {
    const data = d.data() as { labId?: string; stars?: number };
    if (!data.labId || typeof data.stars !== 'number') return;
    const s = sums[data.labId] ?? { total: 0, count: 0 };
    s.total += data.stars;
    s.count += 1;
    sums[data.labId] = s;
  });
  const out: Record<string, LabRatingSummary> = {};
  for (const [labId, s] of Object.entries(sums)) {
    out[labId] = { avg: s.total / s.count, count: s.count };
  }
  return out;
}
