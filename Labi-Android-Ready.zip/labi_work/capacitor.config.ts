import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.labi.dental',
  appName: 'Labi',
  webDir: 'dist',
  android: {
    allowMixedContent: false,
  },
};

export default config;
