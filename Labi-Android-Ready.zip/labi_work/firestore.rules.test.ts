// Dirty Dozen Security Rule Verification Suite for Labi
// Documents adversarial payloads and expected PERMISSION_DENIED outcomes.

export interface DirtyDozenScenario {
  id: number;
  name: string;
  collection: string;
  operation: 'get' | 'list' | 'create' | 'update' | 'delete';
  expectedOutcome: 'PERMISSION_DENIED';
  rationale: string;
}

export const DIRTY_DOZEN_SCENARIOS: DirtyDozenScenario[] = [
  {
    id: 1,
    name: 'PII Cross-Read Attack',
    collection: 'users/userA',
    operation: 'get',
    expectedOutcome: 'PERMISSION_DENIED',
    rationale: 'User B cannot read User A private profile containing email and phone.'
  },
  {
    id: 2,
    name: 'Shadow Field Injection on User',
    collection: 'users/userA',
    operation: 'create',
    expectedOutcome: 'PERMISSION_DENIED',
    rationale: 'hasOnly() rejects extra shadow keys such as isAdmin: true.'
  },
  {
    id: 3,
    name: 'Unverified Email Write',
    collection: 'labs/lab1',
    operation: 'create',
    expectedOutcome: 'PERMISSION_DENIED',
    rationale: 'isVerifiedUser() enforces email_verified == true on all writes.'
  },
  {
    id: 4,
    name: 'Lab Owner Spoofing',
    collection: 'labs/lab1',
    operation: 'create',
    expectedOutcome: 'PERMISSION_DENIED',
    rationale: 'isValidLab enforces ownerUid == request.auth.uid.'
  },
  {
    id: 5,
    name: 'Orphaned Case Creation',
    collection: 'cases/case1',
    operation: 'create',
    expectedOutcome: 'PERMISSION_DENIED',
    rationale: 'exists(/labs/$(labId)) blocks cases referencing non-existent labs.'
  },
  {
    id: 6,
    name: 'Lab Owner Spoofing on Case',
    collection: 'cases/case1',
    operation: 'create',
    expectedOutcome: 'PERMISSION_DENIED',
    rationale: 'get(/labs/$(labId)).data.ownerUid == incoming().labOwnerUid prevents misrouting.'
  },
  {
    id: 7,
    name: 'Pre-Accepted Case Creation',
    collection: 'cases/case1',
    operation: 'create',
    expectedOutcome: 'PERMISSION_DENIED',
    rationale: 'Cases must enter workflow strictly with status == submitted.'
  },
  {
    id: 8,
    name: 'State Shortcutting (Doctor self-shipping)',
    collection: 'cases/case1',
    operation: 'update',
    expectedOutcome: 'PERMISSION_DENIED',
    rationale: 'Action-based update limits doctors to pre-production edits or post-ship confirmation.'
  },
  {
    id: 9,
    name: 'Terminal State Mutation',
    collection: 'cases/case1',
    operation: 'update',
    expectedOutcome: 'PERMISSION_DENIED',
    rationale: 'existing().status != delivered locks completed cases for non-admins.'
  },
  {
    id: 10,
    name: 'Immutable Field Tampering',
    collection: 'cases/case1',
    operation: 'update',
    expectedOutcome: 'PERMISSION_DENIED',
    rationale: 'doctorUid, labId, labOwnerUid, caseCode, and createdAt are immutable.'
  },
  {
    id: 11,
    name: 'Path ID Poisoning',
    collection: 'cases/bad$id',
    operation: 'create',
    expectedOutcome: 'PERMISSION_DENIED',
    rationale: 'isValidId enforces ^[a-zA-Z0-9_\\-]+$ and <= 128 characters.'
  },
  {
    id: 12,
    name: 'Subcollection Message Spoofing',
    collection: 'cases/case1/messages/msg1',
    operation: 'create',
    expectedOutcome: 'PERMISSION_DENIED',
    rationale: 'Master Gate verifies parent case participants and senderUid == request.auth.uid.'
  }
];
