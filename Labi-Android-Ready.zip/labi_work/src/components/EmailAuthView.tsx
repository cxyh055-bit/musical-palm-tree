import { useState, type FormEvent } from 'react';
import { Capacitor } from '@capacitor/core';
import {
  createUserWithEmailAndPassword,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
} from 'firebase/auth';
import { auth, googleProvider } from '../firebase';
import { AuthShell } from './AuthShell';

function arabicError(err: unknown): string {
  const code = (err as { code?: string })?.code ?? '';
  switch (code) {
    case 'auth/invalid-email':
      return 'الإيميل مش مكتوب صح.';
    case 'auth/missing-password':
      return 'اكتب الباسورد.';
    case 'auth/weak-password':
      return 'الباسورد ضعيف، لازم 6 حروف أو أرقام على الأقل.';
    case 'auth/email-already-in-use':
      return 'الإيميل ده مسجل قبل كده، جرّب تسجيل الدخول.';
    case 'auth/invalid-credential':
    case 'auth/wrong-password':
    case 'auth/user-not-found':
      return 'الإيميل أو الباسورد غلط.';
    case 'auth/too-many-requests':
      return 'محاولات كتير، استنى شوية وجرّب تاني.';
    case 'auth/network-request-failed':
      return 'مفيش اتصال بالإنترنت.';
    case 'auth/operation-not-allowed':
      return 'الدخول بالإيميل مش مفعّل في Firebase. فعّله من Authentication ثم Sign-in method.';
    default:
      return err instanceof Error ? err.message : 'حصلت مشكلة، جرّب تاني.';
  }
}

interface Props {
  initialMode?: 'login' | 'signup';
  onBack: () => void;
}

export function EmailAuthView({ initialMode = 'login', onBack }: Props) {
  const [mode, setMode] = useState<'login' | 'signup'>(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setInfo(null);
    try {
      if (mode === 'signup') {
        const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
        await sendEmailVerification(cred.user);
      } else {
        await signInWithEmailAndPassword(auth, email.trim(), password);
      }
    } catch (err) {
      setError(arabicError(err));
    } finally {
      setBusy(false);
    }
  };

  const reset = async () => {
    setError(null);
    setInfo(null);
    if (!email.trim()) {
      setError('اكتب الإيميل الأول.');
      return;
    }
    try {
      await sendPasswordResetEmail(auth, email.trim());
      setInfo('بعتنالك رسالة على الإيميل لتغيير الباسورد.');
    } catch (err) {
      setError(arabicError(err));
    }
  };

  const google = async () => {
    setBusy(true);
    setError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      setError(arabicError(err));
    } finally {
      setBusy(false);
    }
  };

  const input =
    'w-full rounded-2xl border border-[#CFE0EE] bg-white px-4 py-3.5 text-base text-[#0B1E3B] placeholder:text-[#8aa0b8] focus:outline-none focus:ring-2 focus:ring-[#00A8B5]';

  return (
    <AuthShell
      title={mode === 'login' ? 'أهلاً بيك تاني' : 'إنشاء حساب جديد'}
      subtitle={mode === 'login' ? 'سجّل دخولك وكمّل شغلك' : 'ابدأ تبعت وتستقبل شغل في دقيقة'}
    >
      <form onSubmit={submit} className="space-y-3">
        <input
          type="email"
          dir="ltr"
          autoComplete="email"
          placeholder="الإيميل"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className={input}
          required
        />
        <input
          type="password"
          dir="ltr"
          autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
          placeholder="الباسورد"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className={input}
          required
        />
        {error && (
          <div role="alert" className="rounded-2xl border border-red-200 bg-red-50 p-3 text-sm text-red-800">
            {error}
          </div>
        )}
        {info && (
          <div className="rounded-2xl border border-teal-200 bg-teal-50 p-3 text-sm text-teal-900">{info}</div>
        )}
        <button
          type="submit"
          disabled={busy}
          className="w-full rounded-2xl bg-[#002B6B] py-3.5 text-[15px] font-bold text-white shadow-[0_8px_20px_rgba(0,43,107,0.3)] disabled:opacity-60"
        >
          {busy ? 'استنى...' : mode === 'login' ? 'دخول' : 'إنشاء الحساب'}
        </button>
      </form>
      <div className="mt-4 flex justify-between text-sm text-[#002B6B]">
        <button
          type="button"
          onClick={() => {
            setMode(mode === 'login' ? 'signup' : 'login');
            setError(null);
            setInfo(null);
          }}
          className="font-semibold underline"
        >
          {mode === 'login' ? 'معنديش حساب' : 'عندي حساب'}
        </button>
        {mode === 'login' && (
          <button type="button" onClick={reset} className="underline">
            نسيت الباسورد
          </button>
        )}
      </div>
      {!Capacitor.isNativePlatform() && (
        <button
          type="button"
          onClick={google}
          disabled={busy}
          className="mt-5 w-full rounded-2xl border border-[#CFE0EE] bg-white py-3 text-sm font-medium text-[#002B6B]"
        >
          الدخول بحساب جوجل
        </button>
      )}
      <button type="button" onClick={onBack} className="mx-auto mt-5 block text-sm text-[#4b6483] underline">
        رجوع
      </button>
    </AuthShell>
  );
}
