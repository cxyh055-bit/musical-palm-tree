import { useEffect, useMemo, useRef, useState, type ChangeEvent, type FormEvent } from 'react';
import type { User } from 'firebase/auth';
import {
  collection,
  doc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import {
  AlertCircle,
  BarChart3,
  Bell,
  Building2,
  Check,
  CheckCircle2,
  Clock,
  FilePlus2,
  FlaskConical,
  Globe,
  Layers,
  LogOut,
  MapPin,
  Menu,
  Receipt,
  Search,
  Settings2,
  Sparkles,
  Truck,
  Upload,
  X,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  MATERIAL_LABELS_AR,
  PROXIMITY_LABELS,
  RESTORATION_LABELS_AR,
  STATUS_LABELS_BI,
  useLang,
} from '../i18n';
import {
  DENTAL_SPECIALTIES,
  LAB_ACCREDITATIONS_LIST,
  LAB_IMAGES,
  LAB_SERVICES_LIST,
  sanitizeIdSegment,
  VALIDATION,
  type CaseNotification,
  type CaseStatus,
  type DentalCase,
  type DentalLab,
  type DigitalInvoice,
  type UserProfile,
  type UserRole,
} from '../types';
import { recordCaseAuditEvent } from '../utils/auditLog';
import { generateCaseEncryptionKeyB64 } from '../utils/crypto';
import { calculateDistanceKm, getProximityBucket, type ProximityBucket } from '../utils/geo';
import { processImageUpload } from '../utils/imageUpload';
import { sendCaseStatusNotification } from '../utils/notifications';
import { BrandLogo } from './BrandLogo';
import { CaseDetailDrawer } from './CaseDetailDrawer';
import { CreateInvoiceModal } from './CreateInvoiceModal';
import { InvoicesView } from './InvoicesView';
import { LabAnalyticsDashboard } from './LabAnalyticsDashboard';
import { LabProfileEditor } from './LabProfileEditor';
import { LocationPicker } from './LocationPicker';
import { NewCaseModal } from './NewCaseModal';
import { SafeImage } from './SafeImage';

interface WorkspaceProps {
  user: User;
  profile: UserProfile;
  onSignOut: () => void;
}

type NavTab = 'cases' | 'invoices' | 'labs' | 'analytics' | 'my-lab' | 'account';
type StatusFilter =
  | 'all'
  | 'submitted'
  | 'courier'
  | 'received'
  | 'in_progress'
  | 'awaiting_approval'
  | 'delivery'
  | 'completed'
  | 'revision';

function StatusIndicator({ status }: { status: CaseStatus }) {
  const { lang } = useLang();
  const label = STATUS_LABELS_BI[lang][status];

  if (status === 'completed' || status === 'delivered') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700">
        <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
        <span>{label}</span>
      </span>
    );
  }
  if (status === 'revision_requested') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-700">
        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
        <span>{label}</span>
      </span>
    );
  }
  if (
    status === 'courier_picked_up' ||
    status === 'courier_arrived_lab' ||
    status === 'out_for_delivery' ||
    status === 'shipped'
  ) {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#008C99]">
        <Truck className="w-3.5 h-3.5 shrink-0" />
        <span>{label}</span>
      </span>
    );
  }
  if (status === 'awaiting_approval' || status === 'quality_check') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#002B6B]">
        <Clock className="w-3.5 h-3.5 shrink-0" />
        <span>{label}</span>
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-700">
      <Clock className="w-3.5 h-3.5 text-slate-500 shrink-0" />
      <span>{label}</span>
    </span>
  );
}

export function Workspace({ user, profile, onSignOut }: WorkspaceProps) {
  const { lang, setLang } = useLang();
  const isAr = lang === 'ar';

  const [activeTab, setActiveTab] = useState<NavTab>('cases');
  const [perspective, setPerspective] = useState<UserRole>(profile.role);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [labs, setLabs] = useState<DentalLab[]>([]);
  const [ownLabs, setOwnLabs] = useState<DentalLab[]>([]);
  const [loadingLabs, setLoadingLabs] = useState(true);

  const [doctorCases, setDoctorCases] = useState<DentalCase[]>([]);
  const [labCases, setLabCases] = useState<DentalCase[]>([]);
  const [loadingCases, setLoadingCases] = useState(true);

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [labSpecialtyFilter, setLabSpecialtyFilter] = useState('All');

  const [showNewCaseModal, setShowNewCaseModal] = useState(false);
  const [preselectedLabId, setPreselectedLabId] = useState<string | undefined>(undefined);
  const [selectedCaseId, setSelectedCaseId] = useState<string | null>(null);
  const [seedingSample, setSeedingSample] = useState(false);

  const [doctorInvoices, setDoctorInvoices] = useState<DigitalInvoice[]>([]);
  const [labInvoices, setLabInvoices] = useState<DigitalInvoice[]>([]);
  const [loadingInvoices, setLoadingInvoices] = useState(true);
  const [invoiceTarget, setInvoiceTarget] = useState<{
    dentalCase: DentalCase;
    existing?: DigitalInvoice | null;
  } | null>(null);
  const [focusedInvoiceId, setFocusedInvoiceId] = useState<string | null>(null);

  const [notifications, setNotifications] = useState<CaseNotification[]>([]);
  const [notifOpen, setNotifOpen] = useState(false);
  const [liveToasts, setLiveToasts] = useState<CaseNotification[]>([]);
  const initialNotifLoadRef = useRef(true);
  const seenNotifIdsRef = useRef<Set<string>>(new Set());

  // Extended Account & Profile state
  const [acctName, setAcctName] = useState(profile.displayName);
  const [acctOrg, setAcctOrg] = useState(profile.organizationName);
  const [acctAddress, setAcctAddress] = useState(profile.clinicAddress || '');
  const [acctCity, setAcctCity] = useState(profile.city || 'القاهرة');
  const [acctArea, setAcctArea] = useState(profile.area || 'المعادي، القاهرة');
  const [acctLat, setAcctLat] = useState<number>(profile.latitude ?? 29.9602);
  const [acctLng, setAcctLng] = useState<number>(profile.longitude ?? 31.2569);
  const [acctLicense, setAcctLicense] = useState(profile.licenseNumber || '');
  const [acctPhone, setAcctPhone] = useState(profile.phone || '');
  const [acctRole, setAcctRole] = useState<UserRole>(profile.role);
  const [acctSpecialty, setAcctSpecialty] = useState(
    profile.dentalSpecialty || DENTAL_SPECIALTIES[0]
  );
  const [acctYearsExp, setAcctYearsExp] = useState(profile.yearsExperience ?? 8);
  const [acctTurnaround, setAcctTurnaround] = useState(profile.turnaroundDays ?? 4);
  const [acctServices, setAcctServices] = useState<string[]>(
    profile.services || ['Esthetic Ceramics', 'Monolithic Zirconia']
  );
  const [acctAccreditations, setAcctAccreditations] = useState<string[]>(
    profile.accreditations || ['CDT Certified Lab']
  );
  const [acctPhotoUrl, setAcctPhotoUrl] = useState(profile.profilePhotoUrl || '');
  const [acctPhotoError, setAcctPhotoError] = useState<string | null>(null);
  const [savingAccount, setSavingAccount] = useState(false);
  const [accountSaved, setAccountSaved] = useState(false);

  useEffect(() => {
    setAcctName(profile.displayName);
    setAcctOrg(profile.organizationName);
    setAcctAddress(profile.clinicAddress || '');
    setAcctCity(profile.city || 'القاهرة');
    setAcctArea(profile.area || 'المعادي، القاهرة');
    setAcctLat(profile.latitude ?? 29.9602);
    setAcctLng(profile.longitude ?? 31.2569);
    setAcctLicense(profile.licenseNumber || '');
    setAcctPhone(profile.phone || '');
    setAcctRole(profile.role);
    setAcctPhotoUrl(profile.profilePhotoUrl || '');
  }, [profile]);

  useEffect(() => {
    const qOpen = query(collection(db, 'labs'), where('acceptingCases', '==', true));
    const unsubOpen = onSnapshot(
      qOpen,
      (snap) => {
        setLabs(snap.docs.map((d) => d.data() as DentalLab));
        setLoadingLabs(false);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'labs');
      }
    );

    const qOwn = query(collection(db, 'labs'), where('ownerUid', '==', user.uid));
    const unsubOwn = onSnapshot(
      qOwn,
      (snap) => {
        setOwnLabs(snap.docs.map((d) => d.data() as DentalLab));
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'labs');
      }
    );

    return () => {
      unsubOpen();
      unsubOwn();
    };
  }, [user.uid]);

  useEffect(() => {
    const qDoc = query(collection(db, 'cases'), where('doctorUid', '==', user.uid));
    const qLab = query(collection(db, 'cases'), where('labOwnerUid', '==', user.uid));

    let docReady = false;
    let labReady = false;

    const unsubDoc = onSnapshot(
      qDoc,
      (snap) => {
        setDoctorCases(snap.docs.map((d) => d.data() as DentalCase));
        docReady = true;
        if (docReady && labReady) setLoadingCases(false);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'cases');
      }
    );

    const unsubLab = onSnapshot(
      qLab,
      (snap) => {
        setLabCases(snap.docs.map((d) => d.data() as DentalCase));
        labReady = true;
        if (docReady && labReady) setLoadingCases(false);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'cases');
      }
    );

    return () => {
      unsubDoc();
      unsubLab();
    };
  }, [user.uid]);

  useEffect(() => {
    const qDocInv = query(collection(db, 'invoices'), where('doctorUid', '==', user.uid));
    const qLabInv = query(collection(db, 'invoices'), where('labOwnerUid', '==', user.uid));

    let docReady = false;
    let labReady = false;

    const unsubDocInv = onSnapshot(
      qDocInv,
      (snap) => {
        setDoctorInvoices(snap.docs.map((d) => d.data() as DigitalInvoice));
        docReady = true;
        if (docReady && labReady) setLoadingInvoices(false);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'invoices');
      }
    );

    const unsubLabInv = onSnapshot(
      qLabInv,
      (snap) => {
        setLabInvoices(snap.docs.map((d) => d.data() as DigitalInvoice));
        labReady = true;
        if (docReady && labReady) setLoadingInvoices(false);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'invoices');
      }
    );

    return () => {
      unsubDocInv();
      unsubLabInv();
    };
  }, [user.uid]);

  useEffect(() => {
    const qNotifs = query(
      collection(db, 'notifications'),
      where('recipientUid', '==', user.uid)
    );
    const unsubNotifs = onSnapshot(
      qNotifs,
      (snap) => {
        const items = snap.docs
          .map((d) => d.data() as CaseNotification)
          .sort((a, b) => (b.createdAt?.toMillis?.() ?? 0) - (a.createdAt?.toMillis?.() ?? 0));

        if (initialNotifLoadRef.current) {
          for (const item of items) seenNotifIdsRef.current.add(item.id);
          initialNotifLoadRef.current = false;
        } else {
          const newlyAdded = items.filter(
            (item) => !item.read && !seenNotifIdsRef.current.has(item.id)
          );
          for (const item of items) seenNotifIdsRef.current.add(item.id);
          if (newlyAdded.length > 0) {
            setLiveToasts((prev) => [...newlyAdded.slice(0, 3), ...prev].slice(0, 4));
          }
        }

        setNotifications(items);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'notifications');
      }
    );

    return () => unsubNotifs();
  }, [user.uid]);

  useEffect(() => {
    if (liveToasts.length === 0) return;
    const timer = window.setTimeout(() => {
      setLiveToasts((prev) => prev.slice(0, -1));
    }, 8000);
    return () => window.clearTimeout(timer);
  }, [liveToasts]);

  const allDirectoryLabs = useMemo(() => {
    const map = new Map<string, DentalLab>();
    for (const l of labs) map.set(l.id, l);
    for (const l of ownLabs) map.set(l.id, l);
    return Array.from(map.values()).sort((a, b) => a.name.localeCompare(b.name));
  }, [labs, ownLabs]);

  const myPrimaryLab = ownLabs[0] || null;

  const perspectiveCases = useMemo(() => {
    const source = perspective === 'lab' ? labCases : doctorCases;
    return [...source].sort((a, b) => {
      const ta = a.updatedAt?.toMillis?.() ?? 0;
      const tb = b.updatedAt?.toMillis?.() ?? 0;
      return tb - ta;
    });
  }, [perspective, doctorCases, labCases]);

  const selectedCase = useMemo(() => {
    const all = [...doctorCases, ...labCases];
    return all.find((c) => c.id === selectedCaseId) || null;
  }, [doctorCases, labCases, selectedCaseId]);

  const allInvoices = useMemo(() => {
    const map = new Map<string, DigitalInvoice>();
    for (const inv of doctorInvoices) map.set(inv.id, inv);
    for (const inv of labInvoices) map.set(inv.id, inv);
    return Array.from(map.values()).sort((a, b) => {
      const ta = a.updatedAt?.toMillis?.() ?? a.createdAt?.toMillis?.() ?? 0;
      const tb = b.updatedAt?.toMillis?.() ?? b.createdAt?.toMillis?.() ?? 0;
      return tb - ta;
    });
  }, [doctorInvoices, labInvoices]);

  const selectedCaseInvoice = useMemo(() => {
    if (!selectedCase) return null;
    return allInvoices.find((inv) => inv.caseId === selectedCase.id) || null;
  }, [allInvoices, selectedCase]);

  const filteredCases = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return perspectiveCases.filter((c) => {
      if (statusFilter === 'submitted' && c.status !== 'submitted') return false;
      if (
        statusFilter === 'courier' &&
        !['courier_picked_up', 'courier_arrived_lab'].includes(c.status)
      ) {
        return false;
      }
      if (statusFilter === 'received' && !['received', 'accepted'].includes(c.status)) {
        return false;
      }
      if (
        statusFilter === 'in_progress' &&
        !['in_progress', 'in_design', 'milling'].includes(c.status)
      ) {
        return false;
      }
      if (
        statusFilter === 'awaiting_approval' &&
        !['awaiting_approval', 'quality_check'].includes(c.status)
      ) {
        return false;
      }
      if (
        statusFilter === 'delivery' &&
        !['out_for_delivery', 'shipped'].includes(c.status)
      ) {
        return false;
      }
      if (statusFilter === 'completed' && !['completed', 'delivered'].includes(c.status)) {
        return false;
      }
      if (statusFilter === 'revision' && c.status !== 'revision_requested') return false;

      if (!q) return true;
      return (
        c.caseCode.toLowerCase().includes(q) ||
        c.patientChartRef.toLowerCase().includes(q) ||
        c.labName.toLowerCase().includes(q) ||
        c.clinicName.toLowerCase().includes(q) ||
        c.restorationType.toLowerCase().includes(q) ||
        (c.trackingNote || '').toLowerCase().includes(q) ||
        c.toothNumbers.some((t) => t.includes(q))
      );
    });
  }, [perspectiveCases, statusFilter, searchQuery]);

  // Proximity-sorted and bucketed lab directory
  const groupedLabs = useMemo(() => {
    const matching = allDirectoryLabs.filter((l) => {
      if (labSpecialtyFilter !== 'All' && !l.specialties.includes(labSpecialtyFilter)) {
        return false;
      }
      return true;
    });

    const withDist = matching
      .map((lab) => {
        const distanceKm = calculateDistanceKm(
          profile.latitude,
          profile.longitude,
          lab.latitude,
          lab.longitude
        );
        return {
          lab,
          distanceKm,
          bucket: getProximityBucket(distanceKm),
        };
      })
      .sort((a, b) => {
        if (a.distanceKm !== null && b.distanceKm !== null) {
          return a.distanceKm - b.distanceKm;
        }
        if (a.distanceKm !== null) return -1;
        if (b.distanceKm !== null) return 1;
        return a.lab.name.localeCompare(b.lab.name);
      });

    const buckets: { key: ProximityBucket; items: typeof withDist }[] = [
      { key: 'nearest', items: withDist.filter((x) => x.bucket === 'nearest') },
      { key: 'nearby', items: withDist.filter((x) => x.bucket === 'nearby') },
      { key: 'regional', items: withDist.filter((x) => x.bucket === 'regional') },
      { key: 'unknown', items: withDist.filter((x) => x.bucket === 'unknown') },
    ];

    return { totalCount: withDist.length, buckets: buckets.filter((b) => b.items.length > 0) };
  }, [allDirectoryLabs, labSpecialtyFilter, profile.latitude, profile.longitude]);

  const metrics = useMemo(() => {
    const activeCount = perspectiveCases.filter(
      (c) => !['completed', 'delivered'].includes(c.status)
    ).length;
    const inTransitCount = perspectiveCases.filter((c) =>
      [
        'courier_picked_up',
        'courier_arrived_lab',
        'out_for_delivery',
        'shipped',
        'awaiting_approval',
        'quality_check',
      ].includes(c.status)
    ).length;
    const completedCount = perspectiveCases.filter((c) =>
      ['completed', 'delivered'].includes(c.status)
    ).length;
    const totalValue = perspectiveCases.reduce((sum, c) => sum + (c.estimatedFee || 0), 0);
    return { activeCount, inTransitCount, completedCount, totalValue };
  }, [perspectiveCases]);

  const handleSeedSampleNetwork = async () => {
    setSeedingSample(true);
    const uidSlug = sanitizeIdSegment(user.uid).slice(0, 24);
    const sampleLabs = [
      {
        id: `lab-maadi-${uidSlug}`,
        ownerUid: user.uid,
        name: 'معمل ديجيتال سمايل — المعادي',
        city: 'القاهرة',
        area: 'المعادي، القاهرة',
        latitude: 29.9602,
        longitude: 31.2569,
        turnaroundDays: 3,
        expressHours: 24,
        specialties: ['Esthetic Ceramics', 'Monolithic Zirconia'],
        materials: ['Layered E.max', 'Monolithic Zirconia', 'PMMA Provisional'],
        scannerSupport: ['3Shape TRIOS', 'iTero Element', 'Medit i700'],
        accreditations: ['CDT Certified Lab', 'ISO 13485 Medical Devices', '3Shape Certified Partner'],
        priceTier: 'Boutique',
        priceList: {
          zirconiaCrown: 1900,
          emaxVeneer: 2600,
          implantAbutment: 3600,
          clearAligner: 6500,
          denture: 4500,
          rushFee: 450,
          currency: 'EGP',
        },
        summary:
          'عدسات فينير إيماكس هاند ليرد وزركونيا متعددة الطبقات مع مندوب سريع جوه المعادي ووسط البلد.',
        imageKey: 'ceramics',
        acceptingCases: true,
      },
      {
        id: `lab-nasr-${uidSlug}`,
        ownerUid: user.uid,
        name: 'معمل إيليت CAD/CAM — مدينة نصر',
        city: 'القاهرة',
        area: 'مدينة نصر، القاهرة',
        latitude: 30.0511,
        longitude: 31.3656,
        turnaroundDays: 2,
        expressHours: 18,
        specialties: ['Monolithic Zirconia', 'Clear Aligners'],
        materials: ['Monolithic Zirconia', 'Thermoformed PETG', '3D Printed Resin'],
        scannerSupport: ['3Shape TRIOS', 'Dentsply Primescan', 'Medit i700'],
        accreditations: ['FDA Registered Facility', '3Shape Certified Partner'],
        priceTier: 'Standard',
        priceList: {
          zirconiaCrown: 1550,
          emaxVeneer: 2200,
          implantAbutment: 3100,
          clearAligner: 5800,
          denture: 3900,
          rushFee: 350,
          currency: 'EGP',
        },
        summary:
          'مركز تفريز ديجيتال 5-axis تسليم سريع خلال 18–48 ساعة للطرابيش والنايت جارد والتقويم الشفاف.',
        imageKey: 'cad',
        acceptingCases: true,
      },
      {
        id: `lab-zayed-${uidSlug}`,
        ownerUid: user.uid,
        name: 'معمل أرك للزراعة — الشيخ زايد',
        city: 'الجيزة',
        area: 'الشيخ زايد، الجيزة',
        latitude: 30.0226,
        longitude: 30.9854,
        turnaroundDays: 5,
        expressHours: 36,
        specialties: ['Implant Prosthetics', 'Full-Arch All-on-4'],
        materials: ['Titanium Custom', 'Monolithic Zirconia', 'PFM'],
        scannerSupport: ['3Shape TRIOS', 'iTero Element', 'Dentsply Primescan'],
        accreditations: ['ISO 13485 Medical Devices', 'NADL Member', 'DAMAS Accredited'],
        priceTier: 'Enterprise',
        priceList: {
          zirconiaCrown: 2100,
          emaxVeneer: 2800,
          implantAbutment: 3900,
          clearAligner: 7000,
          denture: 5200,
          rushFee: 600,
          currency: 'EGP',
        },
        summary:
          'دعامات تيتانيوم مخصصة وتركيبات زراعة كاملة All-on-4 وجايد جراحي 3D لكل عيادات غرب القاهرة.',
        imageKey: 'implants',
        acceptingCases: true,
      },
    ];

    try {
      for (const lab of sampleLabs) {
        await setDoc(doc(db, 'labs', lab.id), {
          ...lab,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }

      const today = new Date();
      const plusDays = (n: number) => {
        const d = new Date(today);
        d.setDate(d.getDate() + n);
        return d.toISOString().slice(0, 10);
      };

      const sampleCases: {
        base: Record<string, unknown>;
        liveUpdate?: {
          status: CaseStatus;
          courierName: string;
          courierPhone: string;
          courierEta: string;
          trackingNote: string;
          trackingCode: string;
        };
      }[] = [
        {
          base: {
            id: `case-sample-1-${uidSlug}`,
            caseCode: 'LABI-260101',
            doctorUid: user.uid,
            doctorName: profile.displayName,
            clinicName: profile.organizationName,
            labId: sampleLabs[0].id,
            labName: sampleLabs[0].name,
            labOwnerUid: user.uid,
            patientInitials: 'م.ك',
            patientChartRef: 'CH-4092',
            patientAgeGroup: 'Adult',
            restorationType: 'Veneer',
            material: 'Layered E.max',
            requiredLabWork: '4 عدسات فينير إيماكس أمامي (#7–#10) مطابقة درجة BL3',
            toothNumbers: ['7', '8', '9', '10'],
            shade: 'BL3',
            scannerSource: '3Shape TRIOS',
            scanReference: 'TRIOS-4092-ANTERIOR.stl',
            xrayAttachments: [],
            priority: 'Standard',
            dueDate: plusDays(3),
            clinicalNotes: 'مراعاة شفافية الحافة القاطعة ومقاس خفيف بين الأسنان.',
            status: 'submitted',
            trackingCode: 'EG-MAADI-101',
            courierName: 'كريم عادل',
            courierPhone: '01092341122',
            courierEta: 'وصل المعمل',
            trackingNote: 'المندوب وصل المعمل وبنسلم الشغل للفني.',
            estimatedFee: 10400,
            currency: 'EGP',
            encryptionKeyB64: generateCaseEncryptionKeyB64(),
          },
          liveUpdate: {
            status: 'courier_arrived_lab',
            courierName: 'كريم عادل',
            courierPhone: '01092341122',
            courierEta: 'وصل المعمل',
            trackingNote: 'المندوب وصل المعمل دلوقتي وبنسلم المقاس للفني المسؤول.',
            trackingCode: 'EG-MAADI-101',
          },
        },
        {
          base: {
            id: `case-sample-2-${uidSlug}`,
            caseCode: 'LABI-260102',
            doctorUid: user.uid,
            doctorName: profile.displayName,
            clinicName: profile.organizationName,
            labId: sampleLabs[1].id,
            labName: sampleLabs[1].name,
            labOwnerUid: user.uid,
            patientInitials: 'ر.ت',
            patientChartRef: 'CH-3814',
            patientAgeGroup: 'Adult',
            restorationType: 'Crown',
            material: 'Monolithic Zirconia',
            requiredLabWork: 'طربوش زيركون كامل #14 مستعجل تسليم 24 ساعة',
            toothNumbers: ['14'],
            shade: 'A2',
            scannerSource: 'Dentsply Primescan',
            scanReference: 'PRIMESCAN-3814-UL6.ply',
            xrayAttachments: [],
            priority: 'Rush',
            dueDate: plusDays(1),
            clinicalNotes: 'تحضير شامفر واضح. تقليل الـ occlusal contact بمقدار 0.2 مم.',
            status: 'submitted',
            trackingCode: 'EG-NASR-204',
            courierName: 'محمود سعيد',
            courierPhone: '01145678901',
            courierEta: 'خلال 25 دقيقة',
            trackingNote: 'الدليفري جاي لك دلوقتي بالشغل على العيادة.',
            estimatedFee: 1900,
            currency: 'EGP',
            encryptionKeyB64: generateCaseEncryptionKeyB64(),
          },
          liveUpdate: {
            status: 'out_for_delivery',
            courierName: 'محمود سعيد',
            courierPhone: '01145678901',
            courierEta: 'خلال 25 دقيقة',
            trackingNote: 'الدليفري جاي لك دلوقتي بالشغل على العيادة — تقدر تبلغ العميل يجهز.',
            trackingCode: 'EG-NASR-204',
          },
        },
        {
          base: {
            id: `case-sample-3-${uidSlug}`,
            caseCode: 'LABI-260103',
            doctorUid: user.uid,
            doctorName: profile.displayName,
            clinicName: profile.organizationName,
            labId: sampleLabs[2].id,
            labName: sampleLabs[2].name,
            labOwnerUid: user.uid,
            patientInitials: 'س.ل',
            patientChartRef: 'CH-5120',
            patientAgeGroup: 'Adult',
            restorationType: 'Implant Abutment',
            material: 'Titanium Custom',
            requiredLabWork: 'دعامة تيتانيوم كاستم + طربوش زيركون #30 (Straumann BL RC)',
            toothNumbers: ['30'],
            shade: 'A3',
            scannerSource: 'iTero Element',
            scanReference: 'ITERO-5120-SCANBODY.stl',
            xrayAttachments: [],
            priority: 'Standard',
            dueDate: plusDays(5),
            clinicalNotes: 'Scanbody راكب كويس، فتحة المسمار في نص الضرس.',
            status: 'submitted',
            trackingCode: 'EG-ZAYED-309',
            courierName: 'إسلام طارق',
            courierPhone: '01288990011',
            courierEta: 'تحت التصنيع',
            trackingNote: 'المعمل استلم الشغل وشغال فيه حالياً (تصميم CAD وصب الموديل).',
            estimatedFee: 3900,
            currency: 'EGP',
            encryptionKeyB64: generateCaseEncryptionKeyB64(),
          },
          liveUpdate: {
            status: 'in_progress',
            courierName: 'إسلام طارق',
            courierPhone: '01288990011',
            courierEta: 'تحت التصنيع',
            trackingNote: 'المعمل استلم الشغل وشغال فيه حالياً في وحدة الـ CAD/CAM.',
            trackingCode: 'EG-ZAYED-309',
          },
        },
        {
          base: {
            id: `case-sample-4-${uidSlug}`,
            caseCode: 'LABI-260104',
            doctorUid: user.uid,
            doctorName: profile.displayName,
            clinicName: profile.organizationName,
            labId: sampleLabs[0].id,
            labName: sampleLabs[0].name,
            labOwnerUid: user.uid,
            patientInitials: 'ن.ع',
            patientChartRef: 'CH-4410',
            patientAgeGroup: 'Adult',
            restorationType: 'Bridge',
            material: 'Monolithic Zirconia',
            requiredLabWork: 'كوبري زيركون 3 وحدات (#19–#21)',
            toothNumbers: ['19', '20', '21'],
            shade: 'A2',
            scannerSource: '3Shape TRIOS',
            scanReference: 'TRIOS-4410-BRIDGE.stl',
            xrayAttachments: [],
            priority: 'Standard',
            dueDate: plusDays(3),
            clinicalNotes: 'تأكد من قوة الاتصال بين الوحدات والمسافة اللثوية.',
            status: 'submitted',
            trackingCode: 'EG-MAADI-108',
            courierName: 'كريم عادل',
            courierPhone: '01092341122',
            courierEta: 'تم التسليم',
            trackingNote: 'تم تسليم الحالة للعيادة بنجاح.',
            estimatedFee: 6270,
            currency: 'EGP',
            encryptionKeyB64: generateCaseEncryptionKeyB64(),
          },
          liveUpdate: {
            status: 'completed',
            courierName: 'كريم عادل',
            courierPhone: '01092341122',
            courierEta: 'تم التسليم',
            trackingNote: 'الشغل وصل العيادة بالسلامة والعميل جاهز يركب دلوقتي.',
            trackingCode: 'EG-MAADI-108',
          },
        },
        {
          base: {
            id: `case-sample-5-${uidSlug}`,
            caseCode: 'LABI-260105',
            doctorUid: user.uid,
            doctorName: profile.displayName,
            clinicName: profile.organizationName,
            labId: sampleLabs[1].id,
            labName: sampleLabs[1].name,
            labOwnerUid: user.uid,
            patientInitials: 'ي.ح',
            patientChartRef: 'CH-4782',
            patientAgeGroup: 'Adult',
            restorationType: 'Clear Aligner',
            material: 'Thermoformed PETG',
            requiredLabWork: 'طقم تقويم شفاف فك علوي وسفلي (12 مرحلة)',
            toothNumbers: ['6', '7', '8', '9', '10', '11'],
            shade: 'A1',
            scannerSource: 'Medit i700',
            scanReference: 'MEDIT-4782-ALIGNER.stl',
            xrayAttachments: [],
            priority: 'Standard',
            dueDate: plusDays(2),
            clinicalNotes: 'حالة تجميل أمامية بسيطة، متابعة خط الابتسامة.',
            status: 'submitted',
            trackingCode: 'EG-NASR-219',
            courierName: 'محمود سعيد',
            courierPhone: '01145678901',
            courierEta: 'تم التسليم',
            trackingNote: 'تم التسليم في الموعد المحدد.',
            estimatedFee: 5800,
            currency: 'EGP',
            encryptionKeyB64: generateCaseEncryptionKeyB64(),
          },
          liveUpdate: {
            status: 'completed',
            courierName: 'محمود سعيد',
            courierPhone: '01145678901',
            courierEta: 'تم التسليم',
            trackingNote: 'تم التسليم في الموعد المحدد.',
            trackingCode: 'EG-NASR-219',
          },
        },
      ];

      for (const sc of sampleCases) {
        const caseId = sc.base.id as string;
        await setDoc(doc(db, 'cases', caseId), {
          ...sc.base,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        if (sc.liveUpdate) {
          await updateDoc(doc(db, 'cases', caseId), {
            status: sc.liveUpdate.status,
            trackingCode: sc.liveUpdate.trackingCode,
            courierName: sc.liveUpdate.courierName,
            courierPhone: sc.liveUpdate.courierPhone,
            courierEta: sc.liveUpdate.courierEta,
            trackingNote: sc.liveUpdate.trackingNote,
            estimatedFee: sc.base.estimatedFee,
            currency: sc.base.currency,
            updatedAt: serverTimestamp(),
          });
        }

        await recordCaseAuditEvent({
          caseId,
          doctorUid: user.uid,
          labOwnerUid: user.uid,
          actorUid: user.uid,
          actorName: profile.displayName,
          actorRole: 'doctor',
          action: 'CASE_SUBMITTED',
          summary: `Sample case ${sc.base.caseCode} initialized for ${sc.base.labName}`,
        });

        if (sc.liveUpdate && sc.liveUpdate.status !== 'completed') {
          await sendCaseStatusNotification({
            recipientUid: user.uid,
            senderUid: user.uid,
            caseId,
            caseCode: sc.base.caseCode as string,
            labName: sc.base.labName as string,
            clinicName: profile.organizationName,
            newStatus: sc.liveUpdate.status,
            customNote: sc.liveUpdate.trackingNote,
          });
        }
      }

      // Seed 1 pending digital invoice for completed case-sample-4
      const sampleInvCase = sampleCases[3].base;
      const sampleInvId = `inv-sample-4-${uidSlug}`;
      await setDoc(doc(db, 'invoices', sampleInvId), {
        id: sampleInvId,
        invoiceNumber: 'INV-260104',
        caseId: sampleInvCase.id as string,
        caseCode: sampleInvCase.caseCode as string,
        labId: sampleInvCase.labId as string,
        labName: sampleInvCase.labName as string,
        labOwnerUid: user.uid,
        doctorUid: user.uid,
        doctorName: profile.displayName,
        clinicName: profile.organizationName,
        patientInitials: sampleInvCase.patientInitials as string,
        patientChartRef: sampleInvCase.patientChartRef as string,
        serviceDescription: 'كوبري زيركون 3 وحدات (#19–#21) — Monolithic Zirconia',
        unitCount: 3,
        unitPrice: 2090,
        rushFee: 0,
        discountAmount: 0,
        totalAmount: 6270,
        currency: 'EGP',
        notes: 'الدفع متاح عبر Instapay أو تحويل بنكي خلال 7 أيام من التسليم.',
        status: 'pending',
        issuedDate: today.toISOString().slice(0, 10),
        dueDate: plusDays(7),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      await recordCaseAuditEvent({
        caseId: sampleInvCase.id as string,
        doctorUid: user.uid,
        labOwnerUid: user.uid,
        actorUid: user.uid,
        actorName: profile.displayName,
        actorRole: 'lab',
        action: 'INVOICE_ISSUED',
        summary: 'Issued sample digital invoice INV-260104 (6270 EGP)',
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'labs/cases sample seed');
    } finally {
      setSeedingSample(false);
    }
  };

  const handleAccountPhotoChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setAcctPhotoError(null);
    try {
      const dataUrl = await processImageUpload(file, {
        maxDimension: 256,
        maxDataUrlChars: VALIDATION.PROFILE_PHOTO_MAX_CHARS,
      });
      setAcctPhotoUrl(dataUrl);
    } catch (err) {
      setAcctPhotoError(
        err instanceof Error
          ? err.message
          : isAr
            ? 'تعذر رفع الصورة.'
            : 'Unable to process profile photo.'
      );
    }
  };

  const toggleAccountItem = (
    list: string[],
    setter: (next: string[]) => void,
    item: string,
    max: number,
    min: number
  ) => {
    if (list.includes(item)) {
      if (list.length > min) setter(list.filter((i) => i !== item));
    } else if (list.length < max) {
      setter([...list, item]);
    }
  };

  const handleSaveAccount = async (e: FormEvent) => {
    e.preventDefault();
    setSavingAccount(true);
    setAccountSaved(false);
    const path = `users/${profile.uid}`;
    try {
      await updateDoc(doc(db, 'users', profile.uid), {
        displayName: acctName.trim().slice(0, VALIDATION.DISPLAY_NAME_MAX),
        organizationName: acctOrg.trim().slice(0, VALIDATION.ORG_NAME_MAX),
        clinicAddress: acctAddress.trim().slice(0, VALIDATION.ADDRESS_MAX),
        city: acctCity.trim().slice(0, VALIDATION.CITY_MAX),
        area: acctArea.trim().slice(0, VALIDATION.AREA_MAX),
        latitude: acctLat,
        longitude: acctLng,
        licenseNumber: acctLicense.trim().slice(0, VALIDATION.LICENSE_MAX),
        phone: acctPhone.trim().slice(0, VALIDATION.PHONE_MAX),
        role: acctRole,
        dentalSpecialty: acctSpecialty.slice(0, VALIDATION.SPECIALTY_MAX),
        yearsExperience: Math.min(70, Math.max(0, Number(acctYearsExp) || 0)),
        services: acctServices,
        turnaroundDays: Math.min(30, Math.max(1, Number(acctTurnaround) || 4)),
        accreditations: acctAccreditations,
        profilePhotoUrl: acctPhotoUrl,
        updatedAt: serverTimestamp(),
      });
      setPerspective(acctRole);
      setAccountSaved(true);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    } finally {
      setSavingAccount(false);
    }
  };

  const navItems: { id: NavTab; label: string; icon: typeof Layers }[] = [
    {
      id: 'cases',
      label:
        perspective === 'lab'
          ? isAr
            ? 'شغل المعمل والتتبع'
            : 'Lab Production Queue'
          : isAr
            ? 'الروشتات والتتبع'
            : 'Prescriptions & Cases',
      icon: Layers,
    },
    {
      id: 'invoices',
      label: isAr ? 'الفواتير والمدفوعات' : 'Invoices & Billing',
      icon: Receipt,
    },
    { id: 'labs', label: isAr ? 'المعامل القريبة والأسعار' : 'Nearby Labs & Pricing', icon: FlaskConical },
    { id: 'analytics', label: isAr ? 'تحليلات المعمل (KPIs)' : 'Lab KPIs & Analytics', icon: BarChart3 },
    { id: 'my-lab', label: isAr ? 'صفحة معملي وأسعاره' : 'My Lab & Price List', icon: Building2 },
    { id: 'account', label: isAr ? 'حسابي واللوكيشن' : 'Profile & Location', icon: Settings2 },
  ];

  const currentTabTitle = navItems.find((n) => n.id === activeTab)?.label || 'Workspace';

  const statusFilterTabs: { id: StatusFilter; label: string }[] = isAr
    ? [
        { id: 'all', label: 'الكل' },
        { id: 'submitted', label: 'اتبعتت' },
        { id: 'courier', label: 'مع المندوب' },
        { id: 'received', label: 'المعمل استلم' },
        { id: 'in_progress', label: 'شغال فيه' },
        { id: 'awaiting_approval', label: 'مستني موافقة' },
        { id: 'delivery', label: 'الدليفري جاي لك' },
        { id: 'completed', label: 'خلص / وصل' },
        { id: 'revision', label: 'تعديل' },
      ]
    : [
        { id: 'all', label: 'All' },
        { id: 'submitted', label: 'Submitted' },
        { id: 'courier', label: 'Courier' },
        { id: 'received', label: 'Received' },
        { id: 'in_progress', label: 'In Progress' },
        { id: 'awaiting_approval', label: 'Awaiting Approval' },
        { id: 'delivery', label: 'Out for Delivery' },
        { id: 'completed', label: 'Completed' },
        { id: 'revision', label: 'Revision' },
      ];

  const unreadCount = useMemo(
    () => notifications.filter((n) => !n.read).length,
    [notifications]
  );

  const handleOpenNotification = async (notif: CaseNotification) => {
    setNotifOpen(false);
    setLiveToasts((prev) => prev.filter((t) => t.id !== notif.id));

    if (notif.newStatus === 'invoice_sent' || notif.newStatus === 'invoice_paid') {
      setSelectedCaseId(null);
      setPerspective(notif.newStatus === 'invoice_sent' ? 'doctor' : 'lab');
      setActiveTab('invoices');
      const matchingInv = allInvoices.find((inv) => inv.caseId === notif.caseId);
      setFocusedInvoiceId(matchingInv ? matchingInv.id : null);
    } else {
      setActiveTab('cases');
      setSelectedCaseId(notif.caseId);

      const matchingCase = [...doctorCases, ...labCases].find((c) => c.id === notif.caseId);
      if (matchingCase) {
        if (matchingCase.doctorUid === user.uid && notif.senderUid !== user.uid) {
          setPerspective('doctor');
        }
      }
    }

    if (!notif.read) {
      try {
        await updateDoc(doc(db, 'notifications', notif.id), { read: true });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `notifications/${notif.id}`);
      }
    }
  };

  const handleMarkAllNotificationsRead = async () => {
    const unread = notifications.filter((n) => !n.read);
    for (const n of unread) {
      try {
        await updateDoc(doc(db, 'notifications', n.id), { read: true });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `notifications/${n.id}`);
        break;
      }
    }
  };

  const formatFee = (amount: number, curr?: string) => {
    const cLabel = (curr || 'EGP') === 'EGP' ? (isAr ? 'ج.م' : 'EGP') : 'USD';
    return `${amount.toLocaleString()} ${cLabel}`;
  };

  return (
    <div className="min-h-screen liquid-backdrop text-[#0B1E3B] flex">
      {/* Desktop Sidebar (256px) */}
      <aside className="hidden lg:flex w-64 shrink-0 glass-nav border-e flex-col justify-between">
        <div>
          <div className="h-16 px-5 flex items-center justify-between border-b border-[#002B6B]/10">
            <BrandLogo size="md" />
          </div>

          <nav aria-label="Workspace navigation" className="p-4 space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`relative w-full flex items-center px-3 py-2.5 text-sm font-medium rounded-xl transition-colors cursor-pointer whitespace-nowrap ${
                    active
                      ? 'text-[#002B6B] font-semibold'
                      : 'text-slate-600 hover:text-[#002B6B] hover:bg-white/50'
                  }`}
                >
                  {active && (
                    <motion.span
                      layoutId="sidebar-active-bg"
                      transition={{ type: 'spring', stiffness: 420, damping: 34 }}
                      className="absolute inset-0 z-0 rounded-xl bg-white/85 border border-[#00A8B5]/40 shadow-xs"
                    />
                  )}
                  <span className="relative z-10 flex items-center gap-3 w-full">
                    <Icon
                      className={`w-4 h-4 shrink-0 ${active ? 'text-[#00A8B5]' : 'text-slate-500'}`}
                    />
                    <span className="truncate">{item.label}</span>
                  </span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-4 border-t border-[#002B6B]/10 space-y-3">
          {/* Language Switcher inside Sidebar Footer */}
          <div className="flex items-center justify-between px-2.5 py-1.5 glass-surface rounded-xl">
            <span className="inline-flex items-center gap-1.5 text-[11px] font-medium text-slate-600">
              <Globe className="w-3.5 h-3.5 text-[#00A8B5]" />
              <span>{isAr ? 'اللغة' : 'Language'}</span>
            </span>
            <div className="inline-flex items-center gap-1">
              <button
                type="button"
                onClick={() => setLang('ar')}
                className={`px-2 py-0.5 text-[11px] font-semibold rounded-lg transition-colors cursor-pointer ${
                  lang === 'ar' ? 'bg-[#002B6B] text-white' : 'text-slate-600 hover:text-[#002B6B]'
                }`}
              >
                مصري
              </button>
              <button
                type="button"
                onClick={() => setLang('en')}
                className={`px-2 py-0.5 text-[11px] font-semibold rounded-lg transition-colors cursor-pointer ${
                  lang === 'en' ? 'bg-[#002B6B] text-white' : 'text-slate-600 hover:text-[#002B6B]'
                }`}
              >
                EN
              </button>
            </div>
          </div>

          <div className="flex items-center gap-3 px-1">
            <div className="w-9 h-9 rounded-xl glass-surface overflow-hidden flex items-center justify-center shrink-0">
              {profile.profilePhotoUrl ? (
                <img
                  src={profile.profilePhotoUrl}
                  alt={profile.displayName}
                  className="w-full h-full object-cover"
                />
              ) : (
                <span className="font-display text-sm font-bold text-[#002B6B]">
                  {profile.displayName.charAt(0).toUpperCase()}
                </span>
              )}
            </div>
            <div className="min-w-0">
              <div className="text-xs font-semibold text-[#002B6B] truncate">
                {profile.displayName}
              </div>
              <div className="text-[11px] text-slate-500 truncate">
                {profile.area || profile.organizationName}
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={onSignOut}
            className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium btn-glass-secondary rounded-xl cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>{isAr ? 'تسجيل الخروج' : 'Sign out'}</span>
          </button>
        </div>
      </aside>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 lg:hidden flex">
          <div
            className="fixed inset-0 bg-[#002B6B]/25 backdrop-blur-sm"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative z-50 w-64 glass-modal h-full border-e border-white/80 flex flex-col justify-between p-4">
            <div>
              <div className="flex items-center justify-between mb-6 px-2">
                <BrandLogo size="md" />
                <button
                  type="button"
                  onClick={() => setMobileMenuOpen(false)}
                  aria-label={isAr ? 'إغلاق القائمة' : 'Close navigation'}
                  className="p-1.5 text-slate-500 hover:text-[#002B6B] rounded-lg hover:bg-white/60"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <nav className="space-y-1">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const active = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        setActiveTab(item.id);
                        setMobileMenuOpen(false);
                      }}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-xl transition-colors ${
                        active
                          ? 'bg-white/85 border border-[#00A8B5]/40 text-[#002B6B] font-semibold shadow-xs'
                          : 'text-slate-600 hover:text-[#002B6B]'
                      }`}
                    >
                      <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-[#00A8B5]' : 'text-slate-500'}`} />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </nav>
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between px-2.5 py-1.5 glass-surface rounded-xl">
                <span className="text-[11px] font-medium text-slate-600">
                  {isAr ? 'اللغة' : 'Language'}
                </span>
                <div className="inline-flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setLang('ar')}
                    className={`px-2 py-0.5 text-[11px] font-semibold rounded-lg ${
                      lang === 'ar' ? 'bg-[#002B6B] text-white' : 'text-slate-600'
                    }`}
                  >
                    مصري
                  </button>
                  <button
                    type="button"
                    onClick={() => setLang('en')}
                    className={`px-2 py-0.5 text-[11px] font-semibold rounded-lg ${
                      lang === 'en' ? 'bg-[#002B6B] text-white' : 'text-slate-600'
                    }`}
                  >
                    EN
                  </button>
                </div>
              </div>
              <button
                type="button"
                onClick={onSignOut}
                className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium btn-glass-secondary rounded-xl"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>{isAr ? 'تسجيل الخروج' : 'Sign out'}</span>
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="h-16 glass-nav border-b px-6 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label={isAr ? 'فتح القائمة' : 'Open menu'}
              className="lg:hidden p-2 -ms-2 text-[#002B6B] hover:bg-white/60 rounded-xl"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-sm truncate">
              <span className="text-slate-500 hidden sm:inline">
                {isAr ? 'لابي' : 'Labi'}
              </span>
              <span className="text-slate-400 hidden sm:inline" aria-hidden="true">
                /
              </span>
              <span className="font-semibold text-[#002B6B] truncate">{currentTabTitle}</span>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {/* Real-time Notification Bell & Popover */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setNotifOpen((prev) => !prev)}
                aria-label={isAr ? 'الإشعارات اللحظية' : 'Real-time notifications'}
                aria-expanded={notifOpen}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium btn-glass-secondary rounded-xl cursor-pointer whitespace-nowrap shrink-0"
              >
                <Bell className={`w-4 h-4 ${unreadCount > 0 ? 'text-[#00A8B5]' : 'text-slate-500'}`} />
                <span className="hidden sm:inline">{isAr ? 'الإشعارات' : 'Alerts'}</span>
                {unreadCount > 0 && (
                  <span className="font-mono tabular-nums font-bold text-[#002B6B]">
                    ({unreadCount})
                  </span>
                )}
              </button>

              <AnimatePresence>
                {notifOpen && (
                  <>
                    <div
                      className="fixed inset-0 z-30"
                      onClick={() => setNotifOpen(false)}
                      aria-hidden="true"
                    />
                    <motion.div
                      initial={{ opacity: 0, y: 8, scale: 0.97 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 6, scale: 0.97 }}
                      transition={{ duration: 0.16, ease: 'easeOut' }}
                      role="region"
                      aria-label={isAr ? 'قائمة الإشعارات' : 'Notifications list'}
                      className="absolute end-0 mt-2 w-80 sm:w-96 glass-modal rounded-2xl z-40 overflow-hidden"
                    >
                      <div className="px-4 py-3 border-b border-[#002B6B]/10 flex items-center justify-between gap-2 bg-white/60">
                        <span className="text-xs font-semibold text-[#002B6B]">
                          {isAr ? 'تنبيهات تغيّر حالة الحالات' : 'Real-Time Status Alerts'}
                        </span>
                        {unreadCount > 0 && (
                          <button
                            type="button"
                            onClick={handleMarkAllNotificationsRead}
                            className="inline-flex items-center gap-1 text-[11px] font-medium text-[#008C99] hover:text-[#002B6B] cursor-pointer"
                          >
                            <Check className="w-3 h-3" />
                            <span>{isAr ? 'تحديد الكل كمقروء' : 'Mark all read'}</span>
                          </button>
                        )}
                      </div>

                      <div className="max-h-80 overflow-y-auto divide-y divide-[#002B6B]/10">
                        {notifications.length === 0 ? (
                          <div className="p-6 text-center text-xs text-slate-500">
                            {isAr
                              ? 'مفيش إشعارات لسه. أول ما المعمل أو المندوب يحدث حالة هيوصلك تنبيه فوري هنا.'
                              : 'No notifications yet. Instant alerts appear here whenever a lab updates a case.'}
                          </div>
                        ) : (
                          notifications.slice(0, 20).map((n) => (
                            <button
                              key={n.id}
                              type="button"
                              onClick={() => void handleOpenNotification(n)}
                              className={`w-full text-start p-3.5 hover:bg-white/80 transition-colors cursor-pointer space-y-1 ${
                                !n.read ? 'bg-[#00A8B5]/10' : 'bg-white/35'
                              }`}
                            >
                              <div className="flex items-center justify-between gap-2 text-xs">
                                <span
                                  className={`font-semibold ${
                                    !n.read ? 'text-[#002B6B]' : 'text-slate-800'
                                  }`}
                                >
                                  {isAr ? n.titleAr : n.titleEn}
                                </span>
                                <span className="font-mono text-[11px] text-slate-400 shrink-0">
                                  {n.caseCode}
                                </span>
                              </div>
                              <p className="text-xs text-slate-600 leading-relaxed line-clamp-2">
                                {isAr ? n.bodyAr : n.bodyEn}
                              </p>
                              <div className="text-[10px] font-mono tabular-nums text-slate-400">
                                {n.createdAt?.toDate
                                  ? n.createdAt.toDate().toLocaleString([], {
                                      month: 'short',
                                      day: 'numeric',
                                      hour: '2-digit',
                                      minute: '2-digit',
                                    })
                                  : isAr
                                    ? 'الآن'
                                    : 'Just now'}
                                {!n.read && ` · ${isAr ? 'جديد' : 'Unread'}`}
                              </div>
                            </button>
                          ))
                        )}
                      </div>
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>

            <button
              type="button"
              onClick={() => {
                setPreselectedLabId(undefined);
                setShowNewCaseModal(true);
              }}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold btn-glass-primary rounded-xl whitespace-nowrap shrink-0 cursor-pointer"
            >
              <FilePlus2 className="w-4 h-4" />
              <span>{isAr ? 'روشتة جديدة' : 'New Prescription'}</span>
            </button>
          </div>
        </header>

        <main className="flex-1 p-6 lg:p-8 max-w-6xl w-full mx-auto space-y-6">
          {activeTab === 'cases' && (
            <>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="inline-flex items-center p-1 glass-surface rounded-xl self-start">
                  <button
                    type="button"
                    onClick={() => setPerspective('doctor')}
                    className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                      perspective === 'doctor'
                        ? 'bg-[#002B6B] text-white shadow-xs'
                        : 'text-slate-600 hover:text-[#002B6B]'
                    }`}
                  >
                    {isAr
                      ? `روشتات العيادة (${doctorCases.length})`
                      : `Doctor Prescriptions (${doctorCases.length})`}
                  </button>
                  <button
                    type="button"
                    onClick={() => setPerspective('lab')}
                    className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                      perspective === 'lab'
                        ? 'bg-[#002B6B] text-white shadow-xs'
                        : 'text-slate-600 hover:text-[#002B6B]'
                    }`}
                  >
                    {isAr
                      ? `شغل المعمل (${labCases.length})`
                      : `Lab Production Queue (${labCases.length})`}
                  </button>
                </div>

                {allDirectoryLabs.length === 0 && (
                  <button
                    type="button"
                    disabled={seedingSample}
                    onClick={handleSeedSampleNetwork}
                    className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold btn-glass-secondary rounded-xl cursor-pointer whitespace-nowrap shrink-0"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-[#00A8B5]" />
                    <span>
                      {seedingSample
                        ? isAr
                          ? 'بنجهز شبكة معامل مصرية تجريبية...'
                          : 'Creating Sample Network...'
                        : isAr
                          ? 'تحمّيل معامل وحالات تجريبية (القاهرة والجيزة)'
                          : 'Load Sample Labs & Cases'}
                    </span>
                  </button>
                )}
              </div>

              {/* Metrics Strip */}
              <div className="grid grid-cols-2 lg:grid-cols-4 glass-panel rounded-2xl divide-y lg:divide-y-0 lg:divide-x rtl:lg:divide-x-reverse divide-[#002B6B]/10">
                <div className="p-5">
                  <div className="text-xs text-slate-500">
                    {isAr ? 'حالات شغالة دلوقتي' : 'Active Cases'}
                  </div>
                  <div className="font-mono tabular-nums text-2xl font-semibold text-[#002B6B] mt-1">
                    {metrics.activeCount}
                  </div>
                </div>
                <div className="p-5">
                  <div className="text-xs text-slate-500">
                    {isAr ? 'مع المندوب / مستني موافقة' : 'In Transit / Approval'}
                  </div>
                  <div className="font-mono tabular-nums text-2xl font-semibold text-[#002B6B] mt-1">
                    {metrics.inTransitCount}
                  </div>
                </div>
                <div className="p-5">
                  <div className="text-xs text-slate-500">
                    {isAr ? 'وصلت وخلصت' : 'Completed'}
                  </div>
                  <div className="font-mono tabular-nums text-2xl font-semibold text-emerald-700 mt-1">
                    {metrics.completedCount}
                  </div>
                </div>
                <div className="p-5">
                  <div className="text-xs text-slate-500">
                    {isAr ? 'إجمالي قيمة الشغل' : 'Queue Value'}
                  </div>
                  <div className="font-mono tabular-nums text-2xl font-semibold text-[#008C99] mt-1">
                    {metrics.totalValue.toLocaleString()} {isAr ? 'ج.م' : 'EGP'}
                  </div>
                </div>
              </div>

              {/* Filter & Search Bar */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-1 p-1 glass-surface rounded-xl">
                  {statusFilterTabs.map((f) => (
                    <button
                      key={f.id}
                      type="button"
                      onClick={() => setStatusFilter(f.id)}
                      className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                        statusFilter === f.id
                          ? 'bg-[#002B6B] text-white shadow-xs'
                          : 'text-slate-600 hover:text-[#002B6B]'
                      }`}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>

                <div className="relative w-full md:w-72">
                  <Search className="w-4 h-4 text-slate-400 absolute start-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="search"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={
                      isAr ? 'ابحث بالكود، المريض، المعمل، السنة...' : 'Search code, chart, tooth, lab...'
                    }
                    aria-label={isAr ? 'بحث في الحالات' : 'Search cases'}
                    className="w-full ps-9 pe-3 py-2 text-sm glass-input rounded-xl"
                  />
                </div>
              </div>

              {/* High-Density Data Grid */}
              <div className="glass-panel rounded-2xl overflow-hidden">
                {loadingCases ? (
                  <div className="divide-y divide-[#002B6B]/10">
                    {[1, 2, 3, 4].map((row) => (
                      <div key={row} className="h-11 px-5 flex items-center justify-between">
                        <div className="h-3.5 w-28 bg-white/70 rounded animate-pulse" />
                        <div className="h-3.5 w-44 bg-white/70 rounded animate-pulse" />
                        <div className="h-3.5 w-24 bg-white/70 rounded animate-pulse" />
                      </div>
                    ))}
                  </div>
                ) : filteredCases.length === 0 ? (
                  <div className="p-12 text-center">
                    <h3 className="font-display text-base font-semibold text-[#002B6B] mb-1">
                      {perspectiveCases.length === 0
                        ? perspective === 'lab'
                          ? isAr
                            ? 'مفيش حالات مبعوتة لمعمالك لسه'
                            : 'No cases routed to your laboratory yet'
                          : isAr
                            ? 'مفيش روشتات مبعوتة لسه'
                            : 'No prescriptions submitted yet'
                        : isAr
                          ? 'مفيش حالات مطابقة للبحث ده'
                          : 'No cases match your current filter'}
                    </h3>
                    <p className="text-sm text-slate-600 max-w-md mx-auto mb-6">
                      {perspectiveCases.length === 0
                        ? isAr
                          ? 'ابعت أول روشتة ديجيتال بالأشعة أو حمّل المعامل والحالات التجريبية عشان تجرب التراكينج والشات.'
                          : 'Create a digital prescription with X-rays or load sample dental laboratories and cases.'
                        : isAr
                          ? 'جرّب تغيّر فلتر الحالة أو كلمة البحث.'
                          : 'Adjust your status tab or search term to view matching clinical orders.'}
                    </p>
                    <div className="flex flex-wrap items-center justify-center gap-3">
                      <button
                        type="button"
                        onClick={() => setShowNewCaseModal(true)}
                        className="px-4 py-2 text-sm font-semibold btn-glass-primary rounded-xl cursor-pointer"
                      >
                        {isAr ? 'ابعت أول روشتة' : 'Create First Prescription'}
                      </button>
                      {perspectiveCases.length === 0 && (
                        <button
                          type="button"
                          disabled={seedingSample}
                          onClick={handleSeedSampleNetwork}
                          className="px-4 py-2 text-sm font-medium btn-glass-secondary rounded-xl cursor-pointer"
                        >
                          {seedingSample
                            ? isAr
                              ? 'جاري التحميل...'
                              : 'Loading Samples...'
                            : isAr
                              ? 'تحميل معامل وحالات تجريبية'
                              : 'Load Sample Labs & Cases'}
                        </button>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-start border-collapse">
                      <thead>
                        <tr className="border-b border-[#002B6B]/10 bg-white/55 text-[11px] font-semibold text-slate-500">
                          <th className="py-2.5 px-4 text-start">{isAr ? 'الكود' : 'Case Code'}</th>
                          <th className="py-2.5 px-4 text-start">
                            {perspective === 'lab'
                              ? isAr
                                ? 'العيادة والدكتور'
                                : 'Prescribing Clinic'
                              : isAr
                                ? 'المعمل والمريض'
                                : 'Dental Laboratory'}
                          </th>
                          <th className="py-2.5 px-4 text-start">
                            {isAr ? 'التركيبة والخامة' : 'Restoration & Shade'}
                          </th>
                          <th className="py-2.5 px-4 text-start">{isAr ? 'الأسنان' : 'Teeth'}</th>
                          <th className="py-2.5 px-4 text-start">
                            {isAr ? 'التتبع والحالة المباشرة' : 'Live Status & Courier'}
                          </th>
                          <th className="py-2.5 px-4 text-end">
                            {isAr ? 'ميعاد التسليم' : 'Due Date'}
                          </th>
                          <th className="py-2.5 px-4 text-end">{isAr ? 'التكلفة' : 'Fee'}</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#002B6B]/10 text-sm">
                        {filteredCases.map((c) => (
                          <tr
                            key={c.id}
                            onClick={() => setSelectedCaseId(c.id)}
                            className="h-12 hover:bg-white/65 transition-colors cursor-pointer"
                          >
                            <td className="py-2.5 px-4 font-mono tabular-nums font-semibold text-[#002B6B] whitespace-nowrap">
                              {c.caseCode}
                            </td>
                            <td className="py-2.5 px-4 text-slate-700">
                              <div className="font-medium text-[#0B1E3B] truncate max-w-[220px]">
                                {perspective === 'lab' ? c.clinicName : c.labName}
                              </div>
                              <div className="text-xs text-slate-500 font-mono">
                                {c.patientInitials} · {c.patientChartRef}
                                {(c.xrayAttachments?.length || 0) > 0 &&
                                  ` · ${c.xrayAttachments?.length} ${isAr ? 'أشعة' : 'X-ray'}`}
                              </div>
                            </td>
                            <td className="py-2.5 px-4 text-slate-700 whitespace-nowrap">
                              <span>
                                {isAr
                                  ? RESTORATION_LABELS_AR[c.restorationType] || c.restorationType
                                  : c.restorationType}
                              </span>
                              <span className="text-slate-400 mx-1.5" aria-hidden="true">
                                ·
                              </span>
                              <span className="text-slate-500">
                                {isAr ? MATERIAL_LABELS_AR[c.material] || c.material : c.material}
                              </span>
                              <span className="text-slate-400 mx-1.5" aria-hidden="true">
                                ·
                              </span>
                              <span className="font-mono text-[#002B6B]">{c.shade}</span>
                            </td>
                            <td className="py-2.5 px-4 font-mono tabular-nums text-xs text-slate-700 whitespace-nowrap">
                              #{c.toothNumbers.join(', #')}
                            </td>
                            <td className="py-2.5 px-4">
                              <StatusIndicator status={c.status} />
                              {(c.trackingNote || c.courierEta) && (
                                <div className="text-[11px] text-slate-500 truncate max-w-[240px] mt-0.5">
                                  {c.courierEta ? `${c.courierEta} · ` : ''}
                                  {c.trackingNote}
                                </div>
                              )}
                            </td>
                            <td className="py-2.5 px-4 text-end font-mono tabular-nums text-xs text-slate-700 whitespace-nowrap">
                              {c.dueDate}
                            </td>
                            <td className="py-2.5 px-4 text-end font-mono tabular-nums font-semibold text-[#002B6B] whitespace-nowrap">
                              {formatFee(c.estimatedFee, c.currency)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </>
          )}

          {/* Proximity-Grouped Lab Directory View */}
          {activeTab === 'labs' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="font-display text-xl font-bold text-[#002B6B]">
                    {isAr
                      ? 'المعامل القريبة من عيادتك وأسعارها'
                      : 'Verified Labs Sorted by Proximity & Pricing'}
                  </h2>
                  <p className="text-sm text-slate-600 mt-0.5">
                    {isAr
                      ? `مرتّبين حسب المسافة من عيادتك (${profile.area || profile.city || 'القاهرة'}) مع الأسعار ومواعيد التسليم.`
                      : `Grouped by distance from your clinic (${profile.area || profile.city || 'Cairo'}) with transparent pricing and turnaround SLA.`}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setActiveTab('account')}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium btn-glass-secondary text-[#002B6B] rounded-xl cursor-pointer"
                  >
                    <MapPin className="w-3.5 h-3.5 text-[#00A8B5]" />
                    <span>
                      {profile.area
                        ? isAr
                          ? `موقع عيادتك: ${profile.area}`
                          : `Clinic: ${profile.area}`
                        : isAr
                          ? 'حدد لوكيشن عيادتك'
                          : 'Set Clinic Location'}
                    </span>
                  </button>

                  <label htmlFor="spec-filter" className="text-xs font-medium text-slate-600">
                    {isAr ? 'التخصص:' : 'Service:'}
                  </label>
                  <select
                    id="spec-filter"
                    value={labSpecialtyFilter}
                    onChange={(e) => setLabSpecialtyFilter(e.target.value)}
                    className="px-3 py-1.5 text-sm glass-input rounded-xl"
                  >
                    <option value="All">{isAr ? 'كل التخصصات' : 'All Services'}</option>
                    {LAB_SERVICES_LIST.map((srv) => (
                      <option key={srv} value={srv}>
                        {srv}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {loadingLabs ? (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {[1, 2, 3].map((i) => (
                    <div
                      key={i}
                      className="h-72 glass-panel rounded-2xl animate-pulse"
                    />
                  ))}
                </div>
              ) : groupedLabs.totalCount === 0 ? (
                <div className="glass-panel rounded-2xl p-12 text-center">
                  <h3 className="font-display text-base font-semibold text-[#002B6B] mb-1">
                    {isAr ? 'مفيش معامل متسجلة في الدليل لسه' : 'No laboratories published yet'}
                  </h3>
                  <p className="text-sm text-slate-600 max-w-md mx-auto mb-6">
                    {isAr
                      ? 'حمّل المعامل التجريبية في المعادي ومدينة نصر والشيخ زايد بأسعارها الكاملة، أو أضف معملك.'
                      : 'Load sample partner laboratories or publish your own dental lab listing to start routing prescriptions.'}
                  </p>
                  <div className="flex flex-wrap justify-center gap-3">
                    <button
                      type="button"
                      disabled={seedingSample}
                      onClick={handleSeedSampleNetwork}
                      className="px-4 py-2 text-sm font-semibold btn-glass-primary rounded-xl cursor-pointer"
                    >
                      {seedingSample
                        ? isAr
                          ? 'جاري التحميل...'
                          : 'Loading Labs...'
                        : isAr
                          ? 'تحميل معامل القاهرة والجيزة التجريبية'
                          : 'Load Sample Dental Labs'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTab('my-lab')}
                      className="px-4 py-2 text-sm font-medium btn-glass-secondary rounded-xl cursor-pointer"
                    >
                      {isAr ? 'أضف معملك وأسعارك' : 'Publish My Lab'}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-8">
                  {groupedLabs.buckets.map((group) => (
                    <section key={group.key} className="space-y-4">
                      <div className="flex items-center justify-between border-b border-[#002B6B]/10 pb-2">
                        <div className="flex items-center gap-2 text-sm font-semibold text-[#002B6B]">
                          <MapPin className="w-4 h-4 text-[#00A8B5]" />
                          <span>{PROXIMITY_LABELS[lang][group.key]}</span>
                        </div>
                        <span className="font-mono tabular-nums text-xs text-slate-500">
                          {group.items.length}{' '}
                          {isAr ? (group.items.length === 1 ? 'معمل' : 'معامل') : 'labs'}
                        </span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {group.items.map(({ lab, distanceKm }) => {
                          const img = LAB_IMAGES[lab.imageKey] || LAB_IMAGES.ceramics;
                          const currLabel =
                            (lab.priceList?.currency || 'EGP') === 'EGP'
                              ? isAr
                                ? 'ج.م'
                                : 'EGP'
                              : 'USD';

                          return (
                            <article
                              key={lab.id}
                              className="glass-panel glass-interactive rounded-2xl overflow-hidden flex flex-col justify-between"
                            >
                              <div>
                                <div className="aspect-[16/10] bg-white/50 border-b border-white/70 overflow-hidden">
                                  <SafeImage
                                    src={img.src}
                                    alt={img.alt}
                                    fallbackTitle={lab.name}
                                    className="w-full h-full object-cover"
                                  />
                                </div>
                                <div className="p-5 space-y-3">
                                  <div className="text-xs text-slate-600 flex flex-wrap items-center gap-1.5">
                                    <span className="font-medium text-slate-800">
                                      {lab.area || lab.city}
                                    </span>
                                    {distanceKm !== null && (
                                      <>
                                        <span aria-hidden="true">·</span>
                                        <span className="font-mono tabular-nums font-semibold text-[#008C99]">
                                          {isAr
                                            ? `يبعد ${distanceKm} كم`
                                            : `${distanceKm} km away`}
                                        </span>
                                      </>
                                    )}
                                  </div>

                                  <h3 className="font-display text-lg font-semibold text-[#002B6B]">
                                    {lab.name}
                                  </h3>

                                  <div className="text-xs text-slate-600 flex flex-wrap items-center gap-1.5">
                                    <span className="font-mono tabular-nums">
                                      {isAr
                                        ? `التسليم: ${lab.turnaroundDays} أيام`
                                        : `${lab.turnaroundDays}-day SLA`}
                                    </span>
                                    {typeof lab.expressHours === 'number' && lab.expressHours > 0 && (
                                      <>
                                        <span aria-hidden="true">·</span>
                                        <span className="font-mono tabular-nums text-emerald-700 font-medium">
                                          {isAr
                                            ? `مستعجل: ${lab.expressHours} ساعة`
                                            : `Rush: ${lab.expressHours}h`}
                                        </span>
                                      </>
                                    )}
                                  </div>

                                  <p className="text-sm text-slate-600 leading-relaxed line-clamp-2">
                                    {lab.summary}
                                  </p>

                                  {/* Transparent Lab Price List Grid */}
                                  {lab.priceList && (
                                    <div className="glass-surface rounded-xl p-3 grid grid-cols-2 gap-x-3 gap-y-1.5 text-xs">
                                      {typeof lab.priceList.zirconiaCrown === 'number' && (
                                        <div className="flex items-center justify-between gap-1">
                                          <span className="text-slate-500">
                                            {isAr ? 'زيركون' : 'Zirconia'}
                                          </span>
                                          <span className="font-mono tabular-nums font-semibold text-[#002B6B]">
                                            {lab.priceList.zirconiaCrown.toLocaleString()} {currLabel}
                                          </span>
                                        </div>
                                      )}
                                      {typeof lab.priceList.emaxVeneer === 'number' && (
                                        <div className="flex items-center justify-between gap-1">
                                          <span className="text-slate-500">
                                            {isAr ? 'إيماكس' : 'E.max'}
                                          </span>
                                          <span className="font-mono tabular-nums font-semibold text-[#002B6B]">
                                            {lab.priceList.emaxVeneer.toLocaleString()} {currLabel}
                                          </span>
                                        </div>
                                      )}
                                      {typeof lab.priceList.implantAbutment === 'number' && (
                                        <div className="flex items-center justify-between gap-1">
                                          <span className="text-slate-500">
                                            {isAr ? 'زراعة' : 'Implant'}
                                          </span>
                                          <span className="font-mono tabular-nums font-semibold text-[#002B6B]">
                                            {lab.priceList.implantAbutment.toLocaleString()} {currLabel}
                                          </span>
                                        </div>
                                      )}
                                      {typeof lab.priceList.rushFee === 'number' && (
                                        <div className="flex items-center justify-between gap-1">
                                          <span className="text-slate-500">
                                            {isAr ? 'استعجال' : 'Rush'}
                                          </span>
                                          <span className="font-mono tabular-nums font-semibold text-[#002B6B]">
                                            +{lab.priceList.rushFee.toLocaleString()} {currLabel}
                                          </span>
                                        </div>
                                      )}
                                    </div>
                                  )}

                                  <div className="pt-1 text-xs text-slate-500">
                                    {isAr ? 'السكانرز:' : 'Scanners:'} {lab.scannerSupport.join(' · ')}
                                  </div>
                                  {lab.accreditations && lab.accreditations.length > 0 && (
                                    <div className="text-xs text-slate-600">
                                      {isAr ? 'الاعتمادات:' : 'Accredited:'}{' '}
                                      {lab.accreditations.join(' · ')}
                                    </div>
                                  )}
                                </div>
                              </div>

                              <div className="px-5 py-4 border-t border-[#002B6B]/10 flex items-center justify-between gap-3">
                                <span className="text-xs font-medium text-slate-600">
                                  {lab.acceptingCases
                                    ? isAr
                                      ? 'بيستقبل حالات'
                                      : 'Accepting Cases'
                                    : isAr
                                      ? 'متوقف مؤقتاً'
                                      : 'Queue Paused'}
                                </span>
                                <button
                                  type="button"
                                  disabled={!lab.acceptingCases}
                                  onClick={() => {
                                    setPreselectedLabId(lab.id);
                                    setShowNewCaseModal(true);
                                  }}
                                  className="px-3.5 py-1.5 text-xs font-semibold btn-glass-primary rounded-xl disabled:opacity-40 cursor-pointer whitespace-nowrap"
                                >
                                  {isAr ? 'ابعت روشتة' : 'Send Prescription'}
                                </button>
                              </div>
                            </article>
                          );
                        })}
                      </div>
                    </section>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Invoices & Billing View */}
          {activeTab === 'invoices' && (
            <InvoicesView
              profile={profile}
              perspective={perspective}
              invoices={allInvoices}
              labCases={labCases}
              loading={loadingInvoices}
              initialInvoiceId={focusedInvoiceId}
              onClearInitialInvoice={() => setFocusedInvoiceId(null)}
              onOpenCase={(caseId) => setSelectedCaseId(caseId)}
              onCreateInvoiceForCase={(dentalCase, existing) =>
                setInvoiceTarget({ dentalCase, existing })
              }
            />
          )}

          {/* Lab KPIs & Recharts Analytics Dashboard */}
          {activeTab === 'analytics' && (
            <LabAnalyticsDashboard
              labCases={labCases}
              ownLabs={ownLabs}
              loading={loadingCases}
              seedingSample={seedingSample}
              onSeedSample={handleSeedSampleNetwork}
              onOpenNewCase={() => {
                setPreselectedLabId(undefined);
                setShowNewCaseModal(true);
              }}
            />
          )}

          {/* My Lab Profile & Price List Editor */}
          {activeTab === 'my-lab' && (
            <LabProfileEditor
              profile={profile}
              existingLab={myPrimaryLab}
              onSaved={() => setActiveTab('labs')}
            />
          )}

          {/* Profile, Credentials & Location Settings */}
          {activeTab === 'account' && (
            <div className="max-w-3xl space-y-6">
              <div>
                <h2 className="font-display text-xl font-bold text-[#002B6B]">
                  {isAr ? 'حسابي، البيانات الطبية، واللوكيشن' : 'Profile, Credentials & Location'}
                </h2>
                <p className="text-sm text-slate-600 mt-1">
                  {isAr
                    ? 'حدّث صورتك، تخصصك أو خدمات المعمل، بيانات التواصل، واللوكيشن عشان ترتيب المعامل حسب القرب يشتغل بدقة.'
                    : 'Manage your profile picture, contact information, dental specialty, or laboratory credentials and GPS proximity location.'}
                </p>
              </div>

              <form
                onSubmit={handleSaveAccount}
                className="glass-panel rounded-2xl p-6 space-y-6"
              >
                {/* Profile Picture Upload */}
                <div className="flex flex-col sm:flex-row sm:items-center gap-4 p-4 rounded-xl glass-surface">
                  <div className="w-16 h-16 rounded-xl border border-white/80 bg-white/80 overflow-hidden flex items-center justify-center shrink-0">
                    {acctPhotoUrl ? (
                      <img
                        src={acctPhotoUrl}
                        alt={acctName}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <span className="font-display text-lg font-bold text-[#002B6B]">
                        {(acctName || 'L').charAt(0).toUpperCase()}
                      </span>
                    )}
                  </div>
                  <div className="flex-1 space-y-1.5">
                    <div className="text-xs font-medium text-[#002B6B]">
                      {isAr ? 'الصورة الشخصية' : 'Profile Picture'}
                    </div>
                    <p className="text-xs text-slate-500">
                      {isAr
                        ? 'بتظهر في الشريط الجانبي ودليل التواصل بين العيادات والمعامل.'
                        : 'Visible on your account sidebar and clinical directory profile.'}
                    </p>
                    <div className="flex flex-wrap items-center gap-2">
                      <label className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium btn-glass-secondary rounded-xl cursor-pointer">
                        <Upload className="w-3.5 h-3.5 text-[#00A8B5]" />
                        <span>
                          {acctPhotoUrl
                            ? isAr
                              ? 'تغيير الصورة'
                              : 'Change Photo'
                            : isAr
                              ? 'رفع صورة'
                              : 'Upload Photo'}
                        </span>
                        <input
                          type="file"
                          accept="image/jpeg,image/png,image/webp"
                          onChange={handleAccountPhotoChange}
                          className="sr-only"
                        />
                      </label>
                      {acctPhotoUrl && (
                        <button
                          type="button"
                          onClick={() => setAcctPhotoUrl('')}
                          className="px-3 py-1.5 text-xs text-slate-600 hover:text-[#002B6B] cursor-pointer"
                        >
                          {isAr ? 'حذف' : 'Remove'}
                        </button>
                      )}
                    </div>
                    {acctPhotoError && <p className="text-xs text-red-700">{acctPhotoError}</p>}
                  </div>
                </div>

                {/* Role & Identity */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label
                      htmlFor="acct-role"
                      className="block text-xs font-medium text-slate-700 mb-1.5"
                    >
                      {isAr ? 'نوع الحساب' : 'Account Role'}
                    </label>
                    <select
                      id="acct-role"
                      value={acctRole}
                      onChange={(e) => setAcctRole(e.target.value as UserRole)}
                      className="w-full px-3 py-2 text-sm glass-input rounded-xl"
                    >
                      <option value="doctor">{isAr ? 'دكتور أسنان / عيادة' : 'Dental Doctor'}</option>
                      <option value="lab">{isAr ? 'معمل أسنان' : 'Dental Laboratory'}</option>
                    </select>
                  </div>
                  <div>
                    <label
                      htmlFor="acct-name"
                      className="block text-xs font-medium text-slate-700 mb-1.5"
                    >
                      {isAr ? 'الاسم' : 'Display Name'}
                    </label>
                    <input
                      id="acct-name"
                      type="text"
                      required
                      maxLength={VALIDATION.DISPLAY_NAME_MAX}
                      value={acctName}
                      onChange={(e) => setAcctName(e.target.value)}
                      className="w-full px-3 py-2 text-sm glass-input rounded-xl"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="acct-org"
                      className="block text-xs font-medium text-slate-700 mb-1.5"
                    >
                      {acctRole === 'doctor'
                        ? isAr
                          ? 'اسم العيادة'
                          : 'Clinic Name'
                        : isAr
                          ? 'اسم المعمل'
                          : 'Laboratory Name'}
                    </label>
                    <input
                      id="acct-org"
                      type="text"
                      required
                      maxLength={VALIDATION.ORG_NAME_MAX}
                      value={acctOrg}
                      onChange={(e) => setAcctOrg(e.target.value)}
                      className="w-full px-3 py-2 text-sm glass-input rounded-xl"
                    />
                  </div>
                </div>

                {/* Location Picker */}
                <LocationPicker
                  area={acctArea}
                  city={acctCity}
                  latitude={acctLat}
                  longitude={acctLng}
                  onChange={(loc) => {
                    setAcctArea(loc.area);
                    setAcctCity(loc.city);
                    setAcctLat(loc.latitude);
                    setAcctLng(loc.longitude);
                  }}
                />

                {/* Doctor or Lab Credentials */}
                {acctRole === 'doctor' ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label
                        htmlFor="acct-specialty"
                        className="block text-xs font-medium text-slate-700 mb-1.5"
                      >
                        {isAr ? 'التخصص الطبي' : 'Dental Specialty'}
                      </label>
                      <select
                        id="acct-specialty"
                        value={acctSpecialty}
                        onChange={(e) => setAcctSpecialty(e.target.value)}
                        className="w-full px-3 py-2 text-sm glass-input rounded-xl"
                      >
                        {DENTAL_SPECIALTIES.map((spec) => (
                          <option key={spec} value={spec}>
                            {spec}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label
                        htmlFor="acct-exp"
                        className="block text-xs font-medium text-slate-700 mb-1.5"
                      >
                        {isAr ? 'سنين الخبرة' : 'Years of Experience'}
                      </label>
                      <input
                        id="acct-exp"
                        type="number"
                        min={0}
                        max={70}
                        value={acctYearsExp}
                        onChange={(e) => setAcctYearsExp(Number(e.target.value))}
                        className="w-full px-3 py-2 text-sm font-mono tabular-nums glass-input rounded-xl"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label
                          htmlFor="acct-turnaround"
                          className="block text-xs font-medium text-slate-700 mb-1.5"
                        >
                          {isAr ? 'مدة التسليم المعتادة (بالأيام)' : 'Turnaround Time (Days)'}
                        </label>
                        <input
                          id="acct-turnaround"
                          type="number"
                          min={1}
                          max={30}
                          value={acctTurnaround}
                          onChange={(e) => setAcctTurnaround(Number(e.target.value))}
                          className="w-full px-3 py-2 text-sm font-mono tabular-nums glass-input rounded-xl"
                        />
                      </div>
                      <div>
                        <label
                          htmlFor="acct-lab-exp"
                          className="block text-xs font-medium text-slate-700 mb-1.5"
                        >
                          {isAr ? 'سنين الخبرة' : 'Years of Experience'}
                        </label>
                        <input
                          id="acct-lab-exp"
                          type="number"
                          min={0}
                          max={70}
                          value={acctYearsExp}
                          onChange={(e) => setAcctYearsExp(Number(e.target.value))}
                          className="w-full px-3 py-2 text-sm font-mono tabular-nums glass-input rounded-xl"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      <div>
                        <div className="text-xs font-medium text-slate-700 mb-2">
                          {isAr ? 'خدمات المعمل (1–8)' : 'Laboratory Services (1–8)'}
                        </div>
                        <div className="space-y-1.5">
                          {LAB_SERVICES_LIST.map((srv) => (
                            <label
                              key={srv}
                              className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer"
                            >
                              <input
                                type="checkbox"
                                checked={acctServices.includes(srv)}
                                onChange={() =>
                                  toggleAccountItem(acctServices, setAcctServices, srv, 8, 1)
                                }
                                className="rounded border-slate-300 accent-[#002B6B]"
                              />
                              <span>{srv}</span>
                            </label>
                          ))}
                        </div>
                      </div>

                      <div>
                        <div className="text-xs font-medium text-slate-700 mb-2">
                          {isAr ? 'الاعتمادات والشهادات' : 'Accreditations & Certifications'}
                        </div>
                        <div className="space-y-1.5">
                          {LAB_ACCREDITATIONS_LIST.map((acc) => (
                            <label
                              key={acc}
                              className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer"
                            >
                              <input
                                type="checkbox"
                                checked={acctAccreditations.includes(acc)}
                                onChange={() =>
                                  toggleAccountItem(
                                    acctAccreditations,
                                    setAcctAccreditations,
                                    acc,
                                    6,
                                    0
                                  )
                                }
                                className="rounded border-slate-300 accent-[#002B6B]"
                              />
                              <span>{acc}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Contact & Clinic/Lab Address */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label
                      htmlFor="acct-address"
                      className="block text-xs font-medium text-slate-700 mb-1.5"
                    >
                      {acctRole === 'doctor'
                        ? isAr
                          ? 'عنوان العيادة بالتفصيل'
                          : 'Clinic Street Address'
                        : isAr
                          ? 'عنوان المعمل بالتفصيل'
                          : 'Laboratory Address'}
                    </label>
                    <input
                      id="acct-address"
                      type="text"
                      maxLength={VALIDATION.ADDRESS_MAX}
                      value={acctAddress}
                      onChange={(e) => setAcctAddress(e.target.value)}
                      placeholder={
                        isAr ? 'شارع 9، الدور التاني، المعادي' : '9th St, Floor 2, Maadi'
                      }
                      className="w-full px-3 py-2 text-sm glass-input rounded-xl"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="acct-city"
                      className="block text-xs font-medium text-slate-700 mb-1.5"
                    >
                      {isAr ? 'المحافظة / المدينة' : 'City / Governorate'}
                    </label>
                    <input
                      id="acct-city"
                      type="text"
                      maxLength={VALIDATION.CITY_MAX}
                      value={acctCity}
                      onChange={(e) => setAcctCity(e.target.value)}
                      className="w-full px-3 py-2 text-sm glass-input rounded-xl"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label
                      htmlFor="acct-license"
                      className="block text-xs font-medium text-slate-700 mb-1.5"
                    >
                      {isAr ? 'رقم النقابة / الترخيص' : 'License / Syndicate ID'}
                    </label>
                    <input
                      id="acct-license"
                      type="text"
                      maxLength={VALIDATION.LICENSE_MAX}
                      value={acctLicense}
                      onChange={(e) => setAcctLicense(e.target.value)}
                      className="w-full px-3 py-2 text-sm font-mono glass-input rounded-xl"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="acct-phone"
                      className="block text-xs font-medium text-slate-700 mb-1.5"
                    >
                      {isAr ? 'رقم الموبايل المباشر' : 'Direct Phone'}
                    </label>
                    <input
                      id="acct-phone"
                      type="text"
                      maxLength={VALIDATION.PHONE_MAX}
                      value={acctPhone}
                      onChange={(e) => setAcctPhone(e.target.value)}
                      className="w-full px-3 py-2 text-sm font-mono glass-input rounded-xl"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="acct-email"
                      className="block text-xs font-medium text-slate-700 mb-1.5"
                    >
                      {isAr ? 'الإيميل الموثق' : 'Verified Email'}
                    </label>
                    <input
                      id="acct-email"
                      type="email"
                      disabled
                      value={profile.email}
                      className="w-full px-3 py-2 text-sm glass-input rounded-xl opacity-75 text-slate-500"
                    />
                  </div>
                </div>

                {accountSaved && (
                  <div
                    role="status"
                    className="p-3 rounded-xl border border-emerald-200/80 bg-emerald-50/90 text-xs text-emerald-800 flex items-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>
                      {isAr
                        ? 'تم حفظ البيانات واللوكيشن بنجاح.'
                        : 'Profile, credentials, and proximity location updated.'}
                    </span>
                  </div>
                )}

                <div className="pt-2 flex justify-end">
                  <button
                    type="submit"
                    disabled={savingAccount}
                    className="px-5 py-2 text-sm font-semibold btn-glass-primary rounded-xl disabled:opacity-60 cursor-pointer"
                  >
                    {savingAccount
                      ? isAr
                        ? 'جاري الحفظ...'
                        : 'Saving...'
                      : isAr
                        ? 'حفظ البيانات واللوكيشن'
                        : 'Save Profile & Location'}
                  </button>
                </div>
              </form>
            </div>
          )}
        </main>
      </div>

      {showNewCaseModal && (
        <NewCaseModal
          profile={profile}
          labs={allDirectoryLabs}
          initialLabId={preselectedLabId}
          onClose={() => setShowNewCaseModal(false)}
          onCreated={() => {
            setShowNewCaseModal(false);
            setActiveTab('cases');
            setPerspective('doctor');
          }}
        />
      )}

      {selectedCase && (
        <CaseDetailDrawer
          dentalCase={selectedCase}
          profile={profile}
          activePerspective={perspective}
          caseInvoice={selectedCaseInvoice}
          onOpenCreateInvoice={(dentalCase, existing) => {
            setInvoiceTarget({ dentalCase, existing });
          }}
          onViewInvoice={(invoice) => {
            setSelectedCaseId(null);
            setFocusedInvoiceId(invoice.id);
            setActiveTab('invoices');
          }}
          onClose={() => setSelectedCaseId(null)}
        />
      )}

      {invoiceTarget && (
        <CreateInvoiceModal
          dentalCase={invoiceTarget.dentalCase}
          profile={profile}
          existingInvoice={invoiceTarget.existing}
          onClose={() => setInvoiceTarget(null)}
          onSaved={(invoiceId) => {
            setInvoiceTarget(null);
            setSelectedCaseId(null);
            setFocusedInvoiceId(invoiceId);
            setActiveTab('invoices');
          }}
        />
      )}

      {/* Real-time Floating Notification Toasts */}
      {liveToasts.length > 0 && (
        <div
          aria-live="polite"
          className="fixed bottom-5 end-5 z-50 flex flex-col gap-2.5 max-w-sm w-[calc(100vw-2.5rem)]"
        >
          <AnimatePresence>
            {liveToasts.map((toast) => (
              <motion.div
                key={toast.id}
                layout
                initial={{ opacity: 0, y: 14, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 8, scale: 0.96 }}
                transition={{ duration: 0.2, ease: 'easeOut' }}
                role="status"
                className="glass-modal rounded-2xl p-4 space-y-2 border border-[#00A8B5]/35"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2 text-xs font-semibold text-[#002B6B]">
                    <Bell className="w-4 h-4 text-[#00A8B5] shrink-0" />
                    <span>{isAr ? toast.titleAr : toast.titleEn}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      setLiveToasts((prev) => prev.filter((item) => item.id !== toast.id))
                    }
                    aria-label={isAr ? 'إخفاء التنبيه' : 'Dismiss alert'}
                    className="text-slate-400 hover:text-[#002B6B] cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <p className="text-xs text-slate-700 leading-relaxed">
                  {isAr ? toast.bodyAr : toast.bodyEn}
                </p>
                <div className="flex items-center justify-between gap-2 pt-1 text-[11px]">
                  <span className="font-mono text-slate-500">{toast.caseCode}</span>
                  <button
                    type="button"
                    onClick={() => void handleOpenNotification(toast)}
                    className="font-semibold text-[#008C99] hover:text-[#002B6B] cursor-pointer"
                  >
                    {isAr ? 'فتح تفاصيل الحالة' : 'Open Case Details'}
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
