import type { ReactNode } from 'react';
import { LABI_LOGO_SRC } from './BrandLogo';

interface AuthShellProps {
  title: string;
  subtitle?: string;
  children: ReactNode;
}

export function AuthShell({ title, subtitle, children }: AuthShellProps) {
  return (
    <div className="fixed inset-0 flex flex-col overflow-hidden bg-[linear-gradient(160deg,#002B6B_0%,#003F94_60%,#00A8B5_150%)]">
      <div
        className="px-6 pb-6 text-center"
        style={{ paddingTop: 'max(env(safe-area-inset-top, 0px), 40px)' }}
      >
        <div className="mx-auto w-16 h-16 rounded-2xl bg-white shadow-lg flex items-center justify-center overflow-hidden">
          <img src={LABI_LOGO_SRC} alt="Labi" className="w-14 h-14 object-contain" />
        </div>
        <h1 className="mt-4 text-2xl font-bold text-white">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-white/75">{subtitle}</p>}
      </div>
      <div
        className="flex-1 min-h-0 overflow-y-auto rounded-t-[32px] bg-[#F7FBFE] px-6 pt-7"
        style={{ paddingBottom: 'max(env(safe-area-inset-bottom, 0px), 24px)' }}
      >
        <div className="mx-auto w-full max-w-md">{children}</div>
      </div>
    </div>
  );
}
