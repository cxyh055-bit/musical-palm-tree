import { useState, type ChangeEvent, type FormEvent } from 'react';
import type { User } from 'firebase/auth';
import { doc, serverTimestamp, setDoc } from 'firebase/firestore';
import { Building2, Stethoscope, Upload } from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { useLang } from '../i18n';
import {
  DENTAL_SPECIALTIES,
  LAB_ACCREDITATIONS_LIST,
  LAB_SERVICES_LIST,
  sanitizeIdSegment,
  VALIDATION,
  type UserRole,
} from '../types';
import { AREA_PRESETS } from '../utils/geo';
import { processImageUpload } from '../utils/imageUpload';
import { LocationPicker } from './LocationPicker';
import { BrandLogo } from './BrandLogo';

interface OnboardingViewProps {
  user: User;
  onComplete: () => void;
  onSignOut: () => void;
}

export function OnboardingView({ user, onComplete, onSignOut }: OnboardingViewProps) {
  const { lang, setLang } = useLang();
  const isAr = lang === 'ar';

  const [role, setRole] = useState<UserRole>('doctor');
  const [displayName, setDisplayName] = useState(user.displayName || '');
  const [organizationName, setOrganizationName] = useState('');
  const [clinicAddress, setClinicAddress] = useState('');
  const [area, setArea] = useState(AREA_PRESETS[0].areaAr);
  const [city, setCity] = useState(AREA_PRESETS[0].city);
  const [latitude, setLatitude] = useState<number>(AREA_PRESETS[0].lat);
  const [longitude, setLongitude] = useState<number>(AREA_PRESETS[0].lng);
  const [phone, setPhone] = useState('');
  const [licenseNumber, setLicenseNumber] = useState('');

  // Doctor-specific
  const [dentalSpecialty, setDentalSpecialty] = useState(DENTAL_SPECIALTIES[0]);
  const [yearsExperience, setYearsExperience] = useState(8);

  // Lab-specific
  const [services, setServices] = useState<string[]>([
    'Esthetic Ceramics',
    'Monolithic Zirconia',
  ]);
  const [turnaroundDays, setTurnaroundDays] = useState(3);
  const [accreditations, setAccreditations] = useState<string[]>(['CDT Certified Lab']);
  const [zirconiaPrice, setZirconiaPrice] = useState(1800);
  const [emaxPrice, setEmaxPrice] = useState(2400);
  const [implantPrice, setImplantPrice] = useState(3500);
  const [rushFee, setRushFee] = useState(400);

  const [profilePhotoUrl, setProfilePhotoUrl] = useState('');
  const [photoError, setPhotoError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const toggleSelection = (
    list: string[],
    setter: (next: string[]) => void,
    item: string,
    max: number,
    min: number
  ) => {
    if (list.includes(item)) {
      if (list.length > min) setter(list.filter((i) => i !== item));
    } else if (list.length < max) {
      setter([...list, item]);
    }
  };

  const handlePhotoChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPhotoError(null);
    try {
      const dataUrl = await processImageUpload(file, {
        maxDimension: 256,
        maxDataUrlChars: VALIDATION.PROFILE_PHOTO_MAX_CHARS,
      });
      setProfilePhotoUrl(dataUrl);
    } catch (err) {
      setPhotoError(err instanceof Error ? err.message : 'Unable to process image.');
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);

    const trimmedName = displayName.trim();
    const trimmedOrg = organizationName.trim();
    const trimmedCity = city.trim();
    const trimmedArea = area.trim();
    const trimmedAddr = clinicAddress.trim();
    const trimmedLicense = licenseNumber.trim();
    const trimmedPhone = phone.trim();

    if (trimmedName.length < 2 || trimmedName.length > VALIDATION.DISPLAY_NAME_MAX) {
      setError(
        isAr
          ? `الاسم لازم يكون من ٢ لـ ${VALIDATION.DISPLAY_NAME_MAX} حرف.`
          : `Name must be 2–${VALIDATION.DISPLAY_NAME_MAX} characters.`
      );
      return;
    }
    if (trimmedOrg.length < 2 || trimmedOrg.length > VALIDATION.ORG_NAME_MAX) {
      setError(
        isAr
          ? `اسم العيادة أو المعمل لازم يكون من ٢ لـ ${VALIDATION.ORG_NAME_MAX} حرف.`
          : `Clinic or lab name must be 2–${VALIDATION.ORG_NAME_MAX} characters.`
      );
      return;
    }

    setSubmitting(true);
    const userPath = `users/${user.uid}`;

    try {
      const payload: Record<string, unknown> = {
        uid: user.uid,
        displayName: trimmedName,
        email: (user.email || '').slice(0, 120),
        role,
        organizationName: trimmedOrg,
        yearsExperience: Math.min(70, Math.max(0, Number(yearsExperience) || 0)),
        latitude,
        longitude,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };
      if (trimmedLicense) payload.licenseNumber = trimmedLicense.slice(0, VALIDATION.LICENSE_MAX);
      if (trimmedCity) payload.city = trimmedCity.slice(0, VALIDATION.CITY_MAX);
      if (trimmedArea) payload.area = trimmedArea.slice(0, VALIDATION.AREA_MAX);
      if (trimmedAddr) payload.clinicAddress = trimmedAddr.slice(0, VALIDATION.ADDRESS_MAX);
      if (trimmedPhone) payload.phone = trimmedPhone.slice(0, VALIDATION.PHONE_MAX);
      if (profilePhotoUrl) payload.profilePhotoUrl = profilePhotoUrl;

      if (role === 'doctor') {
        payload.dentalSpecialty = dentalSpecialty.slice(0, VALIDATION.SPECIALTY_MAX);
      } else {
        payload.services = services;
        payload.turnaroundDays = Math.min(30, Math.max(1, Number(turnaroundDays) || 3));
        payload.accreditations = accreditations;
      }

      await setDoc(doc(db, 'users', user.uid), payload);

      if (role === 'lab') {
        const labId = `lab-${sanitizeIdSegment(user.uid)}`;
        const labPayload = {
          id: labId,
          ownerUid: user.uid,
          name: trimmedOrg,
          city: trimmedCity || 'القاهرة',
          area: trimmedArea || 'المعادي، القاهرة',
          latitude,
          longitude,
          turnaroundDays: Math.min(30, Math.max(1, Number(turnaroundDays) || 3)),
          expressHours: 24,
          specialties: services.length > 0 ? services : ['Esthetic Ceramics'],
          materials: ['Monolithic Zirconia', 'Layered E.max', 'Titanium Custom'],
          scannerSupport: ['3Shape TRIOS', 'iTero Element', 'Medit i700', 'Dentsply Primescan'],
          accreditations,
          priceTier: 'Boutique',
          priceList: {
            zirconiaCrown: Math.max(0, Number(zirconiaPrice) || 1800),
            emaxVeneer: Math.max(0, Number(emaxPrice) || 2400),
            implantAbutment: Math.max(0, Number(implantPrice) || 3500),
            clearAligner: 6500,
            denture: 4500,
            rushFee: Math.max(0, Number(rushFee) || 400),
            currency: 'EGP',
          },
          summary: `${trimmedOrg} — ${trimmedArea || trimmedCity}. تسليم خلال ${turnaroundDays} أيام مع خدمة مستعجل 24 ساعة.`,
          imageKey: 'ceramics',
          acceptingCases: true,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        };
        try {
          await setDoc(doc(db, 'labs', labId), labPayload);
        } catch (labErr) {
          handleFirestoreError(labErr, OperationType.WRITE, `labs/${labId}`);
        }
      }

      onComplete();
    } catch (err) {
      if (err instanceof Error && err.message.startsWith('{')) {
        throw err;
      }
      handleFirestoreError(err, OperationType.WRITE, userPath);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen liquid-backdrop flex flex-col">
      <header className="glass-nav border-b px-6 h-16 flex items-center justify-between gap-8">
        <BrandLogo size="md" />
        <div className="flex items-center gap-3 text-sm">
          <div className="inline-flex items-center p-0.5 glass-surface rounded-xl">
            <button
              type="button"
              onClick={() => setLang('ar')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-lg cursor-pointer transition-colors ${
                isAr ? 'bg-[#002B6B] text-white shadow-xs' : 'text-[#002B6B]/70'
              }`}
            >
              مصري
            </button>
            <button
              type="button"
              onClick={() => setLang('en')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-lg cursor-pointer transition-colors ${
                !isAr ? 'bg-[#002B6B] text-white shadow-xs' : 'text-[#002B6B]/70'
              }`}
            >
              EN
            </button>
          </div>
          <button
            type="button"
            onClick={onSignOut}
            className="btn-glass-secondary px-3 py-1.5 text-xs font-medium text-[#002B6B] rounded-xl whitespace-nowrap shrink-0 cursor-pointer"
          >
            {isAr ? 'خروج' : 'Sign out'}
          </button>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center p-6">
        <div className="max-w-2xl w-full glass-panel rounded-2xl p-8">
          <h1 className="font-display text-2xl font-bold tracking-tight text-[#002B6B] mb-2">
            {isAr ? 'كمّل بيانات حسابك على لابي' : 'Set up your Labi Connect profile'}
          </h1>
          <p className="text-sm text-slate-600 mb-6">
            {isAr
              ? 'اختار حسابك كدكتور أسنان أو معمل، وحدد اللوكيشن عشان نربط العيادات بالمعامل الأقرب ليها.'
              : 'Configure your clinic or laboratory credentials, location coordinates, and profile photo.'}
          </p>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-2">
                {isAr ? 'نوع الحساب' : 'Account Role'}
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setRole('doctor')}
                  className={`p-4 rounded-xl border text-start transition-all cursor-pointer ${
                    role === 'doctor'
                      ? 'border-[#00A8B5] bg-white/90 ring-2 ring-[#00A8B5]/25 text-[#002B6B]'
                      : 'glass-surface text-slate-700 hover:bg-white/75'
                  }`}
                >
                  <Stethoscope
                    className={`w-5 h-5 mb-2 ${role === 'doctor' ? 'text-[#00A8B5]' : 'text-slate-400'}`}
                  />
                  <div className="text-sm font-semibold">
                    {isAr ? 'دكتور أسنان / عيادة' : 'Dental Doctor / Clinic'}
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    {isAr
                      ? 'دور على أقرب معمل، قارن الأسعار، وابعت الحالات والأشعة'
                      : 'Specialty, experience, clinic location, and X-ray case submission'}
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setRole('lab')}
                  className={`p-4 rounded-xl border text-start transition-all cursor-pointer ${
                    role === 'lab'
                      ? 'border-[#00A8B5] bg-white/90 ring-2 ring-[#00A8B5]/25 text-[#002B6B]'
                      : 'glass-surface text-slate-700 hover:bg-white/75'
                  }`}
                >
                  <Building2
                    className={`w-5 h-5 mb-2 ${role === 'lab' ? 'text-[#00A8B5]' : 'text-slate-400'}`}
                  />
                  <div className="text-sm font-semibold">
                    {isAr ? 'معمل أسنان' : 'Dental Laboratory'}
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    {isAr
                      ? 'حط أسعارك ووقت التسليم ولوكيشن المعمل واستقبل شغل'
                      : 'Publish prices, turnaround SLA, accreditations, and receive cases'}
                  </div>
                </button>
              </div>
            </div>

            {/* Profile Picture */}
            <div className="flex flex-col sm:flex-row sm:items-center gap-4 p-4 rounded-xl glass-surface">
              <div className="w-16 h-16 rounded-xl border border-white/90 bg-white/80 overflow-hidden flex items-center justify-center shrink-0 shadow-xs">
                {profilePhotoUrl ? (
                  <img
                    src={profilePhotoUrl}
                    alt="Profile preview"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <span className="font-display text-lg font-bold text-[#002B6B]/60">
                    {(displayName || 'L').charAt(0).toUpperCase()}
                  </span>
                )}
              </div>
              <div className="flex-1 space-y-1.5">
                <div className="text-xs font-semibold text-[#0B1E3B]">
                  {isAr ? 'صورة البروفايل أو لوجو العيادة/المعمل' : 'Profile Picture'}
                </div>
                <label className="btn-glass-secondary inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#002B6B] rounded-lg cursor-pointer">
                  <Upload className="w-3.5 h-3.5 text-[#00A8B5]" />
                  <span>
                    {profilePhotoUrl
                      ? isAr
                        ? 'تغيير الصورة'
                        : 'Change Photo'
                      : isAr
                        ? 'ارفع صورة'
                        : 'Upload Photo'}
                  </span>
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    onChange={handlePhotoChange}
                    className="sr-only"
                  />
                </label>
                {photoError && <p className="text-xs text-red-700">{photoError}</p>}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="onboard-display-name"
                  className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
                >
                  {role === 'doctor'
                    ? isAr
                      ? 'اسم الدكتور'
                      : 'Doctor Full Name'
                    : isAr
                      ? 'اسم الفني المسؤول / مدير المعمل'
                      : 'Lead Technician / Contact'}
                </label>
                <input
                  id="onboard-display-name"
                  type="text"
                  required
                  maxLength={VALIDATION.DISPLAY_NAME_MAX}
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder={isAr ? 'د. كريم محمود' : 'Dr. Elena Vance'}
                  className="w-full px-3 py-2 text-sm rounded-xl glass-input text-[#0B1E3B]"
                />
              </div>

              <div>
                <label
                  htmlFor="onboard-org-name"
                  className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
                >
                  {role === 'doctor'
                    ? isAr
                      ? 'اسم العيادة'
                      : 'Clinic Name'
                    : isAr
                      ? 'اسم المعمل'
                      : 'Laboratory Name'}
                </label>
                <input
                  id="onboard-org-name"
                  type="text"
                  required
                  maxLength={VALIDATION.ORG_NAME_MAX}
                  value={organizationName}
                  onChange={(e) => setOrganizationName(e.target.value)}
                  placeholder={isAr ? 'عيادة النيل للأسنان' : 'Pacific Restorative Dental'}
                  className="w-full px-3 py-2 text-sm rounded-xl glass-input text-[#0B1E3B]"
                />
              </div>
            </div>

            {/* Location Picker */}
            <LocationPicker
              area={area}
              city={city}
              latitude={latitude}
              longitude={longitude}
              onChange={(loc) => {
                setArea(loc.area);
                setCity(loc.city);
                setLatitude(loc.latitude);
                setLongitude(loc.longitude);
              }}
            />

            {role === 'doctor' ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="onboard-specialty"
                    className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
                  >
                    {isAr ? 'التخصص الطبي' : 'Dental Specialty'}
                  </label>
                  <select
                    id="onboard-specialty"
                    value={dentalSpecialty}
                    onChange={(e) => setDentalSpecialty(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-xl glass-input text-[#0B1E3B]"
                  >
                    {DENTAL_SPECIALTIES.map((spec) => (
                      <option key={spec} value={spec}>
                        {spec}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="onboard-exp"
                    className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
                  >
                    {isAr ? 'سنين الخبرة' : 'Years of Experience'}
                  </label>
                  <input
                    id="onboard-exp"
                    type="number"
                    min={0}
                    max={70}
                    value={yearsExperience}
                    onChange={(e) => setYearsExperience(Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm font-mono tabular-nums rounded-xl glass-input text-[#0B1E3B]"
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label
                      htmlFor="onboard-turnaround"
                      className="block text-xs font-medium text-[#0B1E3B]/80 mb-1"
                    >
                      {isAr ? 'التسليم (أيام)' : 'Turnaround (Days)'}
                    </label>
                    <input
                      id="onboard-turnaround"
                      type="number"
                      min={1}
                      max={30}
                      value={turnaroundDays}
                      onChange={(e) => setTurnaroundDays(Number(e.target.value))}
                      className="w-full px-3 py-2 text-sm font-mono tabular-nums rounded-xl glass-input text-[#0B1E3B]"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="onboard-zirc"
                      className="block text-xs font-medium text-[#0B1E3B]/80 mb-1"
                    >
                      {isAr ? 'سعر الزيركون (ج.م)' : 'Zirconia (EGP)'}
                    </label>
                    <input
                      id="onboard-zirc"
                      type="number"
                      min={0}
                      value={zirconiaPrice}
                      onChange={(e) => setZirconiaPrice(Number(e.target.value))}
                      className="w-full px-3 py-2 text-sm font-mono tabular-nums rounded-xl glass-input text-[#0B1E3B]"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="onboard-emax"
                      className="block text-xs font-medium text-[#0B1E3B]/80 mb-1"
                    >
                      {isAr ? 'سعر الإيماكس (ج.م)' : 'E.max Veneer (EGP)'}
                    </label>
                    <input
                      id="onboard-emax"
                      type="number"
                      min={0}
                      value={emaxPrice}
                      onChange={(e) => setEmaxPrice(Number(e.target.value))}
                      className="w-full px-3 py-2 text-sm font-mono tabular-nums rounded-xl glass-input text-[#0B1E3B]"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="onboard-imp"
                      className="block text-xs font-medium text-[#0B1E3B]/80 mb-1"
                    >
                      {isAr ? 'دعامة زراعة (ج.م)' : 'Implant (EGP)'}
                    </label>
                    <input
                      id="onboard-imp"
                      type="number"
                      min={0}
                      value={implantPrice}
                      onChange={(e) => setImplantPrice(Number(e.target.value))}
                      className="w-full px-3 py-2 text-sm font-mono tabular-nums rounded-xl glass-input text-[#0B1E3B]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-3.5 rounded-xl glass-surface">
                    <div className="text-xs font-semibold text-[#002B6B] mb-2">
                      {isAr ? 'خدمات المعمل' : 'Laboratory Services'}
                    </div>
                    <div className="space-y-1.5 max-h-32 overflow-y-auto">
                      {LAB_SERVICES_LIST.map((srv) => (
                        <label
                          key={srv}
                          className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer"
                        >
                          <input
                            type="checkbox"
                            checked={services.includes(srv)}
                            onChange={() => toggleSelection(services, setServices, srv, 8, 1)}
                            className="rounded border-slate-300 accent-[#002B6B]"
                          />
                          <span>{srv}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                  <div className="p-3.5 rounded-xl glass-surface">
                    <div className="text-xs font-semibold text-[#002B6B] mb-2">
                      {isAr ? 'الاعتمادات والشهادات' : 'Accreditations'}
                    </div>
                    <div className="space-y-1.5 max-h-32 overflow-y-auto">
                      {LAB_ACCREDITATIONS_LIST.map((acc) => (
                        <label
                          key={acc}
                          className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer"
                        >
                          <input
                            type="checkbox"
                            checked={accreditations.includes(acc)}
                            onChange={() =>
                              toggleSelection(accreditations, setAccreditations, acc, 6, 0)
                            }
                            className="rounded border-slate-300 accent-[#002B6B]"
                          />
                          <span>{acc}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="onboard-rush"
                    className="block text-xs font-medium text-[#0B1E3B]/80 mb-1"
                  >
                    {isAr ? 'رسوم الشغل المستعجل (ج.م)' : 'Rush Surcharge (EGP)'}
                  </label>
                  <input
                    id="onboard-rush"
                    type="number"
                    min={0}
                    value={rushFee}
                    onChange={(e) => setRushFee(Number(e.target.value))}
                    className="w-full sm:w-48 px-3 py-2 text-sm font-mono tabular-nums rounded-xl glass-input text-[#0B1E3B]"
                  />
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="sm:col-span-1">
                <label
                  htmlFor="onboard-address"
                  className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
                >
                  {isAr ? 'العنوان التفصيلي' : 'Street Address'}
                </label>
                <input
                  id="onboard-address"
                  type="text"
                  maxLength={VALIDATION.ADDRESS_MAX}
                  value={clinicAddress}
                  onChange={(e) => setClinicAddress(e.target.value)}
                  placeholder={isAr ? 'شارع 9، عمارة 14' : '14 Street 9, Suite 3'}
                  className="w-full px-3 py-2 text-sm rounded-xl glass-input text-[#0B1E3B]"
                />
              </div>

              <div>
                <label
                  htmlFor="onboard-license"
                  className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
                >
                  {isAr ? 'رقم النقابة / الترخيص' : 'License / CDT ID'}
                </label>
                <input
                  id="onboard-license"
                  type="text"
                  maxLength={VALIDATION.LICENSE_MAX}
                  value={licenseNumber}
                  onChange={(e) => setLicenseNumber(e.target.value)}
                  placeholder="EG-DDS-8492"
                  className="w-full px-3 py-2 text-sm font-mono rounded-xl glass-input text-[#0B1E3B]"
                />
              </div>

              <div>
                <label
                  htmlFor="onboard-phone"
                  className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
                >
                  {isAr ? 'رقم الموبايل للتواصل' : 'Direct Phone'}
                </label>
                <input
                  id="onboard-phone"
                  type="text"
                  maxLength={VALIDATION.PHONE_MAX}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="01001234567"
                  className="w-full px-3 py-2 text-sm font-mono rounded-xl glass-input text-[#0B1E3B]"
                />
              </div>
            </div>

            {error && (
              <div
                role="alert"
                className="p-3 rounded-xl border border-red-200 bg-red-50/90 text-xs text-red-800"
              >
                {error}
              </div>
            )}

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                disabled={submitting}
                className="btn-glass-primary px-6 py-2.5 text-sm font-semibold rounded-xl disabled:opacity-60 cursor-pointer"
              >
                {submitting
                  ? isAr
                    ? 'جاري الحفظ...'
                    : 'Saving profile...'
                  : isAr
                    ? 'دخول على لابي كونكت'
                    : 'Continue to Labi Connect'}
              </button>
            </div>
          </form>
        </div>
      </main>
    </div>
  );
}
