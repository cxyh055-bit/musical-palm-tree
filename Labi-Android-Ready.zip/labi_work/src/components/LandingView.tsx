import { useState } from 'react';
import { ArrowLeft, ArrowRight, CheckCircle2, FileCheck2, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';
import { useLang } from '../i18n';
import { LAB_IMAGES } from '../types';
import { BrandLogo } from './BrandLogo';
import { SafeImage } from './SafeImage';

interface LandingViewProps {
  onSignIn: () => void;
  signingIn: boolean;
  authError: string | null;
}

export function LandingView({ onSignIn, signingIn, authError }: LandingViewProps) {
  const { lang, setLang } = useLang();
  const isAr = lang === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;
  const [activeStep, setActiveStep] = useState<0 | 1 | 2>(0);

  const workflowSteps = isAr
    ? [
        {
          num: '01.',
          title: 'مقارنة المعامل بالقرب والأسعار',
          body: 'بنقسملك المعامل للأقرب لعيادتك بالكيلومتر، مع عرض أسعار الزيركون والإيماكس والزراعة ووقت التسليم لكل معمل.',
          preview: 'أقرب معمل: ديجيتال سمايل — المعادي (يبعد 2.1 كم · تسليم 3 أيام)',
        },
        {
          num: '02.',
          title: 'روشتة رقمية مع خريطة الأسنان والأشعة',
          body: 'حدد أرقام الأسنان على الخريطة التفاعلية، ارفع صور الأشعة، واكتب الشغل المطلوب والدرجة (Shade) والملف بيتبعت للمعمل فوراً.',
          preview: 'روشتة LABI-260101 · 4 عدسات E.max · درجة BL3 · أشعة مرفقة',
        },
        {
          num: '03.',
          title: 'تراكينج المندوب والدليفري والفواتير',
          body: 'إشعارات لحظية من استلام المندوب ووصوله للمعمل لحد الدليفري للعيادة، مع فاتورة رقمية جاهزة للسداد.',
          preview: 'الدليفري جاي لك دلوقتي بالشغل · الوصول خلال 25 دقيقة',
        },
      ]
    : [
        {
          num: '01.',
          title: 'Proximity, Pricing & SLA Matching',
          body: 'Browse verified laboratories grouped by distance in kilometers from your clinic, complete with unit rates and express turnaround times.',
          preview: 'Nearest: Digital Smile Lab — Maadi (2.1 km away · 3-day SLA)',
        },
        {
          num: '02.',
          title: 'Digital Rx, Tooth Chart & X-Rays',
          body: 'Select target teeth on the Universal 1–32 dental chart, upload radiographs, and route scan references directly to your chosen lab.',
          preview: 'Rx LABI-260101 · 4x Layered E.max Veneers · Shade BL3 · X-ray attached',
        },
        {
          num: '03.',
          title: 'Live Courier Tracking & Digital Billing',
          body: 'Follow every milestone in real time from courier pickup and lab arrival to CAD approval, clinic delivery, and digital invoicing.',
          preview: 'Delivery courier on the way · ETA 25 mins · Invoice INV-260104',
        },
      ];

  return (
    <div className="min-h-screen liquid-backdrop text-[#0B1E3B] flex flex-col">
      {/* Top Bar Contract: strictly 3 zones */}
      <header className="sticky top-0 z-30 glass-nav border-b">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between gap-8">
          <a href="#top" className="whitespace-nowrap shrink-0 flex items-center">
            <BrandLogo size="md" />
          </a>

          <nav
            aria-label="Primary"
            className="hidden md:flex items-center gap-7 text-sm font-medium text-[#002B6B]/75"
          >
            <a
              href="#workflow"
              className="hover:text-[#002B6B] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
            >
              {isAr ? 'طريقة الشغل' : 'Workflow'}
            </a>
            <a
              href="#disciplines"
              className="hover:text-[#002B6B] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
            >
              {isAr ? 'التخصصات' : 'Specialties'}
            </a>
            <a
              href="#laboratories"
              className="hover:text-[#002B6B] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
            >
              {isAr ? 'المعامل' : 'Laboratories'}
            </a>
            <a
              href="#security"
              className="hover:text-[#002B6B] hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
            >
              {isAr ? 'الأمان والتشفير' : 'Security'}
            </a>
          </nav>

          <div className="shrink-0">
            <button
              type="button"
              onClick={onSignIn}
              disabled={signingIn}
              className="btn-glass-primary px-4 py-2 text-sm font-medium rounded-xl disabled:opacity-60 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00A8B5] focus-visible:ring-offset-2"
            >
              {signingIn
                ? isAr
                  ? 'جاري الدخول...'
                  : 'Connecting...'
                : isAr
                  ? 'سجّل بحساب جوجل'
                  : 'Sign in with Google'}
            </button>
          </div>
        </div>
      </header>

      <main id="top" className="flex-1">
        {/* Hero Split */}
        <section className="py-12 lg:py-16">
          <div className="max-w-7xl mx-auto px-6">
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
              className="glass-panel rounded-3xl p-8 lg:p-12"
            >
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
                <div className="lg:col-span-6 flex flex-col justify-between">
                  <div>
                    <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
                      <p className="text-xs font-semibold tracking-wide text-[#008C99]">
                        {isAr
                          ? 'شبكة ربط دكاترة الأسنان بمعامل التركيبات'
                          : 'Clinical Prescription & Laboratory Network'}
                      </p>
                      <div className="inline-flex items-center p-0.5 glass-surface rounded-xl">
                        <button
                          type="button"
                          onClick={() => setLang('ar')}
                          className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                            isAr
                              ? 'bg-[#002B6B] text-white shadow-xs'
                              : 'text-[#002B6B]/70 hover:text-[#002B6B]'
                          }`}
                        >
                          مصري
                        </button>
                        <button
                          type="button"
                          onClick={() => setLang('en')}
                          className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                            !isAr
                              ? 'bg-[#002B6B] text-white shadow-xs'
                              : 'text-[#002B6B]/70 hover:text-[#002B6B]'
                          }`}
                        >
                          EN
                        </button>
                      </div>
                    </div>

                    <h1 className="font-display text-[clamp(2.1rem,3.9vw,3.3rem)] font-bold leading-[1.14] tracking-tight text-[#002B6B] text-balance mb-5">
                      {isAr
                        ? 'ابعت شغل عيادتك لأقرب معمل أسنان وتابعه خطوة بخطوة.'
                        : 'Direct digital prescriptions from chairside to dental lab.'}
                    </h1>
                    <p className="text-base text-slate-600 leading-relaxed max-w-xl mb-8">
                      {isAr
                        ? 'لابي بيربط عيادات الأسنان بالمعامل المعتمدة حسب اللوكيشن والأسعار ووقت التسليم. ابعت الروشتة والأشعة، وتابع المندوب والمعمل لحظة بلحظة لحد الدليفري والفاتورة الرقمية.'
                        : 'Labi connects dental practices directly with specialized ceramic, implant, and CAD/CAM laboratories ranked by clinic proximity, published pricing, live tracking, and digital billing.'}
                    </p>

                    {authError && (
                      <div
                        role="alert"
                        className="mb-6 p-3.5 rounded-xl border border-red-200 bg-red-50/90 text-sm text-red-800"
                      >
                        {authError}
                      </div>
                    )}

                    <div className="flex flex-wrap items-center gap-4">
                      <button
                        type="button"
                        onClick={onSignIn}
                        disabled={signingIn}
                        className="btn-glass-primary inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold rounded-xl disabled:opacity-60 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00A8B5] focus-visible:ring-offset-2"
                      >
                        <span>
                          {signingIn
                            ? isAr
                              ? 'جاري تسجيل الدخول...'
                              : 'Signing in...'
                            : isAr
                              ? 'ابدا كدكتور أو معمل أسنان'
                              : 'Connect Practice or Lab'}
                        </span>
                        <ArrowIcon className="w-4 h-4" />
                      </button>
                      <a
                        href="#workflow"
                        className="btn-glass-secondary px-4 py-3 text-sm font-medium text-[#002B6B] rounded-xl whitespace-nowrap shrink-0"
                      >
                        {isAr ? 'شوف طريقة الشغل' : 'Inspect clinical workflow'}
                      </a>
                    </div>
                  </div>

                  <div className="mt-10 pt-6 border-t border-[#002B6B]/10 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-slate-600">
                    <span>{isAr ? 'ترتيب المعامل باللوكيشن' : 'Proximity Lab Sorting'}</span>
                    <span aria-hidden="true">·</span>
                    <span>{isAr ? 'أسعار واضحة لكل نوع شُغل' : 'Transparent Lab Pricing'}</span>
                    <span aria-hidden="true">·</span>
                    <span>{isAr ? 'تراكينج المندوب والدليفري' : 'Live Courier Tracking'}</span>
                    <span aria-hidden="true">·</span>
                    <span>{isAr ? 'فواتير رقمية وتشفير AES-256' : 'Digital Billing & AES-256'}</span>
                  </div>
                </div>

                <div className="lg:col-span-6">
                  <div className="h-full min-h-[320px] rounded-2xl overflow-hidden border border-white/80 shadow-lg bg-white/40 relative">
                    <SafeImage
                      src={LAB_IMAGES.studio.src}
                      alt={LAB_IMAGES.studio.alt}
                      fallbackTitle="Modern digital dental ceramic laboratory"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              </div>

              {/* 4-column quantitative strip */}
              <div className="mt-10 grid grid-cols-2 lg:grid-cols-4 glass-surface rounded-2xl divide-y lg:divide-y-0 lg:divide-x rtl:lg:divide-x-reverse divide-[#002B6B]/10">
                <div className="p-6">
                  <p className="font-mono tabular-nums text-2xl font-semibold text-[#002B6B]">
                    {isAr ? 'بالكيلومتر' : 'GPS / km'}
                  </p>
                  <p className="text-xs text-slate-600 mt-1">
                    {isAr
                      ? 'تقسيم المعامل تلقائياً حسب قربها من لوكيشن العيادة'
                      : 'Labs automatically grouped by distance from your clinic'}
                  </p>
                </div>
                <div className="p-6">
                  <p className="font-mono tabular-nums text-2xl font-semibold text-[#008C99]">
                    {isAr ? 'قائمة أسعار' : 'Live Rates'}
                  </p>
                  <p className="text-xs text-slate-600 mt-1">
                    {isAr
                      ? 'كل معمل بيحط أسعاره للزيركون والإيماكس والزراعة ووقت التسليم'
                      : 'Every lab publishes unit prices, rush fees, and delivery SLA'}
                  </p>
                </div>
                <div className="p-6">
                  <p className="font-mono tabular-nums text-2xl font-semibold text-[#002B6B]">
                    {isAr ? '8 مراحل' : '8 Stages'}
                  </p>
                  <p className="text-xs text-slate-600 mt-1">
                    {isAr
                      ? 'تراكينج من استلام المندوب ووصوله للمعمل لحد الدليفري للعيادة'
                      : 'Live tracking from courier pickup to lab work and clinic delivery'}
                  </p>
                </div>
                <div className="p-6">
                  <p className="font-mono tabular-nums text-2xl font-semibold text-[#008C99]">
                    AES-256
                  </p>
                  <p className="text-xs text-slate-600 mt-1">
                    {isAr
                      ? 'رسايل مشفرة، فواتير رقمية، وسجل متابعة كامل لكل حالة'
                      : 'Client-encrypted case threads, digital billing, and audit logs'}
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* 01. Interactive Mechanism & Clinical Flow */}
        <section id="workflow" className="py-12 lg:py-16">
          <div className="max-w-7xl mx-auto px-6">
            <div className="max-w-2xl mb-10">
              <h2 className="font-display text-3xl font-bold tracking-tight text-[#002B6B] text-balance mb-3">
                {isAr
                  ? 'كل تفاصيل الحالة والتسليم واضحة من أول دقيقة.'
                  : 'Structured prescription intake eliminates lab remakes.'}
              </h2>
              <p className="text-base text-slate-600 leading-relaxed">
                {isAr
                  ? 'اختار المعمل الأقرب ليك، شوف أسعاره ومواعيد تسليمه، ابعت الأشعة والروشتة، وتابع المندوب وهو رايح المعمل ولما الدليفري يطلعلك بالشغل.'
                  : 'Every case travels with verified tooth coordinates, Vita shade specifications, X-ray radiographs, and an auditable doctor–technician thread.'}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {workflowSteps.map((step, idx) => {
                const isSelected = activeStep === idx;
                return (
                  <button
                    key={step.num}
                    type="button"
                    onClick={() => setActiveStep(idx as 0 | 1 | 2)}
                    className={`text-start glass-panel glass-interactive rounded-2xl p-7 cursor-pointer transition-all ${
                      isSelected
                        ? 'ring-2 ring-[#00A8B5] bg-white/85'
                        : 'hover:bg-white/80'
                    }`}
                  >
                    <p className="font-mono text-xs font-semibold text-[#008C99] mb-3">
                      {step.num}
                    </p>
                    <h3 className="font-display text-lg font-semibold text-[#002B6B] mb-2">
                      {step.title}
                    </h3>
                    <p className="text-sm text-slate-600 leading-relaxed mb-4">
                      {step.body}
                    </p>
                    <div className="pt-3 border-t border-[#002B6B]/10 text-xs font-mono text-[#002B6B]/85 truncate">
                      {step.preview}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </section>

        {/* 02. Specialized Laboratory Disciplines */}
        <section id="disciplines" className="py-12 lg:py-16">
          <div className="max-w-7xl mx-auto px-6">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
              <div className="max-w-2xl">
                <h2 className="font-display text-3xl font-bold tracking-tight text-[#002B6B] text-balance mb-3">
                  {isAr
                    ? 'مجهز للتركيبات التجميلية، الزراعة، والتقويم الشفاف.'
                    : 'Built for restorative, implant, and orthodontic workflows.'}
                </h2>
                <p className="text-base text-slate-600">
                  {isAr
                    ? 'سواء معمل بوتيك للعدسات أو مركز طحن CAD/CAM، تقدر تنشر أسعارك واعتماداتك وتستقبل حالات العيادات القريبة منك.'
                    : 'Connect with boutique ceramist studios or high-throughput digital milling labs from one unified clinical workspace.'}
                </p>
              </div>
              <button
                type="button"
                onClick={onSignIn}
                className="btn-glass-secondary px-4 py-2.5 rounded-xl text-sm font-semibold text-[#002B6B] inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <span>{isAr ? 'افتح دليل المعامل دلوقتي' : 'Open live lab directory'}</span>
                <ArrowIcon className="w-4 h-4 text-[#00A8B5]" />
              </button>
            </div>

            <div id="laboratories" className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <article className="lg:col-span-7 glass-panel glass-interactive rounded-2xl overflow-hidden flex flex-col">
                <div className="aspect-[16/10] bg-slate-200 overflow-hidden">
                  <SafeImage
                    src={LAB_IMAGES.ceramics.src}
                    alt={LAB_IMAGES.ceramics.alt}
                    fallbackTitle="Layered E.max & Zirconia Ceramics"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-7 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="text-xs text-slate-500 mb-2 flex flex-wrap items-center gap-2">
                      <span>{isAr ? 'تركيبات تجميلية' : 'Esthetic Ceramics'}</span>
                      <span aria-hidden="true">·</span>
                      <span>{isAr ? 'إيماكس وزيركون' : 'Layered E.max & Monolithic Zirconia'}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums text-[#008C99] font-medium">
                        {isAr ? 'تسليم 4 أيام' : '4-Day SLA'}
                      </span>
                    </div>
                    <h3 className="font-display text-xl font-semibold text-[#002B6B] mb-2">
                      {isAr
                        ? 'عدسات الأسنان الأمامية وتطابق الألوان'
                        : 'Anterior Veneers & Shade-Matched Crowns'}
                    </h3>
                    <p className="text-sm text-slate-600 leading-relaxed">
                      {isAr
                        ? 'تحديد درجة اللون بدقة Vita مع إمكانية رفع صور الأشعة ومراجعة الفنيين خطوة بخطوة قبل التسليم.'
                        : 'Direct Vita classical and 3D-Master shade notation paired with radiograph uploads and chairside scan files.'}
                    </p>
                  </div>
                </div>
              </article>

              <div className="lg:col-span-5 flex flex-col gap-6">
                <article className="glass-panel glass-interactive rounded-2xl overflow-hidden flex-1 flex flex-col">
                  <div className="aspect-[16/9] bg-slate-200 overflow-hidden">
                    <SafeImage
                      src={LAB_IMAGES.cad.src}
                      alt={LAB_IMAGES.cad.alt}
                      fallbackTitle="5-Axis Digital CAD/CAM Milling"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-6">
                    <div className="text-xs text-slate-500 mb-1.5 flex items-center gap-2">
                      <span>{isAr ? 'طحن رقمي 5-Axis' : '5-Axis Milling'}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums text-[#008C99] font-medium">
                        {isAr ? 'متاح استعجال 24–48 ساعة' : '48h Rush Available'}
                      </span>
                    </div>
                    <h3 className="font-display text-lg font-semibold text-[#002B6B] mb-1.5">
                      {isAr ? 'تيجان وكباري CAD/CAM' : 'Digital CAD/CAM Bridges & Provisionals'}
                    </h3>
                    <p className="text-sm text-slate-600 leading-relaxed">
                      {isAr
                        ? 'استقبال ملفات TRIOS وiTero وMedit مع تحديث مباشر من المندوب والمعمل.'
                        : 'Seamless intake from TRIOS, iTero, Medit, and Primescan with live courier and stage updates.'}
                    </p>
                  </div>
                </article>

                <article className="glass-panel glass-interactive rounded-2xl overflow-hidden flex-1 flex flex-col">
                  <div className="aspect-[16/9] bg-slate-200 overflow-hidden">
                    <SafeImage
                      src={LAB_IMAGES.implants.src}
                      alt={LAB_IMAGES.implants.alt}
                      fallbackTitle="Custom Titanium Implant Prosthetics"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-6">
                    <div className="text-xs text-slate-500 mb-1.5 flex items-center gap-2">
                      <span>{isAr ? 'تركيبات الزراعة' : 'Implantology'}</span>
                      <span aria-hidden="true">·</span>
                      <span>{isAr ? 'دعامات تيتانيوم وبارات' : 'Titanium Bars & Abutments'}</span>
                    </div>
                    <h3 className="font-display text-lg font-semibold text-[#002B6B] mb-1.5">
                      {isAr ? 'دعامات الزراعة والموديلات الجراحية' : 'Multi-Unit Bars & Surgical Models'}
                    </h3>
                    <p className="text-sm text-slate-600 leading-relaxed">
                      {isAr
                        ? 'متابعة دقيقة مع فني الزراعة وموافقة الدكتور قبل التسليم النهائي.'
                        : 'Coordinate emergence profile checks, screw-access angulation, and doctor approval before dispatch.'}
                    </p>
                  </div>
                </article>
              </div>
            </div>
          </div>
        </section>

        {/* 03. Security & Role Separation */}
        <section id="security" className="py-12 lg:py-16">
          <div className="max-w-7xl mx-auto px-6">
            <div className="glass-panel rounded-3xl p-8 lg:p-12 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-7">
                <h2 className="font-display text-2xl lg:text-3xl font-bold tracking-tight text-[#002B6B] text-balance mb-4">
                  {isAr
                    ? 'خصوصية كاملة ومحادثات مشفرة لكل حالة.'
                    : 'Strict clinic-to-lab isolation for every prescription.'}
                </h2>
                <p className="text-sm text-slate-600 leading-relaxed mb-6 max-w-2xl">
                  {isAr
                    ? 'الدكتور صاحب الحالة والمعمل المختص بس هم اللي يقدروا يشوفوا تفاصيل الحالة والأشعة. وكل الرسايل بتتشفر AES-256-GCM وبتتسجل في سجل حفظ دائم.'
                    : 'Only the prescribing dental doctor and the assigned dental laboratory can view a case, inspect radiographs, or exchange AES-256-GCM encrypted messages.'}
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm text-slate-700">
                  <div className="flex items-start gap-2.5">
                    <ShieldCheck className="w-4 h-4 text-[#00A8B5] mt-0.5 shrink-0" />
                    <span>
                      {isAr ? 'تشفير AES-256 للرسايل' : 'AES-256-GCM encrypted messaging'}
                    </span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <FileCheck2 className="w-4 h-4 text-[#00A8B5] mt-0.5 shrink-0" />
                    <span>
                      {isAr ? 'سجل متابعة غير قابل للتعديل' : 'Immutable audit log ledger'}
                    </span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-[#00A8B5] mt-0.5 shrink-0" />
                    <span>
                      {isAr ? 'اعتماد الدكتور قبل التسليم' : 'Verified delivery sign-off'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-5 lg:text-end">
                <button
                  type="button"
                  onClick={onSignIn}
                  disabled={signingIn}
                  className="btn-glass-primary inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold rounded-xl disabled:opacity-60 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00A8B5] focus-visible:ring-offset-2"
                >
                  <span>{isAr ? 'ادخل منصة لابي' : 'Enter Labi Workspace'}</span>
                  <ArrowIcon className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Quiet Footer */}
      <footer className="glass-nav border-t py-7">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-600">
          <div className="flex items-center gap-3">
            <BrandLogo size="sm" />
            <span aria-hidden="true">·</span>
            <span>
              {isAr
                ? 'ربط دكاترة الأسنان بمعامل التركيبات'
                : 'Dental Doctor & Laboratory Case Coordination'}
            </span>
          </div>
          <div>
            <span>© {new Date().getFullYear()} Labi Clinical Network</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
