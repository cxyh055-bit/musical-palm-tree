import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Check, Crown, FileText, MapPin, Percent, Star, Truck, Wallet } from 'lucide-react';
import { LABI_LOGO_SRC } from './BrandLogo';

interface LandingViewProps {
  onSignIn: () => void;
  onSignUp: () => void;
}

const LABS = [
  { name: 'ديجيتال سمايل', area: 'المعادي', km: '1.2', rate: '4.9', price: 'إيماكس من 1,800 ج', top: true },
  { name: 'معمل إيليت', area: 'مدينة نصر', km: '4.5', rate: '4.7', price: 'زيركون من 900 ج', top: false },
  { name: 'معمل أرك للزراعة', area: 'الشيخ زايد', km: '16', rate: '4.8', price: 'زراعة من 2,400 ج', top: false },
];

function Card({ children }: { children: ReactNode }) {
  return (
    <div className="w-full max-w-sm rounded-3xl bg-white p-4 shadow-[0_18px_40px_rgba(0,20,60,0.35)] text-[#0B1E3B]">
      {children}
    </div>
  );
}

function LabsMock() {
  return (
    <Card>
      <div className="mb-3 flex items-center gap-2 text-sm font-bold text-[#002B6B]">
        <MapPin className="h-4 w-4 text-[#00A8B5]" />
        المعامل القريبة منك
      </div>
      <div className="space-y-2.5">
        {LABS.map((l) => (
          <div
            key={l.name}
            className={`flex items-center justify-between rounded-2xl border p-3 ${
              l.top ? 'border-[#00A8B5]/50 bg-[#00A8B5]/[0.07]' : 'border-[#E1ECF5]'
            }`}
          >
            <div>
              <div className="flex items-center gap-1.5 text-[13px] font-bold text-[#002B6B]">
                {l.name}
                {l.top && <Crown className="h-3.5 w-3.5 text-[#E0A100]" />}
              </div>
              <div className="mt-0.5 text-[11px] text-[#4b6483]">{l.area} · {l.price}</div>
            </div>
            <div className="text-left">
              <div className="text-[12px] font-bold text-[#007a84]">{l.km} كم</div>
              <div className="flex items-center gap-0.5 text-[11px] text-[#4b6483]">
                <Star className="h-3 w-3 fill-[#F5B301] text-[#F5B301]" />
                {l.rate}
              </div>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}

function RxMock() {
  const selected = [7, 8, 9];
  return (
    <Card>
      <div className="mb-3 flex items-center gap-2 text-sm font-bold text-[#002B6B]">
        <FileText className="h-4 w-4 text-[#00A8B5]" />
        روشتة رقمية
      </div>
      <div className="grid grid-cols-8 gap-1.5" dir="ltr">
        {Array.from({ length: 16 }, (_, i) => i + 1).map((n) => (
          <div
            key={n}
            className={`flex aspect-square items-center justify-center rounded-lg text-[10px] font-semibold ${
              selected.includes(n) ? 'bg-[#00A8B5] text-white' : 'border border-[#D3E2EF] text-[#5a7391]'
            }`}
          >
            {n}
          </div>
        ))}
      </div>
      <div className="mt-3 flex flex-wrap gap-1.5 text-[11px]">
        <span className="rounded-full bg-[#EEF5FA] px-2.5 py-1 text-[#31496a]">طربوش زيركون</span>
        <span className="rounded-full bg-[#EEF5FA] px-2.5 py-1 text-[#31496a]">درجة A2</span>
        <span className="rounded-full bg-[#EEF5FA] px-2.5 py-1 text-[#31496a]">أشعة مرفقة</span>
      </div>
      <div className="mt-3 rounded-xl bg-[#002B6B] py-2.5 text-center text-[13px] font-bold text-white">
        ابعت للمعمل
      </div>
    </Card>
  );
}

function TrackMock() {
  const steps = [
    { t: 'اتاخد المقاس من العيادة', done: true },
    { t: 'المندوب استلم الشغل', done: true },
    { t: 'وصل المعمل', done: true },
    { t: 'تحت التصنيع', done: false, current: true },
    { t: 'الدليفري جاي لك', done: false },
  ];
  return (
    <Card>
      <div className="mb-2 flex items-center justify-between text-sm font-bold text-[#002B6B]">
        <span className="flex items-center gap-2">
          <Truck className="h-4 w-4 text-[#00A8B5]" />
          تتبع الحالة
        </span>
        <span className="text-[11px] font-semibold text-[#007a84]">باقي 24 ساعة</span>
      </div>
      <div className="mb-3 h-2 overflow-hidden rounded-full bg-[#D6E5F1]">
        <div className="h-full w-[62%] rounded-full bg-[linear-gradient(90deg,#002B6B,#00A8B5)]" />
      </div>
      <div className="space-y-2">
        {steps.map((s) => (
          <div key={s.t} className="flex items-center gap-2.5 text-[12px]">
            <span
              className={`flex h-4 w-4 items-center justify-center rounded-full ${
                s.done ? 'bg-[#00A8B5] text-white' : s.current ? 'border-2 border-[#00A8B5] bg-white' : 'bg-[#D6E5F1]'
              }`}
            >
              {s.done && <Check className="h-3 w-3" />}
            </span>
            <span className={s.done || s.current ? 'font-semibold text-[#002B6B]' : 'text-[#7a90a8]'}>{s.t}</span>
          </div>
        ))}
      </div>
    </Card>
  );
}

function PayMock() {
  return (
    <Card>
      <div className="mb-3 flex items-center gap-2 text-sm font-bold text-[#002B6B]">
        <Wallet className="h-4 w-4 text-[#00A8B5]" />
        الدفع والفواتير
      </div>
      <div className="grid grid-cols-2 gap-2.5">
        <div className="rounded-2xl border border-[#00A8B5]/50 bg-[#00A8B5]/[0.07] p-3 text-center text-[12px] font-bold text-[#002B6B]">
          إنستاباي
        </div>
        <div className="rounded-2xl border border-[#E1ECF5] p-3 text-center text-[12px] font-bold text-[#002B6B]">
          محفظة موبايل
        </div>
      </div>
      <div className="mt-3 flex items-center justify-between rounded-2xl bg-[#EEF5FA] p-3 text-[12px]">
        <div>
          <div className="font-bold text-[#002B6B]">فاتورة رقمية</div>
          <div className="text-[11px] text-[#4b6483]">طربوش زيركون · 3 أسنان</div>
        </div>
        <div className="text-left">
          <div className="font-bold text-[#002B6B]">2,450 ج</div>
          <div className="flex items-center gap-1 text-[11px] font-semibold text-[#00868f]">
            <Check className="h-3 w-3" /> مدفوعة
          </div>
        </div>
      </div>
    </Card>
  );
}

function PlansMock() {
  return (
    <Card>
      <div className="mb-3 flex items-center justify-between text-sm font-bold text-[#002B6B]">
        <span>الاشتراكات</span>
        <span className="rounded-full bg-[#FFF3D1] px-2 py-0.5 text-[10px] font-bold text-[#8a6100]">قريباً</span>
      </div>
      <div className="grid grid-cols-2 gap-2.5">
        <div className="rounded-2xl border border-[#E1ECF5] p-3">
          <Percent className="mb-2 h-5 w-5 text-[#00A8B5]" />
          <div className="text-[13px] font-bold text-[#002B6B]">للدكتور</div>
          <div className="mt-1 text-[11px] leading-5 text-[#4b6483]">خصم على أسعار المعامل</div>
        </div>
        <div className="rounded-2xl border border-[#E1ECF5] p-3">
          <Crown className="mb-2 h-5 w-5 text-[#E0A100]" />
          <div className="text-[13px] font-bold text-[#002B6B]">للمعمل</div>
          <div className="mt-1 text-[11px] leading-5 text-[#4b6483]">يظهر أول القايمة للدكاترة</div>
        </div>
      </div>
    </Card>
  );
}

const SLIDES: { title: string; desc: string; mock: ReactNode }[] = [
  { title: 'اختار أقرب معمل ليك', desc: 'قارن المعامل بالمسافة والأسعار والتقييمات، واختار الأنسب لشغلك.', mock: <LabsMock /> },
  { title: 'روشتة رقمية بضغطة', desc: 'حدد الأسنان على الخريطة، ارفع الأشعة، والروشتة توصل المعمل فوراً.', mock: <RxMock /> },
  { title: 'تابع شغلك لحظة بلحظة', desc: 'المندوب بيستلم من العيادة ويوصل المعمل، وانت شايف كل خطوة.', mock: <TrackMock /> },
  { title: 'فواتير وسداد من موبايلك', desc: 'فاتورة رقمية لكل حالة، وسداد بإنستاباي أو محفظة الموبايل.', mock: <PayMock /> },
  { title: 'اشتراكات تفرق معاك', desc: 'الدكتور بياخد خصومات، والمعمل بيظهر الأول في القايمة.', mock: <PlansMock /> },
];

export function LandingView({ onSignIn, onSignUp }: LandingViewProps) {
  const [index, setIndex] = useState(0);
  const indexRef = useRef(0);
  const touched = useRef(false);
  const scroller = useRef<HTMLDivElement>(null);

  const goTo = (i: number) => {
    const el = scroller.current?.children[i] as HTMLElement | undefined;
    el?.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
  };

  useEffect(() => {
    const t = setInterval(() => {
      if (touched.current) return;
      goTo((indexRef.current + 1) % SLIDES.length);
    }, 4500);
    return () => clearInterval(t);
  }, []);

  const onScroll = () => {
    const el = scroller.current;
    if (!el || !el.clientWidth) return;
    const i = Math.round(Math.abs(el.scrollLeft) / el.clientWidth);
    if (i !== indexRef.current && i >= 0 && i < SLIDES.length) {
      indexRef.current = i;
      setIndex(i);
    }
  };

  return (
    <div className="fixed inset-0 flex flex-col overflow-hidden bg-[linear-gradient(160deg,#002B6B_0%,#003F94_58%,#00A8B5_150%)] text-white">
      <div className="pointer-events-none absolute -top-24 -left-24 h-72 w-72 rounded-full bg-[#00A8B5]/30 blur-3xl" />
      <div className="pointer-events-none absolute top-1/3 -right-28 h-72 w-72 rounded-full bg-white/10 blur-3xl" />

      <div
        className="relative flex items-center justify-center gap-3 px-6 pb-3"
        style={{ paddingTop: 'max(env(safe-area-inset-top, 0px), 40px)' }}
      >
        <div className="flex h-12 w-12 items-center justify-center overflow-hidden rounded-2xl bg-white shadow-lg">
          <img src={LABI_LOGO_SRC} alt="Labi" className="h-11 w-11 object-contain" />
        </div>
        <div className="text-right">
          <div className="text-xl font-bold leading-tight">لابي</div>
          <div className="text-[11px] text-white/75">شبكة دكاترة الأسنان ومعامل التركيبات</div>
        </div>
      </div>

      <div
        ref={scroller}
        onScroll={onScroll}
        onTouchStart={() => {
          touched.current = true;
        }}
        className="no-scrollbar relative flex min-h-0 flex-1 snap-x snap-mandatory overflow-x-auto"
      >
        {SLIDES.map((s) => (
          <section
            key={s.title}
            className="flex h-full min-w-full snap-center flex-col items-center justify-center gap-5 overflow-hidden px-6"
          >
            {s.mock}
            <div className="max-w-sm text-center">
              <h2 className="text-xl font-bold">{s.title}</h2>
              <p className="mt-1.5 text-[13px] leading-6 text-white/80">{s.desc}</p>
            </div>
          </section>
        ))}
      </div>

      <div className="relative flex justify-center gap-1.5 pb-3 pt-1">
        {SLIDES.map((s, i) => (
          <button
            key={s.title}
            type="button"
            aria-label={`slide ${i + 1}`}
            onClick={() => {
              touched.current = true;
              goTo(i);
            }}
            className={`h-1.5 rounded-full transition-all ${i === index ? 'w-6 bg-white' : 'w-1.5 bg-white/40'}`}
          />
        ))}
      </div>

      <div
        className="relative rounded-t-[32px] bg-[#F7FBFE] px-6 pt-5 shadow-[0_-12px_40px_rgba(0,20,60,0.25)]"
        style={{ paddingBottom: 'max(env(safe-area-inset-bottom, 0px), 20px)' }}
      >
        <div className="mx-auto flex w-full max-w-md flex-col gap-2.5">
          <button
            type="button"
            onClick={onSignUp}
            className="w-full rounded-2xl bg-[#002B6B] py-3.5 text-[15px] font-bold text-white shadow-[0_8px_20px_rgba(0,43,107,0.35)] active:scale-[0.98]"
          >
            ابدأ دلوقتي
          </button>
          <button
            type="button"
            onClick={onSignIn}
            className="w-full rounded-2xl border border-[#CFE0EE] bg-white py-3.5 text-[15px] font-semibold text-[#002B6B] active:scale-[0.98]"
          >
            عندي حساب؟ سجّل دخول
          </button>
        </div>
      </div>
    </div>
  );
}
