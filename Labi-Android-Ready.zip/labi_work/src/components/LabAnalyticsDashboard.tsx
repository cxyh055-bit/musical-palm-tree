import { useMemo, useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { BarChart3, FilePlus2, Sparkles } from 'lucide-react';
import { RESTORATION_LABELS_AR, useLang } from '../i18n';
import {
  RESTORATION_TYPES,
  type DentalCase,
  type DentalLab,
  type RestorationType,
} from '../types';

interface LabAnalyticsDashboardProps {
  labCases: DentalCase[];
  ownLabs: DentalLab[];
  loading: boolean;
  seedingSample: boolean;
  onSeedSample: () => void;
  onOpenNewCase: () => void;
}

type RangeFilter = '3m' | '6m' | 'all';
type PriorityFilter = 'All' | 'Standard' | 'Rush';

const MONTH_NAMES_AR = [
  'يناير',
  'فبراير',
  'مارس',
  'أبريل',
  'مايو',
  'يونيو',
  'يوليو',
  'أغسطس',
  'سبتمبر',
  'أكتوبر',
  'نوفمبر',
  'ديسمبر',
];

const MONTH_NAMES_EN = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
];

const SERVICE_BAR_COLORS = [
  '#002b6b',
  '#00a8b5',
  '#0d47a1',
  '#007c87',
  '#1e3a8a',
  '#334155',
  '#0284c7',
];

function getCaseCreatedDate(c: DentalCase): Date {
  if (c.createdAt && typeof c.createdAt.toDate === 'function') {
    return c.createdAt.toDate();
  }
  if (c.dueDate) {
    const parsed = new Date(`${c.dueDate}T12:00:00`);
    if (!Number.isNaN(parsed.getTime())) return parsed;
  }
  return new Date();
}

function getCaseTurnaroundDays(c: DentalCase, fallbackSlaDays: number): number {
  const createdMs = getCaseCreatedDate(c).getTime();
  const isCompleted = c.status === 'completed' || c.status === 'delivered';

  if (isCompleted && c.updatedAt && typeof c.updatedAt.toMillis === 'function') {
    const elapsedHours = (c.updatedAt.toMillis() - createdMs) / 3600000;
    if (elapsedHours >= 6) {
      return Math.round((elapsedHours / 24) * 10) / 10;
    }
  }

  if (c.dueDate) {
    const dueMs = new Date(`${c.dueDate}T12:00:00`).getTime();
    if (!Number.isNaN(dueMs)) {
      const leadDays = (dueMs - createdMs) / 86400000;
      if (leadDays >= 0.5 && leadDays <= 45) {
        return Math.round(leadDays * 10) / 10;
      }
    }
  }

  return c.priority === 'Rush' ? Math.max(1, Math.round(fallbackSlaDays * 0.6 * 10) / 10) : fallbackSlaDays;
}

function formatMonthKey(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  return `${y}-${m}`;
}

export function LabAnalyticsDashboard({
  labCases,
  ownLabs,
  loading,
  seedingSample,
  onSeedSample,
  onOpenNewCase,
}: LabAnalyticsDashboardProps) {
  const { lang } = useLang();
  const isAr = lang === 'ar';

  const [rangeFilter, setRangeFilter] = useState<RangeFilter>('6m');
  const [priorityFilter, setPriorityFilter] = useState<PriorityFilter>('All');
  const [selectedLabId, setSelectedLabId] = useState<string>('all');

  const labSlaMap = useMemo(() => {
    const map = new Map<string, number>();
    for (const l of ownLabs) {
      map.set(l.id, l.turnaroundDays || 4);
    }
    return map;
  }, [ownLabs]);

  const targetSlaDays = useMemo(() => {
    if (selectedLabId !== 'all') {
      return labSlaMap.get(selectedLabId) ?? 4;
    }
    if (ownLabs.length === 0) return 4;
    const sum = ownLabs.reduce((acc, l) => acc + (l.turnaroundDays || 4), 0);
    return Math.round((sum / ownLabs.length) * 10) / 10;
  }, [ownLabs, labSlaMap, selectedLabId]);

  const filteredCases = useMemo(() => {
    const now = new Date();
    const monthsBack = rangeFilter === '3m' ? 3 : rangeFilter === '6m' ? 6 : 60;
    const cutoff = new Date(now.getFullYear(), now.getMonth() - (monthsBack - 1), 1);

    return labCases.filter((c) => {
      if (selectedLabId !== 'all' && c.labId !== selectedLabId) return false;
      if (priorityFilter !== 'All' && c.priority !== priorityFilter) return false;
      if (rangeFilter !== 'all') {
        const created = getCaseCreatedDate(c);
        if (created < cutoff) return false;
      }
      return true;
    });
  }, [labCases, rangeFilter, priorityFilter, selectedLabId]);

  const kpis = useMemo(() => {
    const total = filteredCases.length;
    const completed = filteredCases.filter((c) =>
      ['completed', 'delivered'].includes(c.status)
    ).length;
    const revisions = filteredCases.filter((c) => c.status === 'revision_requested').length;
    const rushCount = filteredCases.filter((c) => c.priority === 'Rush').length;
    const totalRevenue = filteredCases.reduce((sum, c) => sum + (c.estimatedFee || 0), 0);

    const turnarounds = filteredCases.map((c) =>
      getCaseTurnaroundDays(c, labSlaMap.get(c.labId) ?? targetSlaDays)
    );
    const avgTurnaround =
      turnarounds.length > 0
        ? Math.round((turnarounds.reduce((a, b) => a + b, 0) / turnarounds.length) * 10) / 10
        : 0;

    const onTimeCount = filteredCases.filter((c, i) => {
      const labTarget = labSlaMap.get(c.labId) ?? targetSlaDays;
      return turnarounds[i] <= labTarget + 0.5;
    }).length;

    const completionRate = total > 0 ? Math.round((completed / total) * 100) : 0;
    const slaAdherenceRate = total > 0 ? Math.round((onTimeCount / total) * 100) : 0;
    const avgCaseFee = total > 0 ? Math.round(totalRevenue / total) : 0;

    return {
      total,
      completed,
      active: total - completed,
      revisions,
      rushCount,
      totalRevenue,
      avgCaseFee,
      avgTurnaround,
      completionRate,
      slaAdherenceRate,
    };
  }, [filteredCases, labSlaMap, targetSlaDays]);

  const monthlySeries = useMemo(() => {
    const now = new Date();
    const bucketCount = rangeFilter === '3m' ? 3 : 6;
    const buckets = new Map<
      string,
      {
        key: string;
        label: string;
        totalCases: number;
        completedCases: number;
        revenue: number;
        turnaroundSum: number;
      }
    >();

    // Initialize continuous calendar window so Recharts renders an unbroken timeline
    for (let i = bucketCount - 1; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = formatMonthKey(d);
      const label = isAr
        ? `${MONTH_NAMES_AR[d.getMonth()]} ${d.getFullYear()}`
        : `${MONTH_NAMES_EN[d.getMonth()]} ${d.getFullYear()}`;
      buckets.set(key, {
        key,
        label,
        totalCases: 0,
        completedCases: 0,
        revenue: 0,
        turnaroundSum: 0,
      });
    }

    for (const c of filteredCases) {
      const d = getCaseCreatedDate(c);
      const key = formatMonthKey(d);
      if (!buckets.has(key)) {
        const label = isAr
          ? `${MONTH_NAMES_AR[d.getMonth()]} ${d.getFullYear()}`
          : `${MONTH_NAMES_EN[d.getMonth()]} ${d.getFullYear()}`;
        buckets.set(key, {
          key,
          label,
          totalCases: 0,
          completedCases: 0,
          revenue: 0,
          turnaroundSum: 0,
        });
      }
      const entry = buckets.get(key)!;
      entry.totalCases += 1;
      if (['completed', 'delivered'].includes(c.status)) {
        entry.completedCases += 1;
      }
      entry.revenue += c.estimatedFee || 0;
      entry.turnaroundSum += getCaseTurnaroundDays(c, labSlaMap.get(c.labId) ?? targetSlaDays);
    }

    return Array.from(buckets.values())
      .sort((a, b) => a.key.localeCompare(b.key))
      .map((item) => ({
        ...item,
        avgTurnaround:
          item.totalCases > 0
            ? Math.round((item.turnaroundSum / item.totalCases) * 10) / 10
            : 0,
      }));
  }, [filteredCases, rangeFilter, isAr, labSlaMap, targetSlaDays]);

  const serviceBreakdown = useMemo(() => {
    const counts = new Map<
      RestorationType,
      {
        service: RestorationType;
        label: string;
        cases: number;
        units: number;
        revenue: number;
        turnaroundSum: number;
        revisions: number;
      }
    >();

    for (const srv of RESTORATION_TYPES) {
      counts.set(srv, {
        service: srv,
        label: isAr ? (RESTORATION_LABELS_AR[srv] || srv).split(' (')[0] : srv,
        cases: 0,
        units: 0,
        revenue: 0,
        turnaroundSum: 0,
        revisions: 0,
      });
    }

    for (const c of filteredCases) {
      const bucket = counts.get(c.restorationType);
      if (!bucket) continue;
      bucket.cases += 1;
      bucket.units += Math.max(1, c.toothNumbers?.length || 1);
      bucket.revenue += c.estimatedFee || 0;
      bucket.turnaroundSum += getCaseTurnaroundDays(c, labSlaMap.get(c.labId) ?? targetSlaDays);
      if (c.status === 'revision_requested') bucket.revisions += 1;
    }

    const total = Math.max(1, filteredCases.length);
    return Array.from(counts.values())
      .filter((s) => s.cases > 0)
      .sort((a, b) => b.cases - a.cases || b.revenue - a.revenue)
      .map((s) => ({
        ...s,
        sharePct: Math.round((s.cases / total) * 100),
        avgTurnaround: Math.round((s.turnaroundSum / s.cases) * 10) / 10,
        avgFee: Math.round(s.revenue / s.cases),
        revisionRate: Math.round((s.revisions / s.cases) * 100),
      }));
  }, [filteredCases, isAr, labSlaMap, targetSlaDays]);

  const primaryCurrency = useMemo(() => {
    const first = filteredCases.find((c) => c.currency);
    return (first?.currency || 'EGP') === 'EGP' ? (isAr ? 'ج.م' : 'EGP') : 'USD';
  }, [filteredCases, isAr]);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-24 glass-panel rounded-2xl animate-pulse" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="h-80 glass-panel rounded-2xl animate-pulse" />
          <div className="h-80 glass-panel rounded-2xl animate-pulse" />
        </div>
      </div>
    );
  }

  if (labCases.length === 0) {
    return (
      <div className="glass-panel rounded-2xl p-12 text-center space-y-4">
        <div className="w-12 h-12 rounded-2xl glass-surface flex items-center justify-center mx-auto text-[#002B6B]">
          <BarChart3 className="w-6 h-6 text-[#00A8B5]" />
        </div>
        <div className="space-y-1 max-w-md mx-auto">
          <h2 className="font-display text-lg font-semibold text-[#002B6B]">
            {isAr
              ? 'مفيش بيانات كافية لتحليلات المعمل لسه'
              : 'No laboratory cases recorded for analytics yet'}
          </h2>
          <p className="text-sm text-slate-600">
            {isAr
              ? 'بمجرد ما تستقبل روشتات في معملك أو تحمّل البيانات التجريبية، هيظهر هنا حجم الشغل الشهري، متوسط وقت التسليم، وأكتر الخدمات طلباً.'
              : 'Once prescriptions are routed to your laboratory or you load sample cases, monthly case volume, average turnaround time, and top dental services will appear here.'}
          </p>
        </div>
        <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
          <button
            type="button"
            disabled={seedingSample}
            onClick={onSeedSample}
            className="btn-glass-primary inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-xl disabled:opacity-60 cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-[#00A8B5]" />
            <span>
              {seedingSample
                ? isAr
                  ? 'جاري تجهيز البيانات...'
                  : 'Loading Sample Data...'
                : isAr
                  ? 'تحميل معامل وحالات تجريبية'
                  : 'Load Sample Labs & Cases'}
            </span>
          </button>
          <button
            type="button"
            onClick={onOpenNewCase}
            className="btn-glass-secondary inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-[#002B6B] rounded-xl cursor-pointer"
          >
            <FilePlus2 className="w-4 h-4 text-[#00A8B5]" />
            <span>{isAr ? 'إنشاء روشتة جديدة' : 'Create Prescription'}</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header & Interactive Filters */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-xl font-bold text-[#002B6B]">
            {isAr
              ? 'لوحة مؤشرات أداء المعمل (KPIs)'
              : 'Laboratory Performance & KPI Analytics'}
          </h2>
          <p className="text-sm text-slate-600 mt-0.5">
            {isAr
              ? 'متابعة مباشرة لحجم الحالات الشهري، متوسط سرعة التسليم، والخدمات الأكتر طلباً في المعمل.'
              : 'Real-time operational metrics covering monthly case volume, turnaround adherence, and service mix.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {ownLabs.length > 1 && (
            <select
              aria-label={isAr ? 'تصفية حسب المعمل' : 'Filter by laboratory'}
              value={selectedLabId}
              onChange={(e) => setSelectedLabId(e.target.value)}
              className="px-3 py-1.5 text-xs font-medium glass-input rounded-xl text-[#002B6B]"
            >
              <option value="all">{isAr ? 'كل معاملي' : 'All My Labs'}</option>
              {ownLabs.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name}
                </option>
              ))}
            </select>
          )}

          {/* Priority Filter */}
          <div className="inline-flex items-center p-1 glass-surface rounded-xl">
            {(
              [
                { id: 'All', label: isAr ? 'كل الأولويات' : 'All Priority' },
                { id: 'Standard', label: isAr ? 'عادي' : 'Standard' },
                { id: 'Rush', label: isAr ? 'مستعجل' : 'Rush' },
              ] as { id: PriorityFilter; label: string }[]
            ).map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setPriorityFilter(p.id)}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
                  priorityFilter === p.id
                    ? 'bg-[#002B6B] text-white shadow-xs'
                    : 'text-slate-600 hover:text-[#002B6B]'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Timeframe Filter */}
          <div className="inline-flex items-center p-1 glass-surface rounded-xl">
            {(
              [
                { id: '3m', label: isAr ? '3 شهور' : '3M' },
                { id: '6m', label: isAr ? '6 شهور' : '6M' },
                { id: 'all', label: isAr ? 'الكل' : 'All' },
              ] as { id: RangeFilter; label: string }[]
            ).map((r) => (
              <button
                key={r.id}
                type="button"
                onClick={() => setRangeFilter(r.id)}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
                  rangeFilter === r.id
                    ? 'bg-[#002B6B] text-white shadow-xs'
                    : 'text-slate-600 hover:text-[#002B6B]'
                }`}
              >
                {r.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 4-Column KPI Summary Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 glass-panel rounded-2xl divide-y lg:divide-y-0 lg:divide-x rtl:lg:divide-x-reverse divide-[#002B6B]/10 overflow-hidden">
        <div className="p-5">
          <div className="text-xs font-medium text-slate-500">
            {isAr ? 'إجمالي الحالات' : 'Total Case Volume'}
          </div>
          <div className="font-mono tabular-nums text-2xl font-bold text-[#002B6B] mt-1">
            {kpis.total}
          </div>
          <div className="text-xs text-slate-600 mt-1 font-mono tabular-nums">
            {isAr
              ? `${kpis.completed} منجز · ${kpis.active} شغال`
              : `${kpis.completed} completed · ${kpis.active} active`}
          </div>
        </div>

        <div className="p-5">
          <div className="text-xs font-medium text-slate-500">
            {isAr ? 'متوسط وقت التسليم' : 'Avg Turnaround Time'}
          </div>
          <div className="font-mono tabular-nums text-2xl font-bold text-[#002B6B] mt-1">
            {kpis.avgTurnaround} {isAr ? 'يوم' : 'days'}
          </div>
          <div className="text-xs text-[#008C99] font-medium mt-1 font-mono tabular-nums">
            {isAr ? `الهدف (SLA): ${targetSlaDays} يوم` : `Target SLA: ${targetSlaDays}d`}
          </div>
        </div>

        <div className="p-5">
          <div className="text-xs font-medium text-slate-500">
            {isAr ? 'الالتزام بالمواعيد (SLA)' : 'On-Time SLA Adherence'}
          </div>
          <div className="font-mono tabular-nums text-2xl font-bold text-[#008C99] mt-1">
            {kpis.slaAdherenceRate}%
          </div>
          <div className="text-xs text-slate-600 mt-1 font-mono tabular-nums">
            {isAr
              ? `إنجاز ${kpis.completionRate}% · تعديلات ${kpis.revisions}`
              : `${kpis.completionRate}% completed · ${kpis.revisions} revisions`}
          </div>
        </div>

        <div className="p-5">
          <div className="text-xs font-medium text-slate-500">
            {isAr ? 'إجمالي قيمة الشغل' : 'Total Case Revenue'}
          </div>
          <div className="font-mono tabular-nums text-2xl font-bold text-[#002B6B] mt-1">
            {kpis.totalRevenue.toLocaleString()} {primaryCurrency}
          </div>
          <div className="text-xs text-slate-600 mt-1 font-mono tabular-nums">
            {isAr
              ? `متوسط الحالة: ${kpis.avgCaseFee.toLocaleString()} ${primaryCurrency}`
              : `Avg ${kpis.avgCaseFee.toLocaleString()} ${primaryCurrency} / case`}
          </div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Chart 1: Monthly Case Volume */}
        <section className="lg:col-span-7 glass-panel rounded-2xl p-5 space-y-4">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <div>
              <h3 className="font-display text-base font-semibold text-[#002B6B]">
                {isAr ? 'حجم الحالات الشهري والإنجاز' : 'Monthly Case Volume & Completion'}
              </h3>
              <p className="text-xs text-slate-600 mt-0.5">
                {isAr
                  ? 'مقارنة عدد الحالات المستلمة شهرياً بالحالات اللي اتسلمت وخلصت.'
                  : 'Total prescriptions routed per month compared with completed deliveries.'}
              </p>
            </div>
          </div>

          <div dir="ltr" className="w-full h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlySeries} margin={{ top: 10, right: 12, left: -12, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,43,107,0.08)" vertical={false} />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 11, fill: '#475569' }}
                  axisLine={{ stroke: 'rgba(0,43,107,0.14)' }}
                  tickLine={false}
                />
                <YAxis
                  allowDecimals={false}
                  tick={{ fontSize: 11, fill: '#475569' }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(255, 255, 255, 0.92)',
                    backdropFilter: 'blur(12px)',
                    borderColor: 'rgba(0, 168, 181, 0.35)',
                    borderRadius: '12px',
                    fontSize: '12px',
                    boxShadow: '0 8px 24px rgba(0, 43, 107, 0.1)',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '8px' }} />
                <Bar
                  dataKey="totalCases"
                  name={isAr ? 'إجمالي الحالات' : 'Total Cases'}
                  fill="#002b6b"
                  radius={[6, 6, 0, 0]}
                  maxBarSize={36}
                />
                <Bar
                  dataKey="completedCases"
                  name={isAr ? 'حالات منجزة' : 'Completed'}
                  fill="#00a8b5"
                  radius={[6, 6, 0, 0]}
                  maxBarSize={36}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>

        {/* Chart 2: Popular Dental Services */}
        <section className="lg:col-span-5 glass-panel rounded-2xl p-5 space-y-4">
          <div>
            <h3 className="font-display text-base font-semibold text-[#002B6B]">
              {isAr ? 'الخدمات السنية الأكتر طلباً' : 'Popular Dental Services'}
            </h3>
            <p className="text-xs text-slate-600 mt-0.5">
              {isAr
                ? 'توزيع الحالات حسب نوع التركيبة المطلوبة من العيادات.'
                : 'Case demand ranked by restoration service category.'}
            </p>
          </div>

          {serviceBreakdown.length === 0 ? (
            <div className="h-72 flex items-center justify-center text-xs text-slate-500">
              {isAr ? 'لا توجد حالات مطابقة للفلتر الحالي.' : 'No cases match current filter.'}
            </div>
          ) : (
            <div dir="ltr" className="w-full h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={serviceBreakdown}
                  layout="vertical"
                  margin={{ top: 6, right: 20, left: 12, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,43,107,0.08)" horizontal={false} />
                  <XAxis
                    type="number"
                    allowDecimals={false}
                    tick={{ fontSize: 11, fill: '#475569' }}
                    axisLine={{ stroke: 'rgba(0,43,107,0.14)' }}
                    tickLine={false}
                  />
                  <YAxis
                    type="category"
                    dataKey="label"
                    width={118}
                    tick={{ fontSize: 11, fill: '#0b1e3b' }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(255, 255, 255, 0.92)',
                      backdropFilter: 'blur(12px)',
                      borderColor: 'rgba(0, 168, 181, 0.35)',
                      borderRadius: '12px',
                      fontSize: '12px',
                      boxShadow: '0 8px 24px rgba(0, 43, 107, 0.1)',
                    }}
                    formatter={(value: unknown) => [
                      `${value} ${isAr ? 'حالة' : 'cases'}`,
                      isAr ? 'العدد' : 'Volume',
                    ]}
                  />
                  <Bar
                    dataKey="cases"
                    name={isAr ? 'عدد الحالات' : 'Cases'}
                    radius={[0, 6, 6, 0]}
                    maxBarSize={26}
                  >
                    {serviceBreakdown.map((entry, idx) => (
                      <Cell
                        key={entry.service}
                        fill={SERVICE_BAR_COLORS[idx % SERVICE_BAR_COLORS.length]}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </section>

        {/* Chart 3: Average Turnaround Time vs Target SLA by Service */}
        <section className="lg:col-span-6 glass-panel rounded-2xl p-5 space-y-4">
          <div>
            <h3 className="font-display text-base font-semibold text-[#002B6B]">
              {isAr
                ? 'متوسط وقت التسليم حسب الخدمة (مقابل الـ SLA)'
                : 'Average Turnaround Time by Service vs. SLA'}
            </h3>
            <p className="text-xs text-slate-600 mt-0.5">
              {isAr
                ? `متوسط أيام التنفيذ مقارنة بالحد المستهدف (${targetSlaDays} يوم).`
                : `Average turnaround days compared to target SLA (${targetSlaDays} days).`}
            </p>
          </div>

          {serviceBreakdown.length === 0 ? (
            <div className="h-72 flex items-center justify-center text-xs text-slate-500">
              {isAr ? 'لا توجد حالات مطابقة للفلتر الحالي.' : 'No cases match current filter.'}
            </div>
          ) : (
            <div dir="ltr" className="w-full h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={serviceBreakdown}
                  margin={{ top: 14, right: 16, left: -12, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,43,107,0.08)" vertical={false} />
                  <XAxis
                    dataKey="label"
                    tick={{ fontSize: 11, fill: '#475569' }}
                    axisLine={{ stroke: 'rgba(0,43,107,0.14)' }}
                    tickLine={false}
                  />
                  <YAxis
                    tick={{ fontSize: 11, fill: '#475569' }}
                    axisLine={false}
                    tickLine={false}
                    unit="d"
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(255, 255, 255, 0.92)',
                      backdropFilter: 'blur(12px)',
                      borderColor: 'rgba(0, 168, 181, 0.35)',
                      borderRadius: '12px',
                      fontSize: '12px',
                      boxShadow: '0 8px 24px rgba(0, 43, 107, 0.1)',
                    }}
                    formatter={(value: unknown) => [
                      `${value} ${isAr ? 'أيام' : 'days'}`,
                      isAr ? 'متوسط التسليم' : 'Avg Turnaround',
                    ]}
                  />
                  <ReferenceLine
                    y={targetSlaDays}
                    stroke="#00a8b5"
                    strokeDasharray="4 4"
                    label={{
                      value: `SLA ${targetSlaDays}d`,
                      position: 'insideTopRight',
                      fill: '#007c87',
                      fontSize: 11,
                    }}
                  />
                  <Bar
                    dataKey="avgTurnaround"
                    name={isAr ? 'متوسط أيام التسليم' : 'Avg Days'}
                    fill="#002b6b"
                    radius={[6, 6, 0, 0]}
                    maxBarSize={36}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </section>

        {/* Table 4: Dense KPI Breakdown by Service */}
        <section className="lg:col-span-6 glass-panel rounded-2xl overflow-hidden flex flex-col">
          <div className="p-5 border-b border-[#002B6B]/10">
            <h3 className="font-display text-base font-semibold text-[#002B6B]">
              {isAr ? 'ملخص الأداء لكل خدمة' : 'Service-Level KPI Breakdown'}
            </h3>
            <p className="text-xs text-slate-600 mt-0.5">
              {isAr
                ? 'عدد الحالات، الأسنان/الوحدات، متوسط وقت التنفيذ، والإيراد.'
                : 'Case count, prosthetic units, turnaround speed, and revenue.'}
            </p>
          </div>

          <div className="overflow-x-auto flex-1">
            <table className="w-full text-start border-collapse">
              <thead>
                <tr className="border-b border-[#002B6B]/10 bg-white/50 text-[11px] font-semibold text-slate-600">
                  <th className="py-2.5 px-4 text-start">{isAr ? 'الخدمة' : 'Service'}</th>
                  <th className="py-2.5 px-3 text-end">{isAr ? 'الحالات' : 'Cases'}</th>
                  <th className="py-2.5 px-3 text-end">{isAr ? 'الوحدات' : 'Units'}</th>
                  <th className="py-2.5 px-3 text-end">{isAr ? 'التسليم' : 'Avg SLA'}</th>
                  <th className="py-2.5 px-4 text-end">{isAr ? 'الإيراد' : 'Revenue'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#002B6B]/10 text-xs">
                {serviceBreakdown.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-slate-500">
                      {isAr ? 'لا توجد بيانات' : 'No matching records'}
                    </td>
                  </tr>
                ) : (
                  serviceBreakdown.map((row) => (
                    <tr key={row.service} className="h-11 hover:bg-white/60 transition-colors">
                      <td className="py-2 px-4 font-medium text-[#0B1E3B] whitespace-nowrap">
                        {row.label}
                        <span className="text-[#008C99] font-mono ms-1.5">
                          ({row.sharePct}%)
                        </span>
                      </td>
                      <td className="py-2 px-3 text-end font-mono tabular-nums text-[#0B1E3B]">
                        {row.cases}
                      </td>
                      <td className="py-2 px-3 text-end font-mono tabular-nums text-slate-600">
                        {row.units}
                      </td>
                      <td className="py-2 px-3 text-end font-mono tabular-nums text-[#0B1E3B]">
                        {row.avgTurnaround}d
                      </td>
                      <td className="py-2 px-4 text-end font-mono tabular-nums font-semibold text-[#002B6B] whitespace-nowrap">
                        {row.revenue.toLocaleString()} {primaryCurrency}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </div>
  );
}
