import { useEffect, useState, type ChangeEvent, type FormEvent } from 'react';
import {
  collection,
  doc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import {
  CheckCircle2,
  Clock,
  Download,
  Lock,
  PackageCheck,
  Phone,
  Receipt,
  RotateCcw,
  Send,
  ShieldCheck,
  Truck,
  Upload,
  X,
  ZoomIn,
} from 'lucide-react';
import { motion } from 'motion/react';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  MATERIAL_LABELS_AR,
  RESTORATION_LABELS_AR,
  STATUS_LABELS_BI,
  useLang,
} from '../i18n';
import {
  CASE_STAGE_ORDER,
  normalizeCaseStageIndex,
  VALIDATION,
  type CaseAuditLog,
  type CaseMessage,
  type CaseStatus,
  type CurrencyCode,
  type DentalCase,
  type DigitalInvoice,
  type MessageType,
  type UserProfile,
  type UserRole,
  type XrayAttachment,
} from '../types';
import { recordCaseAuditEvent } from '../utils/auditLog';
import { decryptCaseMessage, encryptCaseMessage } from '../utils/crypto';
import { processImageUpload } from '../utils/imageUpload';
import { sendCaseStatusNotification } from '../utils/notifications';
import { ToothChart } from './ToothChart';

interface CaseDetailDrawerProps {
  dentalCase: DentalCase;
  profile: UserProfile;
  activePerspective: UserRole;
  caseInvoice?: DigitalInvoice | null;
  onOpenCreateInvoice?: (dentalCase: DentalCase, existing?: DigitalInvoice | null) => void;
  onViewInvoice?: (invoice: DigitalInvoice) => void;
  onClose: () => void;
}

interface DecryptedMessageItem extends CaseMessage {
  decryptedText: string;
}

const NEXT_LAB_STAGE: Partial<Record<CaseStatus, CaseStatus>> = {
  submitted: 'courier_picked_up',
  courier_picked_up: 'courier_arrived_lab',
  courier_arrived_lab: 'received',
  received: 'in_progress',
  accepted: 'in_progress',
  revision_requested: 'in_progress',
  in_progress: 'awaiting_approval',
  in_design: 'awaiting_approval',
  milling: 'awaiting_approval',
  quality_check: 'out_for_delivery',
  awaiting_approval: 'out_for_delivery',
  out_for_delivery: 'completed',
  shipped: 'completed',
};

const QUICK_LAB_STAGES: CaseStatus[] = [
  'courier_picked_up',
  'courier_arrived_lab',
  'received',
  'in_progress',
  'awaiting_approval',
  'out_for_delivery',
  'completed',
];

const DEFAULT_TRACKING_NOTES: Record<'ar' | 'en', Partial<Record<CaseStatus, string>>> = {
  ar: {
    courier_picked_up: 'المندوب استلم المقاس / الحالة من العيادة وفي طريقه للمعمل.',
    courier_arrived_lab: 'المندوب وصل المعمل دلوقتي وبنسلم الشغل للفني المسؤول.',
    received: 'المعمل استلم الشغل وبنراجع المقاسات والأشعة.',
    in_progress: 'المعمل استلم الشغل وشغال فيه حالياً (تصميم وتصنيع CAD/CAM).',
    awaiting_approval: 'البروفة / التصميم جاهز ومستني موافقة الدكتور.',
    out_for_delivery: 'الدليفري جاي لك دلوقتي بالشغل على العيادة.',
    completed: 'الشغل وصل العيادة بالسلامة والعميل جاهز يركب دلوقتي.',
  },
  en: {
    courier_picked_up: 'Courier picked up the case from clinic and is heading to the lab.',
    courier_arrived_lab: 'Courier has arrived at the dental laboratory.',
    received: 'Laboratory received the case and verified scan/impressions.',
    in_progress: 'Technicians are actively fabricating the restoration.',
    awaiting_approval: 'Design / try-in is ready and awaiting doctor approval.',
    out_for_delivery: 'Courier is on the way to your clinic with the finished restoration.',
    completed: 'Delivered to clinic and ready for patient seating.',
  },
};

export function CaseDetailDrawer({
  dentalCase,
  profile,
  activePerspective,
  caseInvoice,
  onOpenCreateInvoice,
  onViewInvoice,
  onClose,
}: CaseDetailDrawerProps) {
  const { lang } = useLang();
  const isAr = lang === 'ar';
  const statusMap = STATUS_LABELS_BI[lang];

  const [rawMessages, setRawMessages] = useState<CaseMessage[]>([]);
  const [decryptedMessages, setDecryptedMessages] = useState<DecryptedMessageItem[]>([]);
  const [loadingMessages, setLoadingMessages] = useState(true);

  const [auditLogs, setAuditLogs] = useState<CaseAuditLog[]>([]);
  const [loadingAudit, setLoadingAudit] = useState(true);
  const [commsTab, setCommsTab] = useState<'thread' | 'audit'>('thread');

  const [messageText, setMessageText] = useState('');
  const [messageType, setMessageType] = useState<MessageType>('chat');
  const [sendingMsg, setSendingMsg] = useState(false);
  const [updatingStage, setUpdatingStage] = useState(false);

  const [trackingCode, setTrackingCode] = useState(dentalCase.trackingCode || '');
  const [courierName, setCourierName] = useState(dentalCase.courierName || '');
  const [courierPhone, setCourierPhone] = useState(dentalCase.courierPhone || '');
  const [courierEta, setCourierEta] = useState(dentalCase.courierEta || '');
  const [trackingNote, setTrackingNote] = useState(dentalCase.trackingNote || '');
  const [estimatedFee, setEstimatedFee] = useState(String(dentalCase.estimatedFee || 0));
  const [currency, setCurrency] = useState<CurrencyCode>(dentalCase.currency || 'EGP');

  const [editNotes, setEditNotes] = useState(dentalCase.clinicalNotes || '');
  const [editScanRef, setEditScanRef] = useState(dentalCase.scanReference || '');
  const [editRequiredWork, setEditRequiredWork] = useState(dentalCase.requiredLabWork || '');
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);
  const [lightboxXray, setLightboxXray] = useState<XrayAttachment | null>(null);
  const [xrayUploadError, setXrayUploadError] = useState<string | null>(null);

  useEffect(() => {
    setTrackingCode(dentalCase.trackingCode || '');
    setCourierName(dentalCase.courierName || '');
    setCourierPhone(dentalCase.courierPhone || '');
    setCourierEta(dentalCase.courierEta || '');
    setTrackingNote(dentalCase.trackingNote || '');
    setEstimatedFee(String(dentalCase.estimatedFee || 0));
    setCurrency(dentalCase.currency || 'EGP');
    setEditNotes(dentalCase.clinicalNotes || '');
    setEditScanRef(dentalCase.scanReference || '');
    setEditRequiredWork(dentalCase.requiredLabWork || '');
  }, [dentalCase]);

  // Subscribe to encrypted messages
  useEffect(() => {
    const messagesPath = `cases/${dentalCase.id}/messages`;
    const participantField =
      dentalCase.doctorUid === profile.uid ? 'doctorUid' : 'labOwnerUid';
    const q = query(
      collection(db, messagesPath),
      where(participantField, '==', profile.uid)
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const items = snapshot.docs
          .map((d) => d.data() as CaseMessage)
          .sort((a, b) => (a.createdAt?.toMillis?.() ?? 0) - (b.createdAt?.toMillis?.() ?? 0));
        setRawMessages(items);
        setLoadingMessages(false);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, messagesPath);
      }
    );

    return () => unsubscribe();
  }, [dentalCase.id, dentalCase.doctorUid, profile.uid]);

  // Decrypt incoming AES-256-GCM messages locally
  useEffect(() => {
    let active = true;
    async function decryptAll() {
      const results = await Promise.all(
        rawMessages.map(async (m) => {
          const legacyBody = (m as unknown as { body?: string }).body;
          if (!m.ciphertext && legacyBody) {
            return { ...m, decryptedText: legacyBody };
          }
          const plaintext = dentalCase.encryptionKeyB64
            ? await decryptCaseMessage(
                m.ciphertext,
                m.iv,
                dentalCase.encryptionKeyB64,
                dentalCase.id
              )
            : isAr
              ? '[مفتاح فك التشفير غير متوفر]'
              : '[Missing case decryption key]';
          return { ...m, decryptedText: plaintext };
        })
      );
      if (active) {
        setDecryptedMessages(results);
      }
    }
    void decryptAll();
    return () => {
      active = false;
    };
  }, [rawMessages, dentalCase.encryptionKeyB64, dentalCase.id, isAr]);

  // Subscribe to immutable audit logs
  useEffect(() => {
    const auditPath = `cases/${dentalCase.id}/auditLogs`;
    const participantField =
      dentalCase.doctorUid === profile.uid ? 'doctorUid' : 'labOwnerUid';
    const q = query(
      collection(db, auditPath),
      where(participantField, '==', profile.uid)
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const items = snapshot.docs
          .map((d) => d.data() as CaseAuditLog)
          .sort((a, b) => (a.createdAt?.toMillis?.() ?? 0) - (b.createdAt?.toMillis?.() ?? 0));
        setAuditLogs(items);
        setLoadingAudit(false);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, auditPath);
      }
    );

    return () => unsubscribe();
  }, [dentalCase.id, dentalCase.doctorUid, profile.uid]);

  const isDoctorOwner = dentalCase.doctorUid === profile.uid;
  const isLabOwner = dentalCase.labOwnerUid === profile.uid;
  const actingAsLab = isLabOwner && (!isDoctorOwner || activePerspective === 'lab');
  const actingAsDoctor = isDoctorOwner && (!isLabOwner || activePerspective === 'doctor');

  const isClosed = dentalCase.status === 'completed' || dentalCase.status === 'delivered';
  const nextStage = NEXT_LAB_STAGE[dentalCase.status];
  const currentStageIdx = normalizeCaseStageIndex(dentalCase.status);
  const xrays = dentalCase.xrayAttachments || [];
  const feeCurrencyLabel = currency === 'EGP' ? (isAr ? 'ج.م' : 'EGP') : 'USD';

  const messageTypeLabels: Record<MessageType, string> = isAr
    ? {
        chat: 'رسالة طبية',
        status_update: 'تحديث حالة / دليفري',
        info_request: 'طلب أشعة أو توضيح',
      }
    : {
        chat: 'Clinical Message',
        status_update: 'Case Update',
        info_request: 'Additional Info Request',
      };

  const handleAdvanceLabStage = async (targetStatus: CaseStatus) => {
    setUpdatingStage(true);
    setActionFeedback(null);
    const parsedFee = Math.min(VALIDATION.MAX_FEE, Math.max(0, Number(estimatedFee) || 0));
    const noteToSave = (
      trackingNote.trim() !== '' && trackingNote.trim() !== (dentalCase.trackingNote || '').trim()
        ? trackingNote.trim()
        : DEFAULT_TRACKING_NOTES[lang][targetStatus] || trackingNote.trim()
    ).slice(0, VALIDATION.TRACKING_NOTE_MAX);

    const path = `cases/${dentalCase.id}`;
    try {
      await updateDoc(doc(db, 'cases', dentalCase.id), {
        status: targetStatus,
        trackingCode: trackingCode.trim().slice(0, VALIDATION.TRACKING_MAX),
        courierName: courierName.trim().slice(0, VALIDATION.COURIER_NAME_MAX),
        courierPhone: courierPhone.trim().slice(0, VALIDATION.PHONE_MAX),
        courierEta: courierEta.trim().slice(0, VALIDATION.COURIER_ETA_MAX),
        trackingNote: noteToSave,
        estimatedFee: parsedFee,
        currency,
        updatedAt: serverTimestamp(),
      });
      setTrackingNote(noteToSave);

      await recordCaseAuditEvent({
        caseId: dentalCase.id,
        doctorUid: dentalCase.doctorUid,
        labOwnerUid: dentalCase.labOwnerUid,
        actorUid: profile.uid,
        actorName: profile.displayName,
        actorRole: 'lab',
        action: 'STATUS_UPDATED',
        summary: `${statusMap[targetStatus]}${noteToSave ? ` — ${noteToSave}` : ''}`.slice(0, 290),
      });
      await sendCaseStatusNotification({
        recipientUid: dentalCase.doctorUid,
        senderUid: profile.uid,
        caseId: dentalCase.id,
        caseCode: dentalCase.caseCode,
        labName: dentalCase.labName,
        clinicName: dentalCase.clinicName,
        newStatus: targetStatus,
        customNote: noteToSave,
      });
      setActionFeedback(
        isAr
          ? `تم تحديث الحالة إلى: ${statusMap[targetStatus]}`
          : `Case updated to ${statusMap[targetStatus]}.`
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    } finally {
      setUpdatingStage(false);
    }
  };

  const handleSaveLogisticsOnly = async () => {
    if (isClosed) return;
    const currentStatus =
      dentalCase.status === 'submitted' ? 'courier_picked_up' : dentalCase.status;
    await handleAdvanceLabStage(currentStatus);
  };

  const handleDoctorDecision = async (targetStatus: 'completed' | 'revision_requested') => {
    setUpdatingStage(true);
    setActionFeedback(null);
    const path = `cases/${dentalCase.id}`;
    const noteText =
      targetStatus === 'completed'
        ? isAr
          ? 'الدكتور استلم الشغل وأكّد المطابقة — العميل جاهز للتركيب.'
          : 'Doctor confirmed restoration fit and marked case Completed.'
        : isAr
          ? 'الدكتور طلب تعديل على الحالة قبل التسليم النهائي.'
          : 'Doctor requested revision before final delivery.';
    try {
      await updateDoc(doc(db, 'cases', dentalCase.id), {
        status: targetStatus,
        trackingNote: noteText,
        updatedAt: serverTimestamp(),
      });
      await recordCaseAuditEvent({
        caseId: dentalCase.id,
        doctorUid: dentalCase.doctorUid,
        labOwnerUid: dentalCase.labOwnerUid,
        actorUid: profile.uid,
        actorName: profile.displayName,
        actorRole: 'doctor',
        action: targetStatus === 'completed' ? 'CASE_COMPLETED' : 'REVISION_REQUESTED',
        summary: noteText,
      });
      await sendCaseStatusNotification({
        recipientUid: dentalCase.labOwnerUid,
        senderUid: profile.uid,
        caseId: dentalCase.id,
        caseCode: dentalCase.caseCode,
        labName: dentalCase.labName,
        clinicName: dentalCase.clinicName,
        newStatus: targetStatus,
        customNote: noteText,
      });
      setActionFeedback(
        targetStatus === 'completed'
          ? isAr
            ? 'تم تأكيد استلام الشغل واكتمال الحالة.'
            : 'Case approved and marked Completed.'
          : isAr
            ? 'تم إرسال طلب التعديل للمعمل.'
            : 'Revision requested. Laboratory notified.'
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    } finally {
      setUpdatingStage(false);
    }
  };

  const handleDoctorUpdateNotes = async (e: FormEvent) => {
    e.preventDefault();
    setUpdatingStage(true);
    setActionFeedback(null);
    const path = `cases/${dentalCase.id}`;
    try {
      await updateDoc(doc(db, 'cases', dentalCase.id), {
        shade: dentalCase.shade,
        scanReference: editScanRef.trim().slice(0, VALIDATION.SCAN_REF_MAX),
        requiredLabWork: editRequiredWork.trim().slice(0, VALIDATION.REQUIRED_WORK_MAX),
        xrayAttachments: xrays,
        priority: dentalCase.priority,
        dueDate: dentalCase.dueDate,
        clinicalNotes: editNotes.trim().slice(0, VALIDATION.NOTES_MAX),
        updatedAt: serverTimestamp(),
      });
      await recordCaseAuditEvent({
        caseId: dentalCase.id,
        doctorUid: dentalCase.doctorUid,
        labOwnerUid: dentalCase.labOwnerUid,
        actorUid: profile.uid,
        actorName: profile.displayName,
        actorRole: 'doctor',
        action: 'PRESCRIPTION_UPDATED',
        summary: 'Doctor updated clinical notes, lab work instructions, or scan reference',
      });
      setActionFeedback(
        isAr ? 'تم حفظ تعديلات الروشتة والملاحظات.' : 'Clinical notes and prescription details saved.'
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    } finally {
      setUpdatingStage(false);
    }
  };

  const handleAttachAdditionalXray = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setXrayUploadError(null);
    if (xrays.length >= VALIDATION.XRAY_MAX_COUNT) {
      setXrayUploadError(
        isAr
          ? `أقصى عدد هو ${VALIDATION.XRAY_MAX_COUNT} صور أشعة لكل حالة.`
          : `Maximum ${VALIDATION.XRAY_MAX_COUNT} X-ray images allowed per case.`
      );
      return;
    }

    try {
      const dataUrl = await processImageUpload(file, {
        maxDimension: 960,
        maxDataUrlChars: VALIDATION.XRAY_MAX_CHARS,
        initialQuality: 0.82,
      });
      const nextXrays: XrayAttachment[] = [
        ...xrays,
        {
          id: `xray-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
          name: file.name.slice(0, 80),
          dataUrl,
          uploadedAt: new Date().toISOString().slice(0, 19),
        },
      ];
      await updateDoc(doc(db, 'cases', dentalCase.id), {
        xrayAttachments: nextXrays,
        updatedAt: serverTimestamp(),
      });
      await recordCaseAuditEvent({
        caseId: dentalCase.id,
        doctorUid: dentalCase.doctorUid,
        labOwnerUid: dentalCase.labOwnerUid,
        actorUid: profile.uid,
        actorName: profile.displayName,
        actorRole: 'doctor',
        action: 'XRAY_ATTACHED',
        summary: `Doctor uploaded radiograph (${file.name.slice(0, 50)})`,
      });
      setActionFeedback(
        isAr ? 'تم رفع الأشعة وتسجيلها في سجل الحالة.' : 'Radiograph attached and logged.'
      );
    } catch (err) {
      setXrayUploadError(
        err instanceof Error
          ? err.message
          : isAr
            ? 'تعذر رفع صورة الأشعة.'
            : 'Unable to attach X-ray.'
      );
    }
    e.target.value = '';
  };

  const handleSendMessage = async (e: FormEvent) => {
    e.preventDefault();
    const trimmed = messageText.trim();
    if (!trimmed) return;

    const msgId = `msg-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`;
    const senderRole: UserRole = actingAsLab ? 'lab' : 'doctor';
    const path = `cases/${dentalCase.id}/messages/${msgId}`;

    setSendingMsg(true);
    try {
      const encrypted = await encryptCaseMessage(
        trimmed.slice(0, VALIDATION.MESSAGE_MAX),
        dentalCase.encryptionKeyB64,
        dentalCase.id
      );

      await setDoc(doc(db, `cases/${dentalCase.id}/messages`, msgId), {
        id: msgId,
        caseId: dentalCase.id,
        doctorUid: dentalCase.doctorUid,
        labOwnerUid: dentalCase.labOwnerUid,
        senderUid: profile.uid,
        senderName: profile.displayName,
        senderRole,
        messageType,
        ciphertext: encrypted.ciphertext,
        iv: encrypted.iv,
        algorithm: encrypted.algorithm,
        contentHash: encrypted.contentHash,
        createdAt: serverTimestamp(),
      });

      await recordCaseAuditEvent({
        caseId: dentalCase.id,
        doctorUid: dentalCase.doctorUid,
        labOwnerUid: dentalCase.labOwnerUid,
        actorUid: profile.uid,
        actorName: profile.displayName,
        actorRole: senderRole,
        action: 'ENCRYPTED_MESSAGE_LOGGED',
        summary: `${messageTypeLabels[messageType]} (AES-256-GCM, SHA-256 ${encrypted.contentHash.slice(0, 12)}…)`.slice(0, 290),
      });

      setMessageText('');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, path);
    } finally {
      setSendingMsg(false);
    }
  };

  const handleExportAuditCsv = () => {
    const header = ['Timestamp', 'Action', 'Actor', 'Role', 'Summary', 'DigestHash'];
    const rows = auditLogs.map((l) => [
      l.createdAt?.toDate ? l.createdAt.toDate().toISOString() : '',
      l.action,
      l.actorName,
      l.actorRole,
      `"${l.summary.replace(/"/g, '""')}"`,
      l.digestHash,
    ]);
    const csv = [header.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${dentalCase.caseCode}-audit-record.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const canDoctorEdit =
    actingAsDoctor &&
    [
      'submitted',
      'courier_picked_up',
      'courier_arrived_lab',
      'received',
      'revision_requested',
      'awaiting_approval',
    ].includes(dentalCase.status);

  const canDoctorDecide =
    actingAsDoctor &&
    ['awaiting_approval', 'out_for_delivery', 'shipped'].includes(dentalCase.status);

  return (
    <div
      className="fixed inset-0 z-50 bg-[#002B6B]/25 backdrop-blur-sm flex justify-end"
      role="dialog"
      aria-modal="true"
      aria-labelledby="drawer-case-code"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, x: isAr ? -24 : 24 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-2xl glass-modal h-full border-s border-white/85 flex flex-col"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#002B6B]/10 flex items-center justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
              <span id="drawer-case-code" className="font-mono font-semibold text-[#002B6B] text-sm">
                {dentalCase.caseCode}
              </span>
              <span aria-hidden="true">·</span>
              <span>
                {isAr
                  ? RESTORATION_LABELS_AR[dentalCase.restorationType] || dentalCase.restorationType
                  : dentalCase.restorationType}
              </span>
              <span aria-hidden="true">·</span>
              <span>
                {isAr
                  ? dentalCase.priority === 'Rush'
                    ? 'استعجال (Rush)'
                    : 'أولوية عادية'
                  : `${dentalCase.priority} Priority`}
              </span>
            </div>
            <h2 className="font-display text-base font-semibold text-[#002B6B] mt-0.5">
              {dentalCase.clinicName} → {dentalCase.labName}
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label={isAr ? 'إغلاق تفاصيل الحالة' : 'Close case details'}
            className="p-2 text-slate-500 hover:text-[#002B6B] rounded-xl hover:bg-white/70 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* 8-Stage Real-Time Courier & Clinical Progress Bar */}
          <div>
            <div className="flex items-center justify-between text-xs mb-2.5 gap-2">
              <span className="font-medium text-slate-700">
                {isAr ? 'متابعة المندوب والتصنيع لحظة بلحظة' : 'Real-Time Courier & Lab Tracking'}
              </span>
              <span
                className={`font-semibold ${
                  dentalCase.status === 'revision_requested'
                    ? 'text-amber-700'
                    : isClosed
                      ? 'text-emerald-700'
                      : 'text-[#008C99]'
                }`}
              >
                {statusMap[dentalCase.status]}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-1.5">
              {CASE_STAGE_ORDER.map((stage, idx) => {
                const completed =
                  dentalCase.status !== 'revision_requested' && idx <= currentStageIdx;
                return (
                  <div key={stage} className="space-y-1">
                    <div
                      className={`h-1.5 rounded-full transition-colors ${
                        dentalCase.status === 'revision_requested' && idx <= 4
                          ? 'bg-amber-600'
                          : completed
                            ? 'bg-[#002B6B]'
                            : 'bg-[#002B6B]/10'
                      }`}
                    />
                    <div
                      title={statusMap[stage]}
                      className={`text-[10px] leading-tight truncate ${
                        completed ? 'text-[#002B6B] font-medium' : 'text-slate-400'
                      }`}
                    >
                      {statusMap[stage]}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Live Courier & Delivery Status Banner */}
          <div className="glass-surface rounded-xl p-4 space-y-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#002B6B]">
                <Truck className="w-4 h-4 text-[#00A8B5] shrink-0" />
                <span>
                  {isAr ? 'تحديث المندوب والدليفري المباشر' : 'Live Courier & Delivery Status'}
                </span>
              </div>
              {dentalCase.trackingCode && (
                <span className="font-mono text-xs text-slate-700">
                  {isAr ? 'بوليصة:' : 'ID:'} {dentalCase.trackingCode}
                </span>
              )}
            </div>

            <p className="text-sm font-medium text-[#0B1E3B] leading-relaxed">
              {dentalCase.trackingNote ||
                DEFAULT_TRACKING_NOTES[lang][dentalCase.status] ||
                statusMap[dentalCase.status]}
            </p>

            {(dentalCase.courierName || dentalCase.courierPhone || dentalCase.courierEta) && (
              <div className="pt-2 border-t border-[#002B6B]/10 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600">
                {dentalCase.courierName && (
                  <span>
                    {isAr ? 'المندوب:' : 'Courier:'}{' '}
                    <strong className="text-[#002B6B]">{dentalCase.courierName}</strong>
                  </span>
                )}
                {dentalCase.courierPhone && (
                  <span className="inline-flex items-center gap-1 font-mono tabular-nums">
                    <Phone className="w-3 h-3 text-slate-500" />
                    {dentalCase.courierPhone}
                  </span>
                )}
                {dentalCase.courierEta && (
                  <span className="font-medium text-[#008C99]">
                    {isAr ? 'الوصول المتوقع:' : 'ETA:'} {dentalCase.courierEta}
                  </span>
                )}
              </div>
            )}
          </div>

          {/* Metadata Table */}
          <div className="glass-surface rounded-xl overflow-hidden divide-y divide-[#002B6B]/10 text-sm">
            <div className="grid grid-cols-2 sm:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x rtl:sm:divide-x-reverse divide-[#002B6B]/10">
              <div className="p-3.5">
                <div className="text-xs text-slate-500">
                  {isAr ? 'المريض / الملف' : 'Patient / Chart'}
                </div>
                <div className="font-mono tabular-nums font-medium text-[#002B6B] mt-0.5">
                  {dentalCase.patientInitials} · {dentalCase.patientChartRef}
                </div>
                {dentalCase.patientAgeGroup && (
                  <div className="text-[11px] text-slate-500">
                    {isAr
                      ? dentalCase.patientAgeGroup === 'Pediatric'
                        ? 'أطفال'
                        : 'بالغ'
                      : dentalCase.patientAgeGroup}
                  </div>
                )}
              </div>
              <div className="p-3.5">
                <div className="text-xs text-slate-500">
                  {isAr ? 'الخامة واللون' : 'Material & Shade'}
                </div>
                <div className="font-medium text-[#002B6B] mt-0.5">
                  {isAr
                    ? MATERIAL_LABELS_AR[dentalCase.material] || dentalCase.material
                    : dentalCase.material}{' '}
                  · <span className="font-mono">{dentalCase.shade}</span>
                </div>
              </div>
              <div className="p-3.5">
                <div className="text-xs text-slate-500">
                  {isAr ? 'تاريخ التسليم المطلوب' : 'Target Seat Date'}
                </div>
                <div className="font-mono tabular-nums font-medium text-[#002B6B] mt-0.5">
                  {dentalCase.dueDate}
                </div>
              </div>
              <div className="p-3.5">
                <div className="text-xs text-slate-500">
                  {isAr ? 'التكلفة التقديرية' : 'Estimated Lab Fee'}
                </div>
                <div className="font-mono tabular-nums font-medium text-[#002B6B] mt-0.5">
                  {dentalCase.estimatedFee.toLocaleString()}{' '}
                  {(dentalCase.currency || 'EGP') === 'EGP' ? (isAr ? 'ج.م' : 'EGP') : 'USD'}
                </div>
              </div>
            </div>
            <div className="p-3.5 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600 bg-white/45">
              <span>
                {isAr ? 'نوع المقاس / السكانر:' : 'Scanner:'}{' '}
                <strong className="text-[#002B6B]">{dentalCase.scannerSource}</strong>
              </span>
              <span className="font-mono">{dentalCase.scanReference || '—'}</span>
            </div>
          </div>

          {/* Tooth Chart */}
          <ToothChart selectedTeeth={dentalCase.toothNumbers} readOnly compact />

          {/* Required Lab Work & Notes */}
          <div className="glass-surface rounded-xl p-4 space-y-2.5">
            {dentalCase.requiredLabWork && (
              <div>
                <div className="text-xs font-medium text-slate-700">
                  {isAr ? 'الشغل المطلوب في المعمل' : 'Required Lab Work'}
                </div>
                <p className="text-sm text-[#002B6B] font-medium">{dentalCase.requiredLabWork}</p>
              </div>
            )}
            <div>
              <div className="text-xs font-medium text-slate-700">
                {isAr ? 'ملاحظات الدكتور' : 'Clinical Prescription Notes'}
              </div>
              <p className="text-sm text-slate-700 leading-relaxed">
                {dentalCase.clinicalNotes ||
                  (isAr
                    ? 'مفيش ملاحظات إضافية مسجلة على الحالة.'
                    : 'No additional margin or occlusal notes provided.')}
              </p>
            </div>
          </div>

          {/* X-Ray Radiographs Section */}
          <div className="glass-surface rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="text-xs font-semibold text-[#002B6B]">
                  {isAr
                    ? `الأشعة المرفقة (${xrays.length}/${VALIDATION.XRAY_MAX_COUNT})`
                    : `Attached X-Rays & Radiographs (${xrays.length}/${VALIDATION.XRAY_MAX_COUNT})`}
                </div>
                <div className="text-xs text-slate-500">
                  {isAr
                    ? 'دوس على أي صورة أشعة عشان تكبّرها وتفحص التفاصيل.'
                    : 'Click any radiograph to inspect in full contrast view.'}
                </div>
              </div>

              {actingAsDoctor && !isClosed && xrays.length < VALIDATION.XRAY_MAX_COUNT && canDoctorEdit && (
                <label className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium btn-glass-secondary rounded-xl cursor-pointer shrink-0">
                  <Upload className="w-3.5 h-3.5 text-[#00A8B5]" />
                  <span>{isAr ? 'إضافة أشعة' : 'Attach X-Ray'}</span>
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    onChange={handleAttachAdditionalXray}
                    className="sr-only"
                  />
                </label>
              )}
            </div>

            {xrayUploadError && <div className="text-xs text-red-700">{xrayUploadError}</div>}

            {xrays.length === 0 ? (
              <div className="text-xs text-slate-500 py-2">
                {isAr
                  ? 'مفيش صور أشعة مرفوعة للحالة دي لسه.'
                  : 'No dental radiographs attached to this case yet.'}
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {xrays.map((xray) => (
                  <button
                    key={xray.id}
                    type="button"
                    onClick={() => setLightboxXray(xray)}
                    className="group text-start border border-white/80 rounded-xl overflow-hidden bg-slate-950 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00A8B5]"
                  >
                    <div className="relative h-28 overflow-hidden">
                      <img
                        src={xray.dataUrl}
                        alt={xray.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                      <span className="absolute end-2 bottom-2 p-1 rounded-lg bg-slate-900/80 text-white">
                        <ZoomIn className="w-3.5 h-3.5" />
                      </span>
                    </div>
                    <div className="px-2.5 py-1.5 bg-white/90 text-[11px] font-mono text-slate-700 truncate border-t border-white/70">
                      {xray.name}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {actionFeedback && (
            <div
              role="status"
              className="p-3 rounded-xl border border-emerald-200/80 bg-emerald-50/90 text-xs text-emerald-800 flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{actionFeedback}</span>
            </div>
          )}

          {/* Lab & Courier Live Tracking Controls */}
          {!isClosed && actingAsLab && (
            <div className="glass-surface rounded-xl p-4 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="text-xs font-semibold text-[#002B6B]">
                  {isAr
                    ? 'تحديثات المعمل والمندوب (Tracking & Production)'
                    : 'Laboratory & Courier Tracking Controls'}
                </div>
                <button
                  type="button"
                  disabled={updatingStage}
                  onClick={handleSaveLogisticsOnly}
                  className="text-xs font-medium text-[#008C99] hover:text-[#002B6B] cursor-pointer"
                >
                  {isAr ? 'حفظ بيانات المندوب بس' : 'Save Courier Details'}
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label htmlFor="courier-name" className="block text-xs text-slate-600 mb-1">
                    {isAr ? 'اسم المندوب' : 'Courier Name'}
                  </label>
                  <input
                    id="courier-name"
                    type="text"
                    maxLength={VALIDATION.COURIER_NAME_MAX}
                    value={courierName}
                    onChange={(e) => setCourierName(e.target.value)}
                    placeholder={isAr ? 'أحمد محمود' : 'Ahmed Mahmoud'}
                    className="w-full px-3 py-1.5 text-sm glass-input rounded-xl"
                  />
                </div>
                <div>
                  <label htmlFor="courier-phone" className="block text-xs text-slate-600 mb-1">
                    {isAr ? 'موبايل المندوب' : 'Courier Phone'}
                  </label>
                  <input
                    id="courier-phone"
                    type="text"
                    maxLength={VALIDATION.PHONE_MAX}
                    value={courierPhone}
                    onChange={(e) => setCourierPhone(e.target.value)}
                    placeholder="01012345678"
                    className="w-full px-3 py-1.5 text-sm font-mono glass-input rounded-xl"
                  />
                </div>
                <div>
                  <label htmlFor="courier-eta" className="block text-xs text-slate-600 mb-1">
                    {isAr ? 'وقت الوصول المتوقع (ETA)' : 'Courier ETA'}
                  </label>
                  <input
                    id="courier-eta"
                    type="text"
                    maxLength={VALIDATION.COURIER_ETA_MAX}
                    value={courierEta}
                    onChange={(e) => setCourierEta(e.target.value)}
                    placeholder={isAr ? 'خلال 35 دقيقة' : 'Arriving in 35 mins'}
                    className="w-full px-3 py-1.5 text-sm glass-input rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="tracking-note" className="block text-xs text-slate-600 mb-1">
                  {isAr
                    ? 'رسالة التتبع اللي بتظهر للدكتور (مثلاً: المندوب وصل المعمل / الدليفري جاي لك دلوقتي)'
                    : 'Live Tracking Update Note'}
                </label>
                <input
                  id="tracking-note"
                  type="text"
                  maxLength={VALIDATION.TRACKING_NOTE_MAX}
                  value={trackingNote}
                  onChange={(e) => setTrackingNote(e.target.value)}
                  placeholder={
                    isAr
                      ? 'الدليفري جاي لك دلوقتي بالشغل...'
                      : 'Delivery courier is heading to your clinic...'
                  }
                  className="w-full px-3 py-1.5 text-sm glass-input rounded-xl"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label htmlFor="lab-tracking" className="block text-xs text-slate-600 mb-1">
                    {isAr ? 'رقم البوليصة / التتبع' : 'Tracking ID'}
                  </label>
                  <input
                    id="lab-tracking"
                    type="text"
                    maxLength={VALIDATION.TRACKING_MAX}
                    value={trackingCode}
                    onChange={(e) => setTrackingCode(e.target.value)}
                    placeholder="LABI-TRK-204"
                    className="w-full px-3 py-1.5 text-sm font-mono glass-input rounded-xl"
                  />
                </div>
                <div>
                  <label htmlFor="lab-fee" className="block text-xs text-slate-600 mb-1">
                    {isAr ? `سعر الشغل النهائي (${feeCurrencyLabel})` : `Confirmed Fee (${feeCurrencyLabel})`}
                  </label>
                  <input
                    id="lab-fee"
                    type="number"
                    min={0}
                    max={VALIDATION.MAX_FEE}
                    value={estimatedFee}
                    onChange={(e) => setEstimatedFee(e.target.value)}
                    className="w-full px-3 py-1.5 text-sm font-mono tabular-nums glass-input rounded-xl"
                  />
                </div>
                <div>
                  <label htmlFor="lab-currency" className="block text-xs text-slate-600 mb-1">
                    {isAr ? 'العملة' : 'Currency'}
                  </label>
                  <select
                    id="lab-currency"
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                    className="w-full px-3 py-1.5 text-sm glass-input rounded-xl"
                  >
                    <option value="EGP">{isAr ? 'جنيه مصري (ج.م)' : 'EGP'}</option>
                    <option value="USD">{isAr ? 'دولار (USD)' : 'USD'}</option>
                  </select>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-1">
                {nextStage && (
                  <button
                    type="button"
                    disabled={updatingStage}
                    onClick={() => handleAdvanceLabStage(nextStage)}
                    className="px-4 py-2 text-xs font-semibold btn-glass-primary rounded-xl disabled:opacity-60 cursor-pointer"
                  >
                    {updatingStage
                      ? isAr
                        ? 'جاري التحديث...'
                        : 'Updating...'
                      : isAr
                        ? `الخطوة الجاية: ${statusMap[nextStage]}`
                        : `Next: ${statusMap[nextStage]}`}
                  </button>
                )}

                {QUICK_LAB_STAGES.map(
                  (st) =>
                    st !== dentalCase.status &&
                    st !== nextStage && (
                      <button
                        key={st}
                        type="button"
                        disabled={updatingStage}
                        onClick={() => handleAdvanceLabStage(st)}
                        className="px-3 py-2 text-xs font-medium btn-glass-secondary rounded-xl disabled:opacity-50 cursor-pointer"
                      >
                        {statusMap[st]}
                      </button>
                    )
                )}
              </div>
            </div>
          )}

          {/* Doctor Edit Prescription Form */}
          {canDoctorEdit && !isClosed && (
            <form
              onSubmit={handleDoctorUpdateNotes}
              className="glass-surface rounded-xl p-4 space-y-3"
            >
              <div className="text-xs font-semibold text-[#002B6B]">
                {isAr ? 'تعديل تفاصيل الروشتة' : 'Update Prescription Details'}
              </div>
              <input
                type="text"
                maxLength={VALIDATION.REQUIRED_WORK_MAX}
                value={editRequiredWork}
                onChange={(e) => setEditRequiredWork(e.target.value)}
                placeholder={isAr ? 'تفاصيل الشغل المطلوب' : 'Required lab work details'}
                className="w-full px-3 py-1.5 text-sm glass-input rounded-xl"
              />
              <input
                type="text"
                maxLength={VALIDATION.SCAN_REF_MAX}
                value={editScanRef}
                onChange={(e) => setEditScanRef(e.target.value)}
                placeholder={isAr ? 'اسم ملف السكان STL' : 'Updated STL scan filename'}
                className="w-full px-3 py-1.5 text-sm font-mono glass-input rounded-xl"
              />
              <textarea
                rows={2}
                maxLength={VALIDATION.NOTES_MAX}
                value={editNotes}
                onChange={(e) => setEditNotes(e.target.value)}
                placeholder={isAr ? 'ملاحظات الدكتور للمعمل' : 'Updated clinical notes'}
                className="w-full px-3 py-1.5 text-sm glass-input rounded-xl"
              />
              <button
                type="submit"
                disabled={updatingStage}
                className="px-4 py-1.5 text-xs font-semibold btn-glass-secondary rounded-xl cursor-pointer"
              >
                {updatingStage
                  ? isAr
                    ? 'جاري الحفظ...'
                    : 'Saving...'
                  : isAr
                    ? 'حفظ تعديلات الروشتة'
                    : 'Save Prescription Edits'}
              </button>
            </form>
          )}

          {/* Doctor Approval / Delivery Confirmation */}
          {canDoctorDecide && (
            <div className="glass-surface border border-[#00A8B5]/35 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 bg-[#00A8B5]/5">
              <div className="text-sm text-[#0B1E3B]">
                {dentalCase.status === 'awaiting_approval'
                  ? isAr
                    ? 'المعمل بعت لك الشغل/التصميم ومستني موافقتك قبل التقفيل النهائي.'
                    : 'Laboratory has requested your approval before finalizing.'
                  : isAr
                    ? 'الدليفري جاي لك أو وصل بالشغل. أكد الاستلام عشان الحالة تقفل والعميل يركب.'
                    : 'Courier is delivering or has delivered the case. Confirm fit to complete.'}
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={updatingStage}
                  onClick={() => handleDoctorDecision('revision_requested')}
                  className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-amber-800 border border-amber-300 bg-amber-50/90 rounded-xl hover:bg-amber-100 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  {isAr ? 'طلب تعديل' : 'Request Revision'}
                </button>
                <button
                  type="button"
                  disabled={updatingStage}
                  onClick={() => handleDoctorDecision('completed')}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold btn-glass-teal rounded-xl cursor-pointer"
                >
                  <PackageCheck className="w-3.5 h-3.5" />
                  {isAr ? 'تأكيد الاستلام والانتهاء' : 'Approve & Complete'}
                </button>
              </div>
            </div>
          )}

          {/* Digital Invoice Card for Completed / Delivered Cases */}
          {(isClosed || caseInvoice) && (
            <div className="glass-surface rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
              <div className="space-y-1">
                <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#002B6B]">
                  <Receipt className="w-4 h-4 text-[#00A8B5] shrink-0" />
                  <span>{isAr ? 'الفاتورة الرقمية للحالة' : 'Digital Case Invoice'}</span>
                </div>
                {caseInvoice ? (
                  <div className="text-xs text-slate-600 flex flex-wrap items-center gap-2">
                    <span className="font-mono font-semibold text-[#002B6B]">
                      {caseInvoice.invoiceNumber}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono tabular-nums font-semibold text-[#002B6B]">
                      {caseInvoice.totalAmount.toLocaleString()}{' '}
                      {caseInvoice.currency === 'EGP' ? (isAr ? 'ج.م' : 'EGP') : 'USD'}
                    </span>
                    <span aria-hidden="true">·</span>
                    {caseInvoice.status === 'paid' ? (
                      <span className="inline-flex items-center gap-1 font-semibold text-emerald-700">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>{isAr ? 'مدفوعة' : 'Paid'}</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 font-semibold text-amber-700">
                        <Clock className="w-3.5 h-3.5" />
                        <span>
                          {isAr ? `مستحقة (${caseInvoice.dueDate})` : `Pending (Due ${caseInvoice.dueDate})`}
                        </span>
                      </span>
                    )}
                  </div>
                ) : (
                  <p className="text-xs text-slate-600">
                    {actingAsLab
                      ? isAr
                        ? 'الحالة اكتملت! تقدر تصدر وتبعت الفاتورة الرقمية للدكتور مباشرة دلوقتي.'
                        : 'Case is completed. Generate and send a digital invoice directly to the clinic.'
                      : isAr
                        ? 'الحالة مكتملة ولم يصدر المعمل فاتورة رقمية لها بعد.'
                        : 'Case is completed; awaiting digital invoice from laboratory.'}
                  </p>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {caseInvoice ? (
                  <>
                    {actingAsLab && caseInvoice.status === 'pending' && onOpenCreateInvoice && (
                      <button
                        type="button"
                        onClick={() => onOpenCreateInvoice(dentalCase, caseInvoice)}
                        className="px-3 py-1.5 text-xs font-medium btn-glass-secondary rounded-xl cursor-pointer"
                      >
                        {isAr ? 'تعديل المبلغ' : 'Adjust Amount'}
                      </button>
                    )}
                    {onViewInvoice && (
                      <button
                        type="button"
                        onClick={() => onViewInvoice(caseInvoice)}
                        className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-xl cursor-pointer ${
                          caseInvoice.status === 'pending' && actingAsDoctor
                            ? 'btn-glass-teal'
                            : 'btn-glass-primary'
                        }`}
                      >
                        <Receipt className="w-3.5 h-3.5" />
                        <span>
                          {caseInvoice.status === 'pending' && actingAsDoctor
                            ? isAr
                              ? 'عرض وسداد الفاتورة'
                              : 'View & Pay Invoice'
                            : isAr
                              ? 'عرض الفاتورة'
                              : 'View Invoice'}
                        </span>
                      </button>
                    )}
                  </>
                ) : (
                  actingAsLab &&
                  onOpenCreateInvoice && (
                    <button
                      type="button"
                      onClick={() => onOpenCreateInvoice(dentalCase)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold btn-glass-primary rounded-xl cursor-pointer"
                    >
                      <Receipt className="w-3.5 h-3.5" />
                      <span>{isAr ? 'إصدار وإرسال فاتورة رقمية' : 'Generate & Send Invoice'}</span>
                    </button>
                  )
                )}
              </div>
            </div>
          )}

          {/* Encrypted Communications & Immutable Record-Keeping Tabs */}
          <div className="border-t border-[#002B6B]/10 pt-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="inline-flex items-center p-1 glass-surface rounded-xl">
                <button
                  type="button"
                  onClick={() => setCommsTab('thread')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                    commsTab === 'thread'
                      ? 'bg-[#002B6B] text-white shadow-xs'
                      : 'text-slate-600 hover:text-[#002B6B]'
                  }`}
                >
                  {isAr
                    ? `الشات المشفر (${decryptedMessages.length})`
                    : `Encrypted Thread (${decryptedMessages.length})`}
                </button>
                <button
                  type="button"
                  onClick={() => setCommsTab('audit')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                    commsTab === 'audit'
                      ? 'bg-[#002B6B] text-white shadow-xs'
                      : 'text-slate-600 hover:text-[#002B6B]'
                  }`}
                >
                  {isAr
                    ? `سجل التوثيق (${auditLogs.length})`
                    : `Audit Record (${auditLogs.length})`}
                </button>
              </div>

              <div className="inline-flex items-center gap-1.5 text-xs text-slate-600">
                <Lock className="w-3.5 h-3.5 text-[#008C99]" />
                <span>
                  {isAr ? 'تشفير AES-256-GCM · متسجل بالتاريخ' : 'AES-256-GCM Encrypted · Logged'}
                </span>
              </div>
            </div>

            {commsTab === 'thread' ? (
              <>
                <div className="space-y-2.5 max-h-60 overflow-y-auto">
                  {loadingMessages && (
                    <div className="text-xs text-slate-400">
                      {isAr ? 'جاري فك تشفير الرسائل...' : 'Decrypting clinical messages...'}
                    </div>
                  )}
                  {!loadingMessages && decryptedMessages.length === 0 && (
                    <div className="text-xs text-slate-500 py-3">
                      {isAr
                        ? 'ابدأ محادثة مشفرة بين العيادة والمعمل بخصوص اللون، البروفة، الأشعة، أو ميعاد الدليفري.'
                        : 'Start an encrypted conversation regarding margins, shade, or radiographs.'}
                    </div>
                  )}
                  {decryptedMessages.map((msg) => (
                    <div
                      key={msg.id}
                      className="p-3.5 rounded-xl glass-surface text-sm space-y-1"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
                        <span className="font-medium text-[#002B6B]">
                          {msg.senderName} ·{' '}
                          {msg.senderRole === 'lab'
                            ? isAr
                              ? 'معمل أسنان'
                              : 'Dental Lab'
                            : isAr
                              ? 'دكتور'
                              : 'Doctor'}
                          {msg.messageType && msg.messageType !== 'chat' && (
                            <>
                              <span className="mx-1.5 text-slate-400" aria-hidden="true">
                                ·
                              </span>
                              <span className="text-[#008C99]">
                                {messageTypeLabels[msg.messageType]}
                              </span>
                            </>
                          )}
                        </span>
                        <span className="font-mono tabular-nums text-[11px]">
                          {msg.createdAt?.toDate
                            ? msg.createdAt.toDate().toLocaleString([], {
                                month: 'short',
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit',
                              })
                            : isAr
                              ? 'الآن'
                              : 'Just now'}
                        </span>
                      </div>
                      <p className="text-[#0B1E3B] text-sm leading-relaxed">{msg.decryptedText}</p>
                      {msg.contentHash && (
                        <div className="flex items-center gap-1 text-[10px] font-mono text-slate-400">
                          <ShieldCheck className="w-3 h-3 text-[#008C99]" />
                          <span>SHA-256 {msg.contentHash.slice(0, 14)}…</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                <form onSubmit={handleSendMessage} className="space-y-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <label htmlFor="msg-type" className="text-xs text-slate-600">
                      {isAr ? 'نوع الرسالة:' : 'Intent:'}
                    </label>
                    <select
                      id="msg-type"
                      value={messageType}
                      onChange={(e) => setMessageType(e.target.value as MessageType)}
                      className="px-2.5 py-1 text-xs glass-input rounded-lg"
                    >
                      <option value="chat">{messageTypeLabels.chat}</option>
                      <option value="status_update">{messageTypeLabels.status_update}</option>
                      <option value="info_request">{messageTypeLabels.info_request}</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      maxLength={VALIDATION.MESSAGE_MAX}
                      value={messageText}
                      onChange={(e) => setMessageText(e.target.value)}
                      placeholder={
                        actingAsLab
                          ? isAr
                            ? 'ابعت تحديث للدكتور (مثلاً: المندوب وصل أو استلمنا الشغل)...'
                            : 'Send encrypted case update or request radiographs/info...'
                          : isAr
                            ? 'ابعت رسالة مشفرة للمعمل...'
                            : 'Send encrypted message to laboratory...'
                      }
                      className="flex-1 px-3 py-2 text-sm glass-input rounded-xl"
                    />
                    <button
                      type="submit"
                      disabled={sendingMsg || !messageText.trim()}
                      className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-medium btn-glass-primary rounded-xl disabled:opacity-50 cursor-pointer whitespace-nowrap shrink-0"
                    >
                      <Send className="w-3.5 h-3.5" />
                      {sendingMsg
                        ? isAr
                          ? 'بيتشفر...'
                          : 'Encrypting...'
                        : isAr
                          ? 'إرسال'
                          : 'Send'}
                    </button>
                  </div>
                </form>
              </>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-xs text-slate-600">
                    {isAr
                      ? 'سجل غير قابل للتعديل بيسجل كل تحركات المندوب، تحديثات المعمل، ورسايل التشفير.'
                      : 'Append-only compliance ledger recording case transitions, X-ray uploads, and encrypted communication digests.'}
                  </p>
                  {auditLogs.length > 0 && (
                    <button
                      type="button"
                      onClick={handleExportAuditCsv}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium btn-glass-secondary rounded-xl cursor-pointer whitespace-nowrap shrink-0"
                    >
                      <Download className="w-3.5 h-3.5 text-[#00A8B5]" />
                      <span>{isAr ? 'تصدير CSV' : 'Export CSV'}</span>
                    </button>
                  )}
                </div>

                <div className="glass-surface rounded-xl divide-y divide-[#002B6B]/10 max-h-64 overflow-y-auto">
                  {loadingAudit && (
                    <div className="p-3 text-xs text-slate-400">
                      {isAr ? 'جاري تحميل السجل...' : 'Loading audit ledger...'}
                    </div>
                  )}
                  {!loadingAudit && auditLogs.length === 0 && (
                    <div className="p-4 text-xs text-slate-500">
                      {isAr ? 'مفيش سجلات متسجلة للحالة دي لسه.' : 'No audit records logged yet.'}
                    </div>
                  )}
                  {auditLogs.map((log) => (
                    <div key={log.id} className="p-3 text-xs space-y-1 bg-white/40">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-mono font-semibold text-[#002B6B]">
                          {log.action}
                        </span>
                        <span className="font-mono tabular-nums text-slate-500">
                          {log.createdAt?.toDate
                            ? log.createdAt.toDate().toLocaleString([], {
                                month: 'short',
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit',
                              })
                            : isAr
                              ? 'الآن'
                              : 'Just now'}
                        </span>
                      </div>
                      <div className="text-slate-700">{log.summary}</div>
                      <div className="text-[11px] text-slate-500 font-mono">
                        {log.actorName} ({log.actorRole}) · Digest {log.digestHash.slice(0, 16)}…
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </motion.div>

      {/* X-Ray Lightbox Modal */}
      {lightboxXray && (
        <div
          className="fixed inset-0 z-[60] bg-slate-950/90 backdrop-blur-sm flex items-center justify-center p-6"
          onClick={() => setLightboxXray(null)}
        >
          <div
            className="max-w-3xl w-full bg-slate-900 border border-slate-700 rounded-2xl overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between text-xs text-slate-200">
              <span className="font-mono">{lightboxXray.name}</span>
              <button
                type="button"
                onClick={() => setLightboxXray(null)}
                aria-label={isAr ? 'إغلاق عارض الأشعة' : 'Close radiograph viewer'}
                className="p-1 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 flex items-center justify-center bg-black max-h-[75vh]">
              <img
                src={lightboxXray.dataUrl}
                alt={lightboxXray.name}
                className="max-h-[68vh] w-auto object-contain"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
