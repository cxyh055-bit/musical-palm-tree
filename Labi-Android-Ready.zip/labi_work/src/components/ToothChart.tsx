import { useLang } from '../i18n';

interface ToothChartProps {
  selectedTeeth: string[];
  onToggleTooth?: (tooth: string) => void;
  readOnly?: boolean;
  compact?: boolean;
}

const UPPER_RIGHT = ['1', '2', '3', '4', '5', '6', '7', '8'];
const UPPER_LEFT = ['9', '10', '11', '12', '13', '14', '15', '16'];
const LOWER_RIGHT = ['32', '31', '30', '29', '28', '27', '26', '25'];
const LOWER_LEFT = ['24', '23', '22', '21', '20', '19', '18', '17'];

export function ToothChart({
  selectedTeeth,
  onToggleTooth,
  readOnly = false,
  compact = false,
}: ToothChartProps) {
  const { lang } = useLang();
  const isAr = lang === 'ar';

  const renderTooth = (num: string) => {
    const active = selectedTeeth.includes(num);
    const sizeClasses = compact ? 'h-7 w-7 text-[11px]' : 'h-9 w-9 text-xs';

    if (readOnly) {
      return (
        <div
          key={num}
          className={`${sizeClasses} inline-flex items-center justify-center rounded-lg border font-mono tabular-nums transition-colors ${
            active
              ? 'bg-[#002B6B] border-[#002B6B] text-white font-semibold shadow-xs'
              : 'bg-white/60 border-[#002B6B]/10 text-slate-400'
          }`}
          aria-label={`Tooth ${num}${active ? ' selected' : ''}`}
        >
          {num}
        </div>
      );
    }

    return (
      <button
        key={num}
        type="button"
        onClick={() => onToggleTooth?.(num)}
        aria-pressed={active}
        aria-label={`Tooth ${num}`}
        className={`${sizeClasses} inline-flex items-center justify-center rounded-lg border font-mono tabular-nums transition-all cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00A8B5] focus-visible:ring-offset-1 ${
          active
            ? 'bg-[#002B6B] border-[#002B6B] text-white font-semibold shadow-xs scale-[1.03]'
            : 'bg-white/80 border-[#002B6B]/12 text-[#0B1E3B] hover:border-[#00A8B5] hover:bg-white'
        }`}
      >
        {num}
      </button>
    );
  };

  return (
    <div className="glass-surface rounded-xl p-4">
      <div className="flex items-center justify-between text-xs text-slate-600 mb-3">
        <span className="font-medium text-[#002B6B]">
          {isAr ? 'خريطة ترقيم الأسنان (1–32)' : 'Universal Numbering (1–32)'}
        </span>
        <span className="font-mono tabular-nums font-semibold text-[#008C99]">
          {isAr
            ? `${selectedTeeth.length} سنة محددة`
            : `${selectedTeeth.length} ${selectedTeeth.length === 1 ? 'tooth' : 'teeth'} selected`}
        </span>
      </div>

      {/* Keep anatomical arch direction LTR so 1-16 and 32-17 stay anatomically aligned */}
      <div dir="ltr" className="space-y-3 overflow-x-auto pb-1">
        {/* Maxillary / Upper Arch */}
        <div>
          <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1.5 px-0.5">
            <span>{isAr ? 'فك علوي يمين (1–8)' : 'Upper Right (1–8)'}</span>
            <span>{isAr ? 'فك علوي شمال (9–16)' : 'Upper Left (9–16)'}</span>
          </div>
          <div className="flex items-center justify-between gap-2 min-w-[520px]">
            <div className="flex items-center gap-1">{UPPER_RIGHT.map(renderTooth)}</div>
            <div className="h-6 w-px bg-[#002B6B]/12 shrink-0" aria-hidden="true" />
            <div className="flex items-center gap-1">{UPPER_LEFT.map(renderTooth)}</div>
          </div>
        </div>

        <div className="border-t border-[#002B6B]/10" />

        {/* Mandibular / Lower Arch */}
        <div>
          <div className="flex items-center justify-between gap-2 min-w-[520px]">
            <div className="flex items-center gap-1">{LOWER_RIGHT.map(renderTooth)}</div>
            <div className="h-6 w-px bg-[#002B6B]/12 shrink-0" aria-hidden="true" />
            <div className="flex items-center gap-1">{LOWER_LEFT.map(renderTooth)}</div>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-500 mt-1.5 px-0.5">
            <span>{isAr ? 'فك سفلي يمين (32–25)' : 'Lower Right (32–25)'}</span>
            <span>{isAr ? 'فك سفلي شمال (24–17)' : 'Lower Left (24–17)'}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
