import { useState } from 'react';
import { Crosshair, MapPin } from 'lucide-react';
import { useLang } from '../i18n';
import { AREA_PRESETS, detectBrowserLocation } from '../utils/geo';

interface LocationPickerProps {
  area: string;
  city: string;
  latitude?: number;
  longitude?: number;
  onChange: (next: {
    area: string;
    city: string;
    latitude: number;
    longitude: number;
  }) => void;
}

export function LocationPicker({
  area,
  city,
  latitude,
  longitude,
  onChange,
}: LocationPickerProps) {
  const { lang } = useLang();
  const isAr = lang === 'ar';
  const [detecting, setDetecting] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);

  const handlePresetChange = (presetId: string) => {
    const preset = AREA_PRESETS.find((p) => p.id === presetId);
    if (!preset) return;
    onChange({
      area: isAr ? preset.areaAr : preset.areaEn,
      city: preset.city,
      latitude: preset.lat,
      longitude: preset.lng,
    });
  };

  const handleDetectGps = async () => {
    setDetecting(true);
    setGpsError(null);
    try {
      const coords = await detectBrowserLocation();
      onChange({
        area: area || (isAr ? 'موقع GPS محدد' : 'GPS Detected Area'),
        city: city || (isAr ? 'القاهرة' : 'Cairo'),
        latitude: coords.lat,
        longitude: coords.lng,
      });
    } catch (err) {
      setGpsError(
        err instanceof Error
          ? err.message
          : isAr
            ? 'تعذر تحديد اللوكيشن من المتصفح، اختار المنطقة من القائمة.'
            : 'Unable to access GPS. Please select a district preset.'
      );
    } finally {
      setDetecting(false);
    }
  };

  const selectedPreset =
    AREA_PRESETS.find(
      (p) =>
        typeof latitude === 'number' &&
        typeof longitude === 'number' &&
        Math.abs(p.lat - latitude) < 0.005 &&
        Math.abs(p.lng - longitude) < 0.005
    )?.id || '';

  return (
    <div className="glass-surface rounded-xl p-4 space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-xs font-semibold text-[#002B6B]">
          <MapPin className="w-4 h-4 text-[#00A8B5]" />
          <span>
            {isAr
              ? 'تحديد اللوكيشن (عشان نرتب المعامل حسب قربها)'
              : 'Location & Proximity Coordinates'}
          </span>
        </div>

        <button
          type="button"
          onClick={handleDetectGps}
          disabled={detecting}
          className="btn-glass-secondary inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#002B6B] rounded-lg disabled:opacity-60 cursor-pointer"
        >
          <Crosshair className="w-3.5 h-3.5 text-[#00A8B5]" />
          <span>
            {detecting
              ? isAr
                ? 'جاري تحديد اللوكيشن...'
                : 'Detecting...'
              : isAr
                ? 'تحديد اللوكيشن بالـ GPS'
                : 'Use Current GPS'}
          </span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label htmlFor="loc-preset" className="block text-xs text-slate-600 mb-1">
            {isAr ? 'اختر المنطقة السريعة' : 'Quick Area / District Preset'}
          </label>
          <select
            id="loc-preset"
            value={selectedPreset}
            onChange={(e) => handlePresetChange(e.target.value)}
            className="w-full px-3 py-2 text-sm glass-input rounded-xl text-[#0B1E3B]"
          >
            <option value="">
              {isAr ? 'اختر المنطقة أو الحي...' : 'Select area preset...'}
            </option>
            {AREA_PRESETS.map((p) => (
              <option key={p.id} value={p.id}>
                {isAr ? p.areaAr : p.areaEn}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="loc-area-text" className="block text-xs text-slate-600 mb-1">
            {isAr ? 'المنطقة / الحي' : 'Neighborhood / Area'}
          </label>
          <input
            id="loc-area-text"
            type="text"
            maxLength={80}
            value={area}
            onChange={(e) =>
              onChange({
                area: e.target.value,
                city,
                latitude: latitude ?? 30.0444,
                longitude: longitude ?? 31.2357,
              })
            }
            placeholder={isAr ? 'مثال: المعادي، القاهرة' : 'e.g. Maadi, Cairo'}
            className="w-full px-3 py-2 text-sm glass-input rounded-xl text-[#0B1E3B]"
          />
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono tabular-nums text-slate-500">
        <span>
          {typeof latitude === 'number' && typeof longitude === 'number'
            ? `GPS: ${latitude.toFixed(4)}, ${longitude.toFixed(4)}`
            : isAr
              ? 'لسه ماتحددش إحداثيات لوكيشن'
              : 'No GPS coordinates selected yet'}
        </span>
        {gpsError && <span className="text-red-700 font-sans">{gpsError}</span>}
      </div>
    </div>
  );
}
