import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { doc, serverTimestamp, updateDoc } from 'firebase/firestore';
import { AnimatePresence, motion } from 'motion/react';
import {
  CheckCircle2,
  Clock,
  Edit3,
  ExternalLink,
  FileCheck2,
  Printer,
  Receipt,
  Search,
  Wallet,
  X,
} from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { useLang } from '../i18n';
import {
  VALIDATION,
  type DentalCase,
  type DigitalInvoice,
  type InvoiceStatus,
  type UserProfile,
  type UserRole,
} from '../types';
import { recordCaseAuditEvent } from '../utils/auditLog';
import { sendCaseStatusNotification } from '../utils/notifications';

interface InvoicesViewProps {
  profile: UserProfile;
  perspective: UserRole;
  invoices: DigitalInvoice[];
  labCases: DentalCase[];
  loading: boolean;
  initialInvoiceId?: string | null;
  onClearInitialInvoice?: () => void;
  onOpenCase: (caseId: string) => void;
  onCreateInvoiceForCase: (dentalCase: DentalCase, existing?: DigitalInvoice | null) => void;
}

type InvoiceFilter = 'all' | InvoiceStatus;

export function InvoicesView({
  profile,
  perspective,
  invoices,
  labCases,
  loading,
  initialInvoiceId,
  onClearInitialInvoice,
  onOpenCase,
  onCreateInvoiceForCase,
}: InvoicesViewProps) {
  const { lang } = useLang();
  const isAr = lang === 'ar';

  const [statusFilter, setStatusFilter] = useState<InvoiceFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<string | null>(
    initialInvoiceId || null
  );
  const [paymentRef, setPaymentRef] = useState('');
  const [markingPaid, setMarkingPaid] = useState(false);
  const [paymentFeedback, setPaymentFeedback] = useState<string | null>(null);

  useEffect(() => {
    if (initialInvoiceId) {
      setSelectedInvoiceId(initialInvoiceId);
      setPaymentFeedback(null);
    }
  }, [initialInvoiceId]);

  const roleInvoices = useMemo(() => {
    const filtered = invoices.filter((inv) =>
      perspective === 'lab'
        ? inv.labOwnerUid === profile.uid
        : inv.doctorUid === profile.uid
    );
    return [...filtered].sort((a, b) => {
      const ta = a.updatedAt?.toMillis?.() ?? a.createdAt?.toMillis?.() ?? 0;
      const tb = b.updatedAt?.toMillis?.() ?? b.createdAt?.toMillis?.() ?? 0;
      return tb - ta;
    });
  }, [invoices, perspective, profile.uid]);

  const completedCasesReadyToInvoice = useMemo(() => {
    if (perspective !== 'lab') return [];
    const invoicedCaseIds = new Set(invoices.map((inv) => inv.caseId));
    return labCases.filter(
      (c) =>
        (c.status === 'completed' || c.status === 'delivered') &&
        !invoicedCaseIds.has(c.id)
    );
  }, [perspective, labCases, invoices]);

  const filteredInvoices = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return roleInvoices.filter((inv) => {
      if (statusFilter !== 'all' && inv.status !== statusFilter) return false;
      if (!q) return true;
      return (
        inv.invoiceNumber.toLowerCase().includes(q) ||
        inv.caseCode.toLowerCase().includes(q) ||
        inv.labName.toLowerCase().includes(q) ||
        inv.clinicName.toLowerCase().includes(q) ||
        inv.patientChartRef.toLowerCase().includes(q) ||
        inv.serviceDescription.toLowerCase().includes(q)
      );
    });
  }, [roleInvoices, statusFilter, searchQuery]);

  const selectedInvoice = useMemo(
    () => invoices.find((inv) => inv.id === selectedInvoiceId) || null,
    [invoices, selectedInvoiceId]
  );

  const summary = useMemo(() => {
    const pendingList = roleInvoices.filter((i) => i.status === 'pending');
    const paidList = roleInvoices.filter((i) => i.status === 'paid');
    const pendingTotalEgp = pendingList
      .filter((i) => i.currency === 'EGP')
      .reduce((s, i) => s + i.totalAmount, 0);
    const paidTotalEgp = paidList
      .filter((i) => i.currency === 'EGP')
      .reduce((s, i) => s + i.totalAmount, 0);
    const pendingTotalUsd = pendingList
      .filter((i) => i.currency === 'USD')
      .reduce((s, i) => s + i.totalAmount, 0);
    const paidTotalUsd = paidList
      .filter((i) => i.currency === 'USD')
      .reduce((s, i) => s + i.totalAmount, 0);

    return {
      totalCount: roleInvoices.length,
      pendingCount: pendingList.length,
      paidCount: paidList.length,
      pendingTotalEgp,
      paidTotalEgp,
      pendingTotalUsd,
      paidTotalUsd,
    };
  }, [roleInvoices]);

  const formatAmount = (amount: number, currency: string) => {
    const label = currency === 'EGP' ? (isAr ? 'ج.م' : 'EGP') : 'USD';
    return `${amount.toLocaleString()} ${label}`;
  };

  const formatCurrencySummary = (egp: number, usd: number) => {
    const egpStr = `${egp.toLocaleString()} ${isAr ? 'ج.م' : 'EGP'}`;
    if (usd > 0) {
      return `${egpStr} + $${usd.toLocaleString()}`;
    }
    return egpStr;
  };

  const closeModal = () => {
    setSelectedInvoiceId(null);
    setPaymentRef('');
    setPaymentFeedback(null);
    onClearInitialInvoice?.();
  };

  const handleMarkAsPaid = async (e: FormEvent) => {
    e.preventDefault();
    if (!selectedInvoice || selectedInvoice.status !== 'pending') return;

    setMarkingPaid(true);
    setPaymentFeedback(null);
    const path = `invoices/${selectedInvoice.id}`;
    const cleanRef = (
      paymentRef.trim() ||
      (isAr ? 'سداد إلكتروني داخل المنصة' : 'In-app digital settlement')
    ).slice(0, VALIDATION.PAYMENT_REF_MAX);
    const paidAt = new Date().toISOString().slice(0, 19);

    try {
      await updateDoc(doc(db, 'invoices', selectedInvoice.id), {
        status: 'paid',
        paidAt,
        paymentReference: cleanRef,
        updatedAt: serverTimestamp(),
      });

      const actorRole: UserRole =
        selectedInvoice.labOwnerUid === profile.uid && perspective === 'lab'
          ? 'lab'
          : 'doctor';
      const recipientUid =
        actorRole === 'doctor'
          ? selectedInvoice.labOwnerUid
          : selectedInvoice.doctorUid;

      await recordCaseAuditEvent({
        caseId: selectedInvoice.caseId,
        doctorUid: selectedInvoice.doctorUid,
        labOwnerUid: selectedInvoice.labOwnerUid,
        actorUid: profile.uid,
        actorName: profile.displayName,
        actorRole,
        action: 'INVOICE_PAID',
        summary: `Invoice ${selectedInvoice.invoiceNumber} marked PAID (${selectedInvoice.totalAmount} ${selectedInvoice.currency}) · Ref: ${cleanRef}`,
      });

      await sendCaseStatusNotification({
        recipientUid,
        senderUid: profile.uid,
        caseId: selectedInvoice.caseId,
        caseCode: selectedInvoice.caseCode,
        labName: selectedInvoice.labName,
        clinicName: selectedInvoice.clinicName,
        newStatus: 'invoice_paid',
        customNote: isAr
          ? `تم تأكيد سداد الفاتورة ${selectedInvoice.invoiceNumber} للحالة ${selectedInvoice.caseCode} (${cleanRef}).`
          : `Invoice ${selectedInvoice.invoiceNumber} for case ${selectedInvoice.caseCode} was marked paid (${cleanRef}).`,
      });

      setPaymentFeedback(
        isAr ? 'تم تأكيد سداد الفاتورة بنجاح.' : 'Invoice payment confirmed and recorded.'
      );
      setPaymentRef('');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    } finally {
      setMarkingPaid(false);
    }
  };

  const filterTabs: { id: InvoiceFilter; label: string }[] = isAr
    ? [
        { id: 'all', label: `الكل (${roleInvoices.length})` },
        { id: 'pending', label: `مستحقة الدفع (${summary.pendingCount})` },
        { id: 'paid', label: `مدفوعة (${summary.paidCount})` },
      ]
    : [
        { id: 'all', label: `All (${roleInvoices.length})` },
        { id: 'pending', label: `Pending (${summary.pendingCount})` },
        { id: 'paid', label: `Paid (${summary.paidCount})` },
      ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold text-[#002B6B]">
            {perspective === 'lab'
              ? isAr
                ? 'فواتير المعمل وتحصيل العيادات'
                : 'Laboratory Invoices & Clinic Billing'
              : isAr
                ? 'فواتيري المستحقة والمدفوعة'
                : 'Clinic Invoices — Pending & Paid'}
          </h2>
          <p className="text-sm text-slate-600 mt-0.5">
            {perspective === 'lab'
              ? isAr
                ? 'أصدر فواتير رقمية للحالات المكتملة وتابع الفواتير المستحقة والمدفوعة من الدكاترة.'
                : 'Generate and send itemized digital invoices for completed cases and track clinic payments.'
              : isAr
                ? 'راجع الفواتير المرسلة من المعامل، اطبع الإيصال، وأكّد السداد من مكان واحد.'
                : 'Inspect pending and paid digital invoices from partner laboratories and settle balances.'}
          </p>
        </div>
      </div>

      {/* 4-Column Billing Summary KPI Strip */}
      <div className="glass-panel rounded-2xl grid grid-cols-2 lg:grid-cols-4 divide-y lg:divide-y-0 divide-x rtl:divide-x-reverse divide-[#002B6B]/10 overflow-hidden">
        <div className="p-5">
          <div className="text-xs font-medium text-slate-500">
            {isAr ? 'إجمالي الفواتير' : 'Total Invoices'}
          </div>
          <div className="font-display text-2xl font-bold tabular-nums text-[#002B6B] mt-1">
            {summary.totalCount}
          </div>
        </div>
        <div className="p-5">
          <div className="text-xs font-medium text-slate-500">
            {isAr ? 'فواتير مستحقة الدفع' : 'Pending Invoices'}
          </div>
          <div className="font-display text-2xl font-bold tabular-nums text-amber-700 mt-1">
            {summary.pendingCount}
          </div>
        </div>
        <div className="p-5">
          <div className="text-xs font-medium text-slate-500">
            {isAr ? 'إجمالي المبالغ المستحقة' : 'Pending Balance'}
          </div>
          <div className="font-display text-2xl font-bold tabular-nums text-[#002B6B] mt-1">
            {formatCurrencySummary(summary.pendingTotalEgp, summary.pendingTotalUsd)}
          </div>
        </div>
        <div className="p-5">
          <div className="text-xs font-medium text-slate-500">
            {isAr ? 'إجمالي المدفوع' : 'Paid Volume'}
          </div>
          <div className="font-display text-2xl font-bold tabular-nums text-[#008C99] mt-1">
            {formatCurrencySummary(summary.paidTotalEgp, summary.paidTotalUsd)}
          </div>
        </div>
      </div>

      {/* Completed Cases Ready to Invoice (Lab View) */}
      {perspective === 'lab' && completedCasesReadyToInvoice.length > 0 && (
        <div className="glass-panel rounded-2xl overflow-hidden">
          <div className="px-5 py-3.5 border-b border-[#002B6B]/10 bg-white/50 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-sm font-semibold text-[#002B6B]">
              <FileCheck2 className="w-4 h-4 text-[#00A8B5]" />
              <span>
                {isAr
                  ? `حالات مكتملة جاهزة لإصدار الفاتورة (${completedCasesReadyToInvoice.length})`
                  : `Completed Cases Ready to Invoice (${completedCasesReadyToInvoice.length})`}
              </span>
            </div>
            <span className="text-xs text-slate-500">
              {isAr
                ? 'الحالات دي خلصت ووصلت للعيادة ولم تصدر لها فاتورة رقمية بعد.'
                : 'Delivered cases with no digital invoice issued yet.'}
            </span>
          </div>

          <div className="divide-y divide-[#002B6B]/10">
            {completedCasesReadyToInvoice.map((c) => (
              <div
                key={c.id}
                className="px-5 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-white/40 transition-colors"
              >
                <div className="space-y-0.5">
                  <div className="flex flex-wrap items-center gap-2 text-sm">
                    <span className="font-mono font-semibold text-[#002B6B]">{c.caseCode}</span>
                    <span className="text-slate-400" aria-hidden="true">
                      ·
                    </span>
                    <span className="font-medium text-[#0B1E3B]">{c.clinicName}</span>
                    <span className="text-slate-500 text-xs">({c.doctorName})</span>
                  </div>
                  <div className="text-xs text-slate-600">
                    {c.restorationType} · {c.material} ·{' '}
                    <span className="font-mono tabular-nums">
                      {c.toothNumbers.length} {isAr ? 'وحدات' : 'units'}
                    </span>{' '}
                    ·{' '}
                    <span className="font-mono tabular-nums text-[#002B6B] font-semibold">
                      {formatAmount(c.estimatedFee, c.currency || 'EGP')}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => onOpenCase(c.id)}
                    className="btn-glass-secondary px-3 py-1.5 text-xs font-medium text-[#002B6B] rounded-xl cursor-pointer"
                  >
                    {isAr ? 'عرض الحالة' : 'Inspect Case'}
                  </button>
                  <button
                    type="button"
                    onClick={() => onCreateInvoiceForCase(c)}
                    className="btn-glass-primary inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-xl cursor-pointer"
                  >
                    <Receipt className="w-3.5 h-3.5 text-[#00A8B5]" />
                    <span>{isAr ? 'إصدار وإرسال فاتورة' : 'Issue & Send Invoice'}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Invoices Table Card */}
      <div className="glass-panel rounded-2xl overflow-hidden">
        <div className="p-4 border-b border-[#002B6B]/10 flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 text-[#002B6B]/50 absolute start-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                isAr
                  ? 'ابحث برقم الفاتورة INV أو رقم الحالة أو العيادة...'
                  : 'Search invoice #, case code, clinic, or lab...'
              }
              className="w-full ps-9 pe-3 py-2 text-sm glass-input rounded-xl text-[#0B1E3B]"
            />
          </div>

          <div className="inline-flex items-center gap-1 p-1 glass-surface rounded-xl self-start">
            {filterTabs.map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setStatusFilter(tab.id)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  statusFilter === tab.id
                    ? 'bg-[#002B6B] text-white shadow-xs'
                    : 'text-slate-600 hover:text-[#002B6B]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="p-10 text-center text-sm text-slate-500">
            {isAr ? 'جاري تحميل الفواتير الرقمية...' : 'Loading digital invoices...'}
          </div>
        ) : filteredInvoices.length === 0 ? (
          <div className="p-12 text-center space-y-2">
            <Receipt className="w-8 h-8 text-[#00A8B5]/60 mx-auto" />
            <h3 className="font-display text-base font-semibold text-[#002B6B]">
              {isAr ? 'مفيش فواتير مطابقة للعرض دلوقتي' : 'No matching invoices yet'}
            </h3>
            <p className="text-sm text-slate-600 max-w-md mx-auto">
              {perspective === 'lab'
                ? isAr
                  ? 'أول ما حالة توصل وتكمل، تقدر تصدر لها فاتورة رقمية مباشرة من فوق أو من صفحة تفاصيل الحالة.'
                  : 'Once a case is marked Completed, issue an itemized digital invoice directly from above or from the case drawer.'
                : isAr
                  ? 'أي فاتورة رقمية يصدرها المعمل لحالة مكتملة هتظهر هنا فوراً للمراجعة والسداد.'
                  : 'Digital invoices issued by dental laboratories for completed cases will appear here for review and payment.'}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-start">
              <thead>
                <tr className="border-b border-[#002B6B]/10 bg-white/50 text-xs font-semibold text-slate-600">
                  <th className="py-2.5 px-4 text-start">{isAr ? 'رقم الفاتورة' : 'Invoice #'}</th>
                  <th className="py-2.5 px-4 text-start">{isAr ? 'رقم الحالة' : 'Case Code'}</th>
                  <th className="py-2.5 px-4 text-start">
                    {perspective === 'lab'
                      ? isAr
                        ? 'العيادة والدكتور'
                        : 'Clinic & Doctor'
                      : isAr
                        ? 'المعمل'
                        : 'Laboratory'}
                  </th>
                  <th className="py-2.5 px-4 text-start">{isAr ? 'البيان' : 'Description'}</th>
                  <th className="py-2.5 px-4 text-start">{isAr ? 'الاستحقاق' : 'Due Date'}</th>
                  <th className="py-2.5 px-4 text-start">{isAr ? 'الحالة' : 'Status'}</th>
                  <th className="py-2.5 px-4 text-end">{isAr ? 'الإجمالي' : 'Total'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#002B6B]/10">
                {filteredInvoices.map((inv) => (
                  <tr
                    key={inv.id}
                    onClick={() => {
                      setSelectedInvoiceId(inv.id);
                      setPaymentFeedback(null);
                    }}
                    className="hover:bg-white/60 cursor-pointer transition-colors"
                  >
                    <td className="py-3 px-4 font-mono font-semibold text-[#002B6B] whitespace-nowrap">
                      {inv.invoiceNumber}
                    </td>
                    <td className="py-3 px-4 font-mono text-xs text-[#008C99] font-semibold whitespace-nowrap">
                      {inv.caseCode}
                    </td>
                    <td className="py-3 px-4 text-[#0B1E3B]">
                      <div className="font-medium">
                        {perspective === 'lab' ? inv.clinicName : inv.labName}
                      </div>
                      <div className="text-xs text-slate-500">
                        {perspective === 'lab' ? inv.doctorName : inv.clinicName} ·{' '}
                        <span className="font-mono">{inv.patientChartRef}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-slate-600 max-w-xs truncate">
                      {inv.serviceDescription}
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums text-xs text-slate-700 whitespace-nowrap">
                      {inv.dueDate}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      {inv.status === 'paid' ? (
                        <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700">
                          <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                          <span>{isAr ? 'مدفوعة' : 'Paid'}</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-700">
                          <Clock className="w-3.5 h-3.5 shrink-0" />
                          <span>{isAr ? 'مستحقة الدفع' : 'Pending'}</span>
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-end font-mono tabular-nums font-semibold text-[#002B6B] whitespace-nowrap">
                      {formatAmount(inv.totalAmount, inv.currency)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Itemized Digital Invoice Receipt & Payment Modal */}
      <AnimatePresence>
        {selectedInvoice && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="fixed inset-0 z-50 bg-[#002B6B]/25 backdrop-blur-sm flex items-center justify-center p-4"
            role="dialog"
            aria-modal="true"
            aria-labelledby="invoice-detail-title"
            onClick={closeModal}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.97, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.97, y: 10 }}
              transition={{ duration: 0.2 }}
              className="glass-modal rounded-2xl w-full max-w-2xl max-h-[92vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Modal Header */}
              <div className="px-6 py-4 border-b border-[#002B6B]/10 flex items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2.5">
                    <span
                      id="invoice-detail-title"
                      className="font-mono text-base font-bold text-[#002B6B]"
                    >
                      {selectedInvoice.invoiceNumber}
                    </span>
                    <span className="text-slate-300" aria-hidden="true">
                      ·
                    </span>
                    {selectedInvoice.status === 'paid' ? (
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>{isAr ? 'مدفوعة بالكامل' : 'Paid'}</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-700">
                        <Clock className="w-3.5 h-3.5" />
                        <span>{isAr ? 'مستحقة الدفع' : 'Pending Payment'}</span>
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5 font-mono">
                    {isAr ? 'إصدار:' : 'Issued:'} {selectedInvoice.issuedDate} ·{' '}
                    {isAr ? 'استحقاق:' : 'Due:'} {selectedInvoice.dueDate}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => window.print()}
                    className="btn-glass-secondary inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#002B6B] rounded-xl cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5 text-[#00A8B5]" />
                    <span>{isAr ? 'طباعة' : 'Print'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={closeModal}
                    aria-label={isAr ? 'إغلاق الفاتورة' : 'Close invoice'}
                    className="p-1.5 text-slate-500 hover:text-[#002B6B] rounded-xl hover:bg-white/70 cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="p-6 space-y-5">
                {/* Issuer & Recipient Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 glass-surface rounded-xl p-4 text-xs">
                  <div>
                    <div className="text-slate-500">{isAr ? 'من المعمل' : 'From Laboratory'}</div>
                    <div className="text-sm font-semibold text-[#002B6B] mt-0.5">
                      {selectedInvoice.labName}
                    </div>
                    <div className="text-slate-600 mt-1">
                      {isAr ? 'رقم الحالة:' : 'Case Ref:'}{' '}
                      <button
                        type="button"
                        onClick={() => {
                          const cId = selectedInvoice.caseId;
                          closeModal();
                          onOpenCase(cId);
                        }}
                        className="inline-flex items-center gap-1 font-mono font-semibold text-[#008C99] hover:text-[#002B6B] cursor-pointer"
                      >
                        <span>{selectedInvoice.caseCode}</span>
                        <ExternalLink className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                  <div>
                    <div className="text-slate-500">{isAr ? 'فاتورة إلى العيادة' : 'Bill To Clinic'}</div>
                    <div className="text-sm font-semibold text-[#002B6B] mt-0.5">
                      {selectedInvoice.clinicName}
                    </div>
                    <div className="text-slate-600 mt-1">
                      {selectedInvoice.doctorName} ·{' '}
                      <span className="font-mono">
                        {selectedInvoice.patientInitials} ({selectedInvoice.patientChartRef})
                      </span>
                    </div>
                  </div>
                </div>

                {/* Itemized Line Items */}
                <div className="glass-surface rounded-xl overflow-hidden">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-white/60 border-b border-[#002B6B]/10 text-xs font-semibold text-slate-600">
                        <th className="py-2.5 px-4 text-start">{isAr ? 'البند' : 'Item'}</th>
                        <th className="py-2.5 px-4 text-end">{isAr ? 'الكمية' : 'Units'}</th>
                        <th className="py-2.5 px-4 text-end">{isAr ? 'السعر' : 'Unit Price'}</th>
                        <th className="py-2.5 px-4 text-end">{isAr ? 'المبلغ' : 'Amount'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#002B6B]/10">
                      <tr>
                        <td className="py-3 px-4 text-[#0B1E3B] font-medium">
                          {selectedInvoice.serviceDescription}
                        </td>
                        <td className="py-3 px-4 text-end font-mono tabular-nums text-slate-700">
                          {selectedInvoice.unitCount}
                        </td>
                        <td className="py-3 px-4 text-end font-mono tabular-nums text-slate-700">
                          {formatAmount(selectedInvoice.unitPrice, selectedInvoice.currency)}
                        </td>
                        <td className="py-3 px-4 text-end font-mono tabular-nums font-medium text-[#002B6B]">
                          {formatAmount(
                            selectedInvoice.unitCount * selectedInvoice.unitPrice,
                            selectedInvoice.currency
                          )}
                        </td>
                      </tr>
                      {selectedInvoice.rushFee > 0 && (
                        <tr>
                          <td className="py-2.5 px-4 text-slate-700" colSpan={3}>
                            {isAr ? 'رسوم الاستعجال (Express / Rush SLA)' : 'Express / Rush SLA Fee'}
                          </td>
                          <td className="py-2.5 px-4 text-end font-mono tabular-nums text-[#002B6B]">
                            +{formatAmount(selectedInvoice.rushFee, selectedInvoice.currency)}
                          </td>
                        </tr>
                      )}
                      {selectedInvoice.discountAmount > 0 && (
                        <tr>
                          <td className="py-2.5 px-4 text-[#008C99]" colSpan={3}>
                            {isAr ? 'خصم المعمل' : 'Laboratory Discount'}
                          </td>
                          <td className="py-2.5 px-4 text-end font-mono tabular-nums text-[#008C99]">
                            −{formatAmount(selectedInvoice.discountAmount, selectedInvoice.currency)}
                          </td>
                        </tr>
                      )}
                    </tbody>
                    <tfoot>
                      <tr className="bg-white/60 border-t border-[#002B6B]/10">
                        <td className="py-3 px-4 font-semibold text-[#002B6B]" colSpan={3}>
                          {isAr ? 'الإجمالي المستحق' : 'Total Invoice Amount'}
                        </td>
                        <td className="py-3 px-4 text-end font-display text-lg font-bold tabular-nums text-[#002B6B]">
                          {formatAmount(selectedInvoice.totalAmount, selectedInvoice.currency)}
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>

                {selectedInvoice.notes && (
                  <div className="glass-surface rounded-xl p-3.5 text-xs text-slate-700">
                    <div className="font-semibold text-[#002B6B] mb-1">
                      {isAr ? 'ملاحظات الدفع والتحويل:' : 'Payment Instructions / Notes:'}
                    </div>
                    <p className="leading-relaxed">{selectedInvoice.notes}</p>
                  </div>
                )}

                {paymentFeedback && (
                  <div
                    role="status"
                    className="p-3 rounded-xl border border-emerald-200 bg-emerald-50/90 text-xs text-emerald-800 flex items-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>{paymentFeedback}</span>
                  </div>
                )}

                {/* Paid Receipt Details OR Pending Settlement Controls */}
                {selectedInvoice.status === 'paid' ? (
                  <div className="border border-emerald-200 bg-emerald-50/80 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-2 text-emerald-800 font-semibold">
                      <CheckCircle2 className="w-4 h-4 shrink-0" />
                      <span>{isAr ? 'تم سداد هذه الفاتورة' : 'Invoice Settled & Paid'}</span>
                    </div>
                    <div className="font-mono text-slate-700 space-x-3 rtl:space-x-reverse">
                      {selectedInvoice.paymentReference && (
                        <span>
                          {isAr ? 'المرجع:' : 'Ref:'} {selectedInvoice.paymentReference}
                        </span>
                      )}
                      {selectedInvoice.paidAt && (
                        <span>{selectedInvoice.paidAt.replace('T', ' ')}</span>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="glass-surface rounded-xl p-4 space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2 text-xs font-semibold text-[#002B6B]">
                        <Wallet className="w-4 h-4 text-[#00A8B5]" />
                        <span>
                          {perspective === 'lab'
                            ? isAr
                              ? 'تأكيد استلام السداد من العيادة'
                              : 'Record Payment Received'
                            : isAr
                              ? 'سداد الفاتورة وتأكيد التحويل'
                              : 'Pay & Settle Digital Invoice'}
                        </span>
                      </div>

                      {perspective === 'lab' &&
                        selectedInvoice.labOwnerUid === profile.uid && (
                          <button
                            type="button"
                            onClick={() => {
                              const matchingCase = labCases.find(
                                (c) => c.id === selectedInvoice.caseId
                              );
                              if (matchingCase) {
                                closeModal();
                                onCreateInvoiceForCase(matchingCase, selectedInvoice);
                              }
                            }}
                            className="inline-flex items-center gap-1.5 text-xs font-medium text-[#008C99] hover:text-[#002B6B] cursor-pointer"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>{isAr ? 'تعديل المبلغ / البنود' : 'Adjust Invoice'}</span>
                          </button>
                        )}
                    </div>

                    <form onSubmit={handleMarkAsPaid} className="space-y-3">
                      <div className="flex flex-wrap items-center gap-2">
                        {(isAr
                          ? ['تحويل Instapay', 'تحويل بنكي', 'نقدي للمندوب']
                          : ['Instapay Transfer', 'Bank Transfer', 'Cash to Courier']
                        ).map((preset) => (
                          <button
                            key={preset}
                            type="button"
                            onClick={() => setPaymentRef(preset)}
                            className="btn-glass-secondary px-2.5 py-1 text-xs rounded-lg text-[#002B6B] cursor-pointer"
                          >
                            {preset}
                          </button>
                        ))}
                      </div>

                      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                        <input
                          type="text"
                          maxLength={VALIDATION.PAYMENT_REF_MAX}
                          value={paymentRef}
                          onChange={(e) => setPaymentRef(e.target.value)}
                          placeholder={
                            isAr
                              ? 'رقم مرجع التحويل أو طريقة الدفع (مثلاً: Instapay #88421)'
                              : 'Payment reference or method (e.g. Instapay #88421)'
                          }
                          className="flex-1 px-3 py-2 text-sm glass-input rounded-xl text-[#0B1E3B]"
                        />
                        <button
                          type="submit"
                          disabled={markingPaid}
                          className="btn-glass-teal inline-flex items-center justify-center gap-1.5 px-4 py-2 text-sm font-semibold rounded-xl disabled:opacity-60 cursor-pointer whitespace-nowrap"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          <span>
                            {markingPaid
                              ? isAr
                                ? 'جاري التأكيد...'
                                : 'Confirming...'
                              : isAr
                                ? 'تأكيد السداد'
                                : 'Mark as Paid'}
                          </span>
                        </button>
                      </div>
                    </form>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
