import { useState } from 'react';

export const LABI_LOGO_SRC =
  '/assets/aistudio/file_00000000076c8210b21c3d5791cdd4ab_bd7be7f2.png';

interface BrandLogoProps {
  size?: 'sm' | 'md' | 'lg';
  framed?: boolean;
  className?: string;
}

export function BrandLogo({
  size = 'md',
  framed = false,
  className = '',
}: BrandLogoProps) {
  const [failed, setFailed] = useState(false);

  const sizeClass =
    size === 'sm'
      ? 'h-8 w-auto'
      : size === 'lg'
        ? 'h-16 w-auto'
        : 'h-10 w-auto';

  if (failed) {
    return (
      <span
        className={`inline-flex items-center font-display font-bold tracking-tight text-[#002B6B] whitespace-nowrap shrink-0 ${
          size === 'lg' ? 'text-2xl' : 'text-xl'
        } ${className}`}
      >
        Lab<span className="text-[#00A8B5]">i</span>
      </span>
    );
  }

  const imgEl = (
    <img
      src={LABI_LOGO_SRC}
      alt="Labi"
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={`${sizeClass} object-contain mix-blend-multiply select-none ${className}`}
    />
  );

  if (framed) {
    return (
      <span className="inline-flex items-center justify-center p-2.5 rounded-2xl glass-panel">
        {imgEl}
      </span>
    );
  }

  return imgEl;
}
