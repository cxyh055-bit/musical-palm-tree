import { useState } from 'react';
import { sendEmailVerification, type User } from 'firebase/auth';
import { AuthShell } from './AuthShell';

interface Props {
  user: User;
  onChecked: () => void;
  onSignOut: () => void;
}

export function VerifyEmailView({ user, onChecked, onSignOut }: Props) {
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const check = async () => {
    setBusy(true);
    setMsg(null);
    try {
      await user.reload();
      await user.getIdToken(true);
      if (user.emailVerified) {
        onChecked();
      } else {
        setMsg('لسه الإيميل ما اتأكدش. افتح الرسالة واضغط على اللينك الأول.');
      }
    } catch {
      setMsg('حصلت مشكلة، جرّب تاني.');
    } finally {
      setBusy(false);
    }
  };

  const resend = async () => {
    setMsg(null);
    try {
      await sendEmailVerification(user);
      setMsg('بعتنالك الرسالة تاني، شوف الـ Spam كمان.');
    } catch {
      setMsg('استنى شوية قبل ما تبعت تاني.');
    }
  };

  return (
    <AuthShell title="أكّد الإيميل بتاعك" subtitle="خطوة أخيرة وتبدأ">
      <p className="text-center text-sm leading-7 text-[#31496a]">
        بعتنا رسالة تأكيد على <span dir="ltr" className="font-semibold">{user.email}</span>.
        افتح الرسالة واضغط على اللينك، وبعدها ارجع هنا واضغط الزرار.
      </p>
      {msg && (
        <div className="mt-4 rounded-2xl border border-[#CFE0EE] bg-white p-3 text-center text-sm text-[#002B6B]">
          {msg}
        </div>
      )}
      <button
        type="button"
        onClick={check}
        disabled={busy}
        className="mt-5 w-full rounded-2xl bg-[#002B6B] py-3.5 text-[15px] font-bold text-white shadow-[0_8px_20px_rgba(0,43,107,0.3)] disabled:opacity-60"
      >
        {busy ? 'استنى...' : 'أكدت الإيميل'}
      </button>
      <button type="button" onClick={resend} className="mx-auto mt-4 block text-sm text-[#002B6B] underline">
        ابعت الرسالة تاني
      </button>
      <button type="button" onClick={onSignOut} className="mx-auto mt-4 block text-sm text-[#4b6483] underline">
        خروج
      </button>
    </AuthShell>
  );
}
