import { useMemo, useState, type FormEvent } from 'react';
import { doc, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import { motion } from 'motion/react';
import { Receipt, Send, X } from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { MATERIAL_LABELS_AR, RESTORATION_LABELS_AR, useLang } from '../i18n';
import {
  VALIDATION,
  type CurrencyCode,
  type DentalCase,
  type DigitalInvoice,
  type UserProfile,
} from '../types';
import { recordCaseAuditEvent } from '../utils/auditLog';
import { sendCaseStatusNotification } from '../utils/notifications';

interface CreateInvoiceModalProps {
  dentalCase: DentalCase;
  profile: UserProfile;
  existingInvoice?: DigitalInvoice | null;
  onClose: () => void;
  onSaved: (invoiceId: string) => void;
}

function getDefaultDueDate(daysAhead = 7): string {
  const d = new Date();
  d.setDate(d.getDate() + daysAhead);
  return d.toISOString().slice(0, 10);
}

export function CreateInvoiceModal({
  dentalCase,
  profile,
  existingInvoice,
  onClose,
  onSaved,
}: CreateInvoiceModalProps) {
  const { lang } = useLang();
  const isAr = lang === 'ar';
  const isEditingPending = Boolean(existingInvoice && existingInvoice.status === 'pending');

  const initialUnits = existingInvoice
    ? existingInvoice.unitCount
    : Math.max(1, Math.min(32, dentalCase.toothNumbers.length || 1));
  const initialRush = existingInvoice
    ? existingInvoice.rushFee
    : dentalCase.priority === 'Rush'
      ? 400
      : 0;
  const derivedUnitPrice = existingInvoice
    ? existingInvoice.unitPrice
    : Math.max(
        0,
        Math.round(Math.max(0, (dentalCase.estimatedFee || 0) - initialRush) / initialUnits)
      );

  const defaultDesc = isAr
    ? `${RESTORATION_LABELS_AR[dentalCase.restorationType] || dentalCase.restorationType} — ${
        MATERIAL_LABELS_AR[dentalCase.material] || dentalCase.material
      } (${dentalCase.toothNumbers.join(', ')})`
    : `${dentalCase.restorationType} — ${dentalCase.material} (Teeth ${dentalCase.toothNumbers.join(', ')})`;

  const [serviceDescription, setServiceDescription] = useState(
    existingInvoice?.serviceDescription || defaultDesc.slice(0, VALIDATION.INVOICE_DESC_MAX)
  );
  const [unitCount, setUnitCount] = useState<number>(initialUnits);
  const [unitPrice, setUnitPrice] = useState<number>(derivedUnitPrice);
  const [rushFee, setRushFee] = useState<number>(initialRush);
  const [discountAmount, setDiscountAmount] = useState<number>(
    existingInvoice?.discountAmount ?? 0
  );
  const [currency, setCurrency] = useState<CurrencyCode>(
    existingInvoice?.currency || dentalCase.currency || 'EGP'
  );
  const [dueDate, setDueDate] = useState(
    existingInvoice?.dueDate || getDefaultDueDate(7)
  );
  const [notes, setNotes] = useState(existingInvoice?.notes || '');
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const subtotal = useMemo(() => {
    const safeUnits = Math.min(32, Math.max(1, Math.round(Number(unitCount) || 1)));
    const safePrice = Math.min(VALIDATION.MAX_FEE, Math.max(0, Number(unitPrice) || 0));
    return Math.round(safeUnits * safePrice);
  }, [unitCount, unitPrice]);

  const totalAmount = useMemo(() => {
    const safeRush = Math.min(50000, Math.max(0, Number(rushFee) || 0));
    const safeDiscount = Math.min(VALIDATION.MAX_FEE, Math.max(0, Number(discountAmount) || 0));
    return Math.min(VALIDATION.MAX_FEE, Math.max(0, Math.round(subtotal + safeRush - safeDiscount)));
  }, [subtotal, rushFee, discountAmount]);

  const currencyLabel = currency === 'EGP' ? (isAr ? 'ج.م' : 'EGP') : 'USD';

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const cleanDesc = serviceDescription.trim().slice(0, VALIDATION.INVOICE_DESC_MAX);
    if (cleanDesc.length < 2) {
      setErrorMsg(
        isAr ? 'اكتب وصف الخدمة المطلوبة (حرفين على الأقل).' : 'Please enter a valid service description.'
      );
      return;
    }

    if (!VALIDATION.DATE_PATTERN.test(dueDate)) {
      setErrorMsg(
        isAr ? 'اختر تاريخ استحقاق صحيح.' : 'Please select a valid due date.'
      );
      return;
    }

    const cleanUnits = Math.min(32, Math.max(1, Math.round(Number(unitCount) || 1)));
    const cleanUnitPrice = Math.min(VALIDATION.MAX_FEE, Math.max(0, Math.round(Number(unitPrice) || 0)));
    const cleanRush = Math.min(50000, Math.max(0, Math.round(Number(rushFee) || 0)));
    const cleanDiscount = Math.min(
      VALIDATION.MAX_FEE,
      Math.max(0, Math.round(Number(discountAmount) || 0))
    );
    const cleanTotal = Math.min(
      VALIDATION.MAX_FEE,
      Math.max(0, Math.round(cleanUnits * cleanUnitPrice + cleanRush - cleanDiscount))
    );
    const cleanNotes = notes.trim().slice(0, VALIDATION.INVOICE_NOTES_MAX);

    setSubmitting(true);

    try {
      if (isEditingPending && existingInvoice) {
        const path = `invoices/${existingInvoice.id}`;
        try {
          await updateDoc(doc(db, 'invoices', existingInvoice.id), {
            unitPrice: cleanUnitPrice,
            rushFee: cleanRush,
            discountAmount: cleanDiscount,
            totalAmount: cleanTotal,
            notes: cleanNotes,
            dueDate,
            updatedAt: serverTimestamp(),
          });

          await recordCaseAuditEvent({
            caseId: dentalCase.id,
            doctorUid: dentalCase.doctorUid,
            labOwnerUid: dentalCase.labOwnerUid,
            actorUid: profile.uid,
            actorName: profile.displayName,
            actorRole: 'lab',
            action: 'INVOICE_UPDATED',
            summary: `Updated pending invoice ${existingInvoice.invoiceNumber} to ${cleanTotal} ${currency}`,
          });

          onSaved(existingInvoice.id);
        } catch (err) {
          handleFirestoreError(err, OperationType.UPDATE, path);
        }
        return;
      }

      const invoiceId = `inv-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
      const invoiceNumber = `INV-${Math.floor(100000 + Math.random() * 900000)}`;
      const issuedDate = new Date().toISOString().slice(0, 10);
      const path = `invoices/${invoiceId}`;

      try {
        await setDoc(doc(db, 'invoices', invoiceId), {
          id: invoiceId,
          invoiceNumber,
          caseId: dentalCase.id,
          caseCode: dentalCase.caseCode,
          labId: dentalCase.labId,
          labName: dentalCase.labName.slice(0, VALIDATION.ORG_NAME_MAX),
          labOwnerUid: dentalCase.labOwnerUid,
          doctorUid: dentalCase.doctorUid,
          doctorName: dentalCase.doctorName.slice(0, VALIDATION.DISPLAY_NAME_MAX),
          clinicName: dentalCase.clinicName.slice(0, VALIDATION.ORG_NAME_MAX),
          patientInitials: dentalCase.patientInitials.slice(0, 6),
          patientChartRef: dentalCase.patientChartRef.slice(0, VALIDATION.CHART_REF_MAX),
          serviceDescription: cleanDesc,
          unitCount: cleanUnits,
          unitPrice: cleanUnitPrice,
          rushFee: cleanRush,
          discountAmount: cleanDiscount,
          totalAmount: cleanTotal,
          currency,
          notes: cleanNotes,
          status: 'pending',
          issuedDate,
          dueDate,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        await recordCaseAuditEvent({
          caseId: dentalCase.id,
          doctorUid: dentalCase.doctorUid,
          labOwnerUid: dentalCase.labOwnerUid,
          actorUid: profile.uid,
          actorName: profile.displayName,
          actorRole: 'lab',
          action: 'INVOICE_ISSUED',
          summary: `Issued digital invoice ${invoiceNumber} (${cleanTotal} ${currency}, due ${dueDate})`,
        });

        await sendCaseStatusNotification({
          recipientUid: dentalCase.doctorUid,
          senderUid: profile.uid,
          caseId: dentalCase.id,
          caseCode: dentalCase.caseCode,
          labName: dentalCase.labName,
          clinicName: dentalCase.clinicName,
          newStatus: 'invoice_sent',
          customNote: isAr
            ? `أصدر ${dentalCase.labName} فاتورة رقمية ${invoiceNumber} بقيمة ${cleanTotal.toLocaleString()} ${currencyLabel} للحالة ${dentalCase.caseCode}.`
            : `${dentalCase.labName} sent invoice ${invoiceNumber} (${cleanTotal.toLocaleString()} ${currencyLabel}) for case ${dentalCase.caseCode}.`,
        });

        onSaved(invoiceId);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, path);
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.16 }}
      className="fixed inset-0 z-50 bg-[#002B6B]/25 backdrop-blur-sm flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="create-invoice-title"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.97, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.2 }}
        className="glass-modal rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
      >
        <div className="px-6 py-4 border-b border-[#002B6B]/10 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <Receipt className="w-5 h-5 text-[#00A8B5] shrink-0" />
            <div>
              <h2
                id="create-invoice-title"
                className="font-display text-base font-semibold text-[#002B6B]"
              >
                {isEditingPending
                  ? isAr
                    ? `تعديل الفاتورة ${existingInvoice?.invoiceNumber}`
                    : `Adjust Invoice ${existingInvoice?.invoiceNumber}`
                  : isAr
                    ? 'إصدار وإرسال فاتورة رقمية للعيادة'
                    : 'Generate & Send Digital Invoice'}
              </h2>
              <p className="text-xs text-slate-500 font-mono">
                {dentalCase.caseCode} · {dentalCase.clinicName} ({dentalCase.doctorName})
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label={isAr ? 'إغلاق' : 'Close'}
            className="p-1.5 text-slate-500 hover:text-[#002B6B] rounded-xl hover:bg-white/70 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Case & Billing Target Summary */}
          <div className="glass-surface rounded-xl p-4 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div>
              <div className="text-slate-500">{isAr ? 'العيادة المستلمة' : 'Bill To Clinic'}</div>
              <div className="font-semibold text-[#002B6B] mt-0.5">{dentalCase.clinicName}</div>
              <div className="text-slate-600">{dentalCase.doctorName}</div>
            </div>
            <div>
              <div className="text-slate-500">{isAr ? 'ملف المريض' : 'Patient Chart'}</div>
              <div className="font-mono tabular-nums font-semibold text-[#002B6B] mt-0.5">
                {dentalCase.patientInitials} · {dentalCase.patientChartRef}
              </div>
              <div className="text-slate-600">
                {isAr ? 'الأسنان:' : 'Teeth:'} {dentalCase.toothNumbers.join(', ')}
              </div>
            </div>
            <div>
              <div className="text-slate-500">{isAr ? 'المعمل المُصدر' : 'Issuing Lab'}</div>
              <div className="font-semibold text-[#002B6B] mt-0.5">{dentalCase.labName}</div>
              <div className="font-mono tabular-nums text-[#008C99] font-medium">
                {isAr ? 'تقدير الحالة:' : 'Case Est.:'}{' '}
                {dentalCase.estimatedFee.toLocaleString()} {currencyLabel}
              </div>
            </div>
          </div>

          <div>
            <label
              htmlFor="inv-desc"
              className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
            >
              {isAr ? 'وصف البند / الشغل المنفذ' : 'Service & Restoration Description'}
            </label>
            <input
              id="inv-desc"
              type="text"
              required
              disabled={isEditingPending}
              maxLength={VALIDATION.INVOICE_DESC_MAX}
              value={serviceDescription}
              onChange={(e) => setServiceDescription(e.target.value)}
              className="w-full px-3 py-2 text-sm glass-input rounded-xl text-[#0B1E3B] disabled:opacity-60"
            />
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label
                htmlFor="inv-units"
                className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
              >
                {isAr ? 'عدد الوحدات / الأسنان' : 'Units / Teeth'}
              </label>
              <input
                id="inv-units"
                type="number"
                min={1}
                max={32}
                required
                disabled={isEditingPending}
                value={unitCount}
                onChange={(e) => setUnitCount(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm font-mono tabular-nums glass-input rounded-xl text-[#0B1E3B] disabled:opacity-60"
              />
            </div>

            <div>
              <label
                htmlFor="inv-unit-price"
                className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
              >
                {isAr ? `سعر الوحدة (${currencyLabel})` : `Unit Price (${currencyLabel})`}
              </label>
              <input
                id="inv-unit-price"
                type="number"
                min={0}
                max={VALIDATION.MAX_FEE}
                required
                value={unitPrice}
                onChange={(e) => setUnitPrice(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm font-mono tabular-nums glass-input rounded-xl text-[#0B1E3B]"
              />
            </div>

            <div>
              <label
                htmlFor="inv-rush"
                className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
              >
                {isAr ? `رسوم استعجال (${currencyLabel})` : `Rush Fee (${currencyLabel})`}
              </label>
              <input
                id="inv-rush"
                type="number"
                min={0}
                max={50000}
                value={rushFee}
                onChange={(e) => setRushFee(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm font-mono tabular-nums glass-input rounded-xl text-[#0B1E3B]"
              />
            </div>

            <div>
              <label
                htmlFor="inv-discount"
                className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
              >
                {isAr ? `خصم (${currencyLabel})` : `Discount (${currencyLabel})`}
              </label>
              <input
                id="inv-discount"
                type="number"
                min={0}
                max={VALIDATION.MAX_FEE}
                value={discountAmount}
                onChange={(e) => setDiscountAmount(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm font-mono tabular-nums glass-input rounded-xl text-[#0B1E3B]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="inv-due"
                className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
              >
                {isAr ? 'تاريخ استحقاق السداد' : 'Payment Due Date'}
              </label>
              <input
                id="inv-due"
                type="date"
                required
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono glass-input rounded-xl text-[#0B1E3B]"
              />
            </div>

            <div>
              <label
                htmlFor="inv-currency"
                className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
              >
                {isAr ? 'العملة' : 'Currency'}
              </label>
              <select
                id="inv-currency"
                disabled={isEditingPending}
                value={currency}
                onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                className="w-full px-3 py-2 text-sm glass-input rounded-xl text-[#0B1E3B] disabled:opacity-60"
              >
                <option value="EGP">{isAr ? 'جنيه مصري (EGP)' : 'Egyptian Pound (EGP)'}</option>
                <option value="USD">{isAr ? 'دولار أمريكي (USD)' : 'US Dollar (USD)'}</option>
              </select>
            </div>
          </div>

          <div>
            <label
              htmlFor="inv-notes"
              className="block text-xs font-medium text-[#0B1E3B]/80 mb-1.5"
            >
              {isAr ? 'ملاحظات الدفع أو حساب التحويل (اختياري)' : 'Payment Instructions / Notes (Optional)'}
            </label>
            <textarea
              id="inv-notes"
              rows={2}
              maxLength={VALIDATION.INVOICE_NOTES_MAX}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={
                isAr
                  ? 'مثلاً: التحويل على Instapay أو الدفع نقدي مع مندوب التحصيل...'
                  : 'e.g. Pay via Instapay, bank transfer, or cash to lab courier...'
              }
              className="w-full px-3 py-2 text-sm glass-input rounded-xl text-[#0B1E3B]"
            />
          </div>

          {/* Live Calculated Summary Strip */}
          <div className="glass-surface rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
            <div className="text-xs text-slate-600 space-y-1">
              <div>
                {isAr ? 'المجموع الفرعي للوحدات:' : 'Units Subtotal:'}{' '}
                <span className="font-mono tabular-nums text-[#002B6B] font-semibold">
                  {subtotal.toLocaleString()} {currencyLabel}
                </span>
              </div>
              <div className="text-slate-500">
                {isAr
                  ? `+ استعجال ${Math.max(0, rushFee).toLocaleString()} − خصم ${Math.max(0, discountAmount).toLocaleString()}`
                  : `+ Rush ${Math.max(0, rushFee).toLocaleString()} − Discount ${Math.max(0, discountAmount).toLocaleString()}`}
              </div>
            </div>
            <div className="text-end">
              <div className="text-xs text-slate-500">
                {isAr ? 'إجمالي الفاتورة المستحق' : 'Invoice Total'}
              </div>
              <div className="font-display text-2xl font-bold tabular-nums text-[#002B6B]">
                {totalAmount.toLocaleString()} {currencyLabel}
              </div>
            </div>
          </div>

          {errorMsg && (
            <div className="p-3 rounded-xl border border-red-200 bg-red-50/90 text-xs text-red-700">
              {errorMsg}
            </div>
          )}

          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="btn-glass-secondary px-4 py-2 text-sm font-medium text-[#002B6B] rounded-xl cursor-pointer"
            >
              {isAr ? 'إلغاء' : 'Cancel'}
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="btn-glass-primary inline-flex items-center gap-2 px-5 py-2 text-sm font-semibold rounded-xl disabled:opacity-60 cursor-pointer"
            >
              <Send className="w-4 h-4 text-[#00A8B5]" />
              <span>
                {submitting
                  ? isAr
                    ? 'جاري الإرسال...'
                    : 'Sending...'
                  : isEditingPending
                    ? isAr
                      ? 'حفظ تعديل الفاتورة'
                      : 'Save Invoice Update'
                    : isAr
                      ? 'إصدار وإرسال الفاتورة للدكتور'
                      : 'Send Digital Invoice'}
              </span>
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
}
