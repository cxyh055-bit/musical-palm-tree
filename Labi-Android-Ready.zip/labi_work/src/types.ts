import type { Timestamp } from 'firebase/firestore';

export type UserRole = 'doctor' | 'lab';

export type CaseStatus =
  | 'submitted'
  | 'courier_picked_up'
  | 'courier_arrived_lab'
  | 'received'
  | 'accepted'
  | 'in_progress'
  | 'in_design'
  | 'milling'
  | 'quality_check'
  | 'awaiting_approval'
  | 'out_for_delivery'
  | 'shipped'
  | 'completed'
  | 'delivered'
  | 'revision_requested';

export type RestorationType =
  | 'Crown'
  | 'Bridge'
  | 'Veneer'
  | 'Implant Abutment'
  | 'Clear Aligner'
  | 'Denture'
  | 'Nightguard';

export type MaterialType =
  | 'Monolithic Zirconia'
  | 'Layered E.max'
  | 'PFM'
  | 'Titanium Custom'
  | 'PMMA Provisional'
  | '3D Printed Resin'
  | 'Thermoformed PETG';

export type ScannerSource =
  | '3Shape TRIOS'
  | 'iTero Element'
  | 'Medit i700'
  | 'Dentsply Primescan'
  | 'Physical Impression';

export type PriceTier = 'Standard' | 'Boutique' | 'Enterprise';
export type LabImageKey = 'ceramics' | 'cad' | 'implants' | 'studio';
export type MessageType = 'chat' | 'status_update' | 'info_request';
export type CurrencyCode = 'EGP' | 'USD';

export interface LabPriceList {
  zirconiaCrown?: number;
  emaxVeneer?: number;
  implantAbutment?: number;
  clearAligner?: number;
  denture?: number;
  rushFee?: number;
  currency?: CurrencyCode;
}

export interface XrayAttachment {
  id: string;
  name: string;
  dataUrl: string;
  uploadedAt: string;
}

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  role: UserRole;
  organizationName: string;
  licenseNumber?: string;
  city?: string;
  area?: string;
  clinicAddress?: string;
  latitude?: number;
  longitude?: number;
  phone?: string;
  dentalSpecialty?: string;
  yearsExperience?: number;
  services?: string[];
  turnaroundDays?: number;
  accreditations?: string[];
  profilePhotoUrl?: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface DentalLab {
  id: string;
  ownerUid: string;
  name: string;
  city: string;
  area?: string;
  latitude?: number;
  longitude?: number;
  turnaroundDays: number;
  expressHours?: number;
  specialties: string[];
  materials: string[];
  scannerSupport: string[];
  accreditations?: string[];
  priceTier: PriceTier;
  priceList?: LabPriceList;
  summary: string;
  imageKey: LabImageKey;
  acceptingCases: boolean;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface DentalCase {
  id: string;
  caseCode: string;
  doctorUid: string;
  doctorName: string;
  clinicName: string;
  labId: string;
  labName: string;
  labOwnerUid: string;
  patientInitials: string;
  patientChartRef: string;
  patientAgeGroup?: 'Adult' | 'Pediatric';
  restorationType: RestorationType;
  material: MaterialType;
  requiredLabWork?: string;
  toothNumbers: string[];
  shade: string;
  scannerSource: ScannerSource;
  scanReference: string;
  xrayAttachments?: XrayAttachment[];
  priority: 'Standard' | 'Rush';
  dueDate: string;
  clinicalNotes: string;
  status: CaseStatus;
  trackingCode: string;
  courierName?: string;
  courierPhone?: string;
  courierEta?: string;
  trackingNote?: string;
  estimatedFee: number;
  currency?: CurrencyCode;
  encryptionKeyB64: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface CaseMessage {
  id: string;
  caseId: string;
  doctorUid: string;
  labOwnerUid: string;
  senderUid: string;
  senderName: string;
  senderRole: UserRole;
  messageType: MessageType;
  ciphertext: string;
  iv: string;
  algorithm: 'AES-GCM-256';
  contentHash: string;
  createdAt: Timestamp;
}

export interface CaseAuditLog {
  id: string;
  caseId: string;
  doctorUid: string;
  labOwnerUid: string;
  actorUid: string;
  actorName: string;
  actorRole: UserRole;
  action: string;
  summary: string;
  digestHash: string;
  createdAt: Timestamp;
}

export type NotificationEventStatus = CaseStatus | 'invoice_sent' | 'invoice_paid';

export interface CaseNotification {
  id: string;
  recipientUid: string;
  senderUid: string;
  caseId: string;
  caseCode: string;
  labName: string;
  clinicName: string;
  newStatus: NotificationEventStatus;
  titleAr: string;
  titleEn: string;
  bodyAr: string;
  bodyEn: string;
  read: boolean;
  createdAt: Timestamp;
}

export type InvoiceStatus = 'pending' | 'paid';

export interface DigitalInvoice {
  id: string;
  invoiceNumber: string;
  caseId: string;
  caseCode: string;
  labId: string;
  labName: string;
  labOwnerUid: string;
  doctorUid: string;
  doctorName: string;
  clinicName: string;
  patientInitials: string;
  patientChartRef: string;
  serviceDescription: string;
  unitCount: number;
  unitPrice: number;
  rushFee: number;
  discountAmount: number;
  totalAmount: number;
  currency: CurrencyCode;
  notes: string;
  status: InvoiceStatus;
  issuedDate: string;
  dueDate: string;
  paidAt?: string;
  paymentReference?: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export const VALIDATION = {
  ID_PATTERN: /^[a-zA-Z0-9_-]+$/,
  CASE_CODE_PATTERN: /^LABI-[0-9]{4,8}$/,
  INVOICE_NUMBER_PATTERN: /^INV-[0-9]{4,8}$/,
  INITIALS_PATTERN: /^[A-Za-z\u0600-\u06FF.]{1,6}$/,
  DATE_PATTERN: /^[0-9]{4}-[0-9]{2}-[0-9]{2}$/,
  DISPLAY_NAME_MAX: 80,
  ORG_NAME_MAX: 100,
  CITY_MAX: 60,
  AREA_MAX: 80,
  ADDRESS_MAX: 160,
  SPECIALTY_MAX: 80,
  LICENSE_MAX: 40,
  PHONE_MAX: 30,
  LAB_SUMMARY_MAX: 400,
  REQUIRED_WORK_MAX: 400,
  CHART_REF_MAX: 32,
  SHADE_MAX: 20,
  SCAN_REF_MAX: 120,
  NOTES_MAX: 1000,
  TRACKING_MAX: 64,
  COURIER_NAME_MAX: 80,
  COURIER_ETA_MAX: 60,
  TRACKING_NOTE_MAX: 200,
  MESSAGE_MAX: 1000,
  NOTIFICATION_TITLE_MAX: 140,
  NOTIFICATION_BODY_MAX: 260,
  INVOICE_DESC_MAX: 240,
  INVOICE_NOTES_MAX: 500,
  PAYMENT_REF_MAX: 80,
  MAX_FEE: 250000,
  PROFILE_PHOTO_MAX_CHARS: 110000,
  XRAY_MAX_CHARS: 240000,
  XRAY_MAX_COUNT: 3,
} as const;

export const DENTAL_SPECIALTIES = [
  'General Dentistry',
  'Prosthodontics',
  'Implantology',
  'Cosmetic & Esthetic Dentistry',
  'Orthodontics',
  'Endodontics',
  'Periodontics',
];

export const LAB_SERVICES_LIST = [
  'Esthetic Ceramics',
  'Monolithic Zirconia',
  'Implant Prosthetics',
  'Clear Aligners',
  'Full-Arch All-on-4',
  'Removable Dentures',
  '3D Surgical Guides',
  'Occlusal Nightguards',
];

export const LAB_ACCREDITATIONS_LIST = [
  'CDT Certified Lab',
  'ISO 13485 Medical Devices',
  'FDA Registered Facility',
  'NADL Member',
  'DAMAS Accredited',
  '3Shape Certified Partner',
];

export const RESTORATION_TYPES: RestorationType[] = [
  'Crown',
  'Bridge',
  'Veneer',
  'Implant Abutment',
  'Clear Aligner',
  'Denture',
  'Nightguard',
];

export const MATERIAL_TYPES: MaterialType[] = [
  'Monolithic Zirconia',
  'Layered E.max',
  'PFM',
  'Titanium Custom',
  'PMMA Provisional',
  '3D Printed Resin',
  'Thermoformed PETG',
];

export const SCANNER_SOURCES: ScannerSource[] = [
  '3Shape TRIOS',
  'iTero Element',
  'Medit i700',
  'Dentsply Primescan',
  'Physical Impression',
];

export const VITA_SHADES = [
  'A1',
  'A2',
  'A3',
  'A3.5',
  'B1',
  'B2',
  'C1',
  'D2',
  'BL2',
  'BL3',
  '1M1',
  '2M2',
];

export const CASE_STAGE_ORDER: CaseStatus[] = [
  'submitted',
  'courier_picked_up',
  'courier_arrived_lab',
  'received',
  'in_progress',
  'awaiting_approval',
  'out_for_delivery',
  'completed',
];

export const CASE_STATUS_LABELS: Record<CaseStatus, string> = {
  submitted: 'Submitted',
  courier_picked_up: 'Courier Picked Up',
  courier_arrived_lab: 'Courier Arrived at Lab',
  received: 'Lab Received',
  accepted: 'Lab Received',
  in_progress: 'In Progress',
  in_design: 'In Progress',
  milling: 'In Progress',
  quality_check: 'Awaiting Approval',
  awaiting_approval: 'Awaiting Approval',
  out_for_delivery: 'Delivery On The Way',
  shipped: 'Delivery On The Way',
  completed: 'Completed',
  delivered: 'Completed',
  revision_requested: 'Revision Requested',
};

export function normalizeCaseStageIndex(status: CaseStatus): number {
  switch (status) {
    case 'submitted':
      return 0;
    case 'courier_picked_up':
      return 1;
    case 'courier_arrived_lab':
      return 2;
    case 'received':
    case 'accepted':
      return 3;
    case 'in_progress':
    case 'in_design':
    case 'milling':
      return 4;
    case 'awaiting_approval':
    case 'quality_check':
      return 5;
    case 'out_for_delivery':
    case 'shipped':
      return 6;
    case 'completed':
    case 'delivered':
      return 7;
    case 'revision_requested':
      return 4;
  }
}

export function estimateLabPriceForRestoration(
  lab: DentalLab | null,
  restorationType: RestorationType,
  toothCount: number,
  priority: 'Standard' | 'Rush'
): { amount: number; currency: CurrencyCode } {
  const pl = lab?.priceList;
  const currency: CurrencyCode = pl?.currency || 'EGP';
  const units = Math.max(1, toothCount);

  if (pl) {
    let unitPrice = pl.zirconiaCrown ?? 1800;
    if (restorationType === 'Veneer') unitPrice = pl.emaxVeneer ?? 2400;
    else if (restorationType === 'Implant Abutment') unitPrice = pl.implantAbutment ?? 3500;
    else if (restorationType === 'Clear Aligner') unitPrice = pl.clearAligner ?? 6500;
    else if (restorationType === 'Denture') unitPrice = pl.denture ?? 4500;
    else if (restorationType === 'Bridge') unitPrice = (pl.zirconiaCrown ?? 1800) * 1.1;

    const rush = priority === 'Rush' ? (pl.rushFee ?? 400) : 0;
    return {
      amount: Math.min(VALIDATION.MAX_FEE, Math.round(unitPrice * units + rush)),
      currency,
    };
  }

  const fallbackUnit =
    restorationType === 'Implant Abutment'
      ? 3500
      : restorationType === 'Bridge'
        ? 2200
        : restorationType === 'Clear Aligner'
          ? 6500
          : 1800;
  return {
    amount: Math.min(VALIDATION.MAX_FEE, fallbackUnit * units + (priority === 'Rush' ? 400 : 0)),
    currency,
  };
}

export const LAB_IMAGES: Record<LabImageKey, { src: string; alt: string }> = {
  studio: {
    src: '/src/assets/images/hero_dental_lab_1795303189695.jpg',
    alt: 'Master dental ceramicist inspecting zirconia crowns next to digital intraoral scan monitor',
  },
  ceramics: {
    src: '/src/assets/images/lab_ceramics_studio_1795303190430.jpg',
    alt: 'Hand-layered porcelain veneers and zirconia crowns next to a Vita classical shade guide',
  },
  cad: {
    src: '/src/assets/images/lab_digital_cad_1795303190647.jpg',
    alt: '5-axis dental CAD/CAM milling unit machining a zirconia dental arch',
  },
  implants: {
    src: '/src/assets/images/lab_implant_prosthetics_1795303189975.jpg',
    alt: 'Custom titanium dental implant abutments and multi-unit prosthetic bar on resin model',
  },
};

export function sanitizeIdSegment(raw: string): string {
  return raw.replace(/[^a-zA-Z0-9_-]/g, '-').slice(0, 64);
}
