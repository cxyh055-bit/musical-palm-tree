import { useEffect, useState } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut, type User } from 'firebase/auth';
import { doc, onSnapshot } from 'firebase/firestore';
import { BrandLogo } from './components/BrandLogo';
import { ErrorBoundary } from './components/ErrorBoundary';
import { LandingView } from './components/LandingView';
import { OnboardingView } from './components/OnboardingView';
import { Workspace } from './components/Workspace';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from './firebase';
import { LanguageContext, type Lang } from './i18n';
import type { UserProfile } from './types';

function LabiRoot() {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [profileLoading, setProfileLoading] = useState(false);
  const [signingIn, setSigningIn] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  useEffect(() => {
    const unsubAuth = onAuthStateChanged(auth, (nextUser) => {
      setUser(nextUser);
      setAuthReady(true);
      if (!nextUser) {
        setProfile(null);
        setProfileLoading(false);
      }
    });
    return () => unsubAuth();
  }, []);

  useEffect(() => {
    if (!user) return;
    setProfileLoading(true);
    const userPath = `users/${user.uid}`;
    const unsubProfile = onSnapshot(
      doc(db, 'users', user.uid),
      (snap) => {
        setProfile(snap.exists() ? (snap.data() as UserProfile) : null);
        setProfileLoading(false);
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, userPath);
      }
    );
    return () => unsubProfile();
  }, [user]);

  const handleSignIn = async () => {
    setSigningIn(true);
    setAuthError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to sign in with Google.';
      if (!msg.includes('popup-closed-by-user')) {
        setAuthError(msg);
      }
    } finally {
      setSigningIn(false);
    }
  };

  const handleSignOut = async () => {
    await signOut(auth);
  };

  if (!authReady || (user && profileLoading)) {
    return (
      <div className="min-h-screen liquid-backdrop flex items-center justify-center p-6">
        <div className="glass-panel rounded-2xl px-8 py-7 text-center space-y-3">
          <BrandLogo size="lg" />
          <div className="text-xs font-medium text-[#002B6B]/75">
            جاري تحميل مساحة العمل الطبية...
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <LandingView onSignIn={handleSignIn} signingIn={signingIn} authError={authError} />
    );
  }

  if (!profile) {
    return (
      <OnboardingView
        user={user}
        onComplete={() => {
          // Real-time snapshot updates profile automatically
        }}
        onSignOut={handleSignOut}
      />
    );
  }

  return <Workspace user={user} profile={profile} onSignOut={handleSignOut} />;
}

export default function App() {
  const [lang, setLang] = useState<Lang>('ar');

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  return (
    <ErrorBoundary>
      <LanguageContext.Provider value={{ lang, setLang }}>
        <LabiRoot />
      </LanguageContext.Provider>
    </ErrorBoundary>
  );
}
