import { useEffect, useState } from 'react';
import { onAuthStateChanged, signOut, type User } from 'firebase/auth';
import { doc, onSnapshot } from 'firebase/firestore';
import { BrandLogo } from './components/BrandLogo';
import { ErrorBoundary } from './components/ErrorBoundary';
import { LandingView } from './components/LandingView';
import { OnboardingView } from './components/OnboardingView';
import { Workspace } from './components/Workspace';
import { auth, db, handleFirestoreError, OperationType } from './firebase';
import { EmailAuthView } from './components/EmailAuthView';
import { VerifyEmailView } from './components/VerifyEmailView';
import { LanguageContext, type Lang } from './i18n';
import type { UserProfile } from './types';

function LabiRoot() {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [profileLoading, setProfileLoading] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup' | null>(null);
  const [, setTick] = useState(0);

  useEffect(() => {
    const unsubAuth = onAuthStateChanged(auth, (nextUser) => {
      setUser(nextUser);
      setAuthReady(true);
      if (!nextUser) {
        setProfile(null);
        setProfileLoading(false);
      }
    });
    return () => unsubAuth();
  }, []);

  useEffect(() => {
    if (!user) return;
    setProfileLoading(true);
    const userPath = `users/${user.uid}`;
    const unsubProfile = onSnapshot(
      doc(db, 'users', user.uid),
      (snap) => {
        setProfile(snap.exists() ? (snap.data() as UserProfile) : null);
        setProfileLoading(false);
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, userPath);
      }
    );
    return () => unsubProfile();
  }, [user]);

  const handleSignOut = async () => {
    await signOut(auth);
  };

  if (!authReady || (user && user.emailVerified && profileLoading)) {
    return (
      <div className="min-h-screen liquid-backdrop flex items-center justify-center p-6">
        <div className="glass-panel rounded-2xl px-8 py-7 text-center space-y-3">
          <BrandLogo size="lg" />
          <div className="text-xs font-medium text-[#002B6B]/75">
            جاري تحميل مساحة العمل الطبية...
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    if (authMode) return <EmailAuthView initialMode={authMode} onBack={() => setAuthMode(null)} />;
    return (
      <LandingView onSignIn={() => setAuthMode('login')} onSignUp={() => setAuthMode('signup')} />
    );
  }

  if (!user.emailVerified) {
    return (
      <VerifyEmailView user={user} onChecked={() => setTick((n) => n + 1)} onSignOut={handleSignOut} />
    );
  }

  if (!profile) {
    return (
      <OnboardingView
        user={user}
        onComplete={() => {
          // Real-time snapshot updates profile automatically
        }}
        onSignOut={handleSignOut}
      />
    );
  }

  return <Workspace user={user} profile={profile} onSignOut={handleSignOut} />;
}

export default function App() {
  const [lang, setLang] = useState<Lang>('ar');

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  return (
    <ErrorBoundary>
      <LanguageContext.Provider value={{ lang, setLang }}>
        <LabiRoot />
      </LanguageContext.Provider>
    </ErrorBoundary>
  );
}
