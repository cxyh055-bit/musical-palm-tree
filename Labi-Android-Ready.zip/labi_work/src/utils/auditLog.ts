import { doc, serverTimestamp, setDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import type { UserRole } from '../types';
import { sha256Hex } from './crypto';

interface RecordAuditEventParams {
  caseId: string;
  doctorUid: string;
  labOwnerUid: string;
  actorUid: string;
  actorName: string;
  actorRole: UserRole;
  action: string;
  summary: string;
}

export async function recordCaseAuditEvent(params: RecordAuditEventParams): Promise<void> {
  const logId = `log-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`;
  const path = `cases/${params.caseId}/auditLogs/${logId}`;
  const digestHash = await sha256Hex(
    `${params.caseId}|${params.actorUid}|${params.action}|${params.summary}|${Date.now()}`
  );

  try {
    await setDoc(doc(db, `cases/${params.caseId}/auditLogs`, logId), {
      id: logId,
      caseId: params.caseId,
      doctorUid: params.doctorUid,
      labOwnerUid: params.labOwnerUid,
      actorUid: params.actorUid,
      actorName: params.actorName.slice(0, 80),
      actorRole: params.actorRole,
      action: params.action.slice(0, 64),
      summary: params.summary.slice(0, 300),
      digestHash,
      createdAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}
