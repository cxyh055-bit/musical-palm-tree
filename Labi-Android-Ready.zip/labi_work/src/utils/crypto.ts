function toBase64(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.length; i += 1) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function fromBase64(b64: string): Uint8Array {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

function toHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

export function generateCaseEncryptionKeyB64(): string {
  const raw = new Uint8Array(32);
  crypto.getRandomValues(raw);
  return toBase64(raw);
}

async function importAesKey(keyB64: string, usages: KeyUsage[]): Promise<CryptoKey> {
  const rawBytes = fromBase64(keyB64);
  const keyBuffer = new Uint8Array(rawBytes).buffer;
  return crypto.subtle.importKey('raw', keyBuffer, { name: 'AES-GCM', length: 256 }, false, usages);
}

export async function sha256Hex(input: string): Promise<string> {
  const data = new TextEncoder().encode(input);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return toHex(new Uint8Array(digest));
}

export interface EncryptedPayload {
  ciphertext: string;
  iv: string;
  algorithm: 'AES-GCM-256';
  contentHash: string;
}

export async function encryptCaseMessage(
  plaintext: string,
  keyB64: string,
  caseId: string
): Promise<EncryptedPayload> {
  const key = await importAesKey(keyB64, ['encrypt']);
  const ivBytes = new Uint8Array(12);
  crypto.getRandomValues(ivBytes);

  const encoder = new TextEncoder();
  const encodedText = encoder.encode(plaintext);
  const aad = encoder.encode(caseId);

  const encryptedBuffer = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: ivBytes, additionalData: aad },
    key,
    encodedText
  );

  const contentHash = await sha256Hex(`${caseId}:${plaintext}`);

  return {
    ciphertext: toBase64(new Uint8Array(encryptedBuffer)),
    iv: toBase64(ivBytes),
    algorithm: 'AES-GCM-256',
    contentHash,
  };
}

export async function decryptCaseMessage(
  ciphertext: string,
  iv: string,
  keyB64: string,
  caseId: string
): Promise<string> {
  try {
    const key = await importAesKey(keyB64, ['decrypt']);
    const cipherBytes = fromBase64(ciphertext);
    const ivBytes = fromBase64(iv);
    const aad = new TextEncoder().encode(caseId);

    const decryptedBuffer = await crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv: new Uint8Array(ivBytes),
        additionalData: aad,
      },
      key,
      new Uint8Array(cipherBytes)
    );

    return new TextDecoder().decode(decryptedBuffer);
  } catch {
    return '[Encrypted message — unable to decrypt with current case key]';
  }
}
