const ALLOWED_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

export interface ImageProcessOptions {
  maxDimension: number;
  maxDataUrlChars: number;
  initialQuality?: number;
}

export async function processImageUpload(
  file: File,
  options: ImageProcessOptions
): Promise<string> {
  if (!ALLOWED_MIME_TYPES.includes(file.type)) {
    throw new Error('Only JPEG, PNG, or WebP images are permitted.');
  }

  if (file.size > 12 * 1024 * 1024) {
    throw new Error('Image file must be smaller than 12 MB.');
  }

  const bitmap = await loadImageElement(file);
  const scale = Math.min(1, options.maxDimension / Math.max(bitmap.width, bitmap.height));
  const targetWidth = Math.max(1, Math.round(bitmap.width * scale));
  const targetHeight = Math.max(1, Math.round(bitmap.height * scale));

  const canvas = document.createElement('canvas');
  canvas.width = targetWidth;
  canvas.height = targetHeight;

  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Unable to initialize image processor.');
  }

  ctx.drawImage(bitmap, 0, 0, targetWidth, targetHeight);

  let quality = options.initialQuality ?? 0.84;
  let dataUrl = canvas.toDataURL('image/jpeg', quality);

  while (dataUrl.length > options.maxDataUrlChars && quality > 0.35) {
    quality -= 0.1;
    dataUrl = canvas.toDataURL('image/jpeg', quality);
  }

  if (dataUrl.length > options.maxDataUrlChars) {
    throw new Error('Compressed image still exceeds storage limit. Please choose a smaller image.');
  }

  return dataUrl;
}

function loadImageElement(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const objectUrl = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(objectUrl);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error('Failed to decode selected image file.'));
    };
    img.src = objectUrl;
  });
}
