import { doc, serverTimestamp, setDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { VALIDATION, type NotificationEventStatus } from '../types';

export interface StatusNotificationCopy {
  titleAr: string;
  titleEn: string;
  bodyAr: (caseCode: string, labName: string, note?: string) => string;
  bodyEn: (caseCode: string, labName: string, note?: string) => string;
}

const STATUS_NOTIFICATION_COPY: Record<NotificationEventStatus, StatusNotificationCopy> = {
  submitted: {
    titleAr: 'روشتة جديدة اتبعتت للمعمل',
    titleEn: 'New Prescription Submitted',
    bodyAr: (code, lab) => `تم إرسال الروشتة ${code} إلى ${lab}.`,
    bodyEn: (code, lab) => `Prescription ${code} has been submitted to ${lab}.`,
  },
  courier_picked_up: {
    titleAr: 'المندوب استلم الشغل',
    titleEn: 'Courier Picked Up Case',
    bodyAr: (code, lab, note) =>
      note || `المندوب استلم شغلك (${code}) من العيادة وفي طريقه إلى ${lab}.`,
    bodyEn: (code, lab, note) =>
      note || `Courier picked up case ${code} from your clinic and is heading to ${lab}.`,
  },
  courier_arrived_lab: {
    titleAr: 'المندوب وصل المعمل',
    titleEn: 'Courier Arrived at Lab',
    bodyAr: (code, lab, note) =>
      note || `المندوب وصل ${lab} دلوقتي بحالة ${code}.`,
    bodyEn: (code, lab, note) =>
      note || `Courier arrived at ${lab} with case ${code}.`,
  },
  received: {
    titleAr: 'المعمل استلم الشغل',
    titleEn: 'Lab Received Case',
    bodyAr: (code, lab, note) =>
      note || `${lab} استلم الحالة ${code} وبيراجع المقاسات والأشعة.`,
    bodyEn: (code, lab, note) =>
      note || `${lab} received case ${code} and verified your records.`,
  },
  accepted: {
    titleAr: 'المعمل استلم الشغل',
    titleEn: 'Lab Accepted Case',
    bodyAr: (code, lab, note) =>
      note || `${lab} استلم وقبل الحالة ${code}.`,
    bodyEn: (code, lab, note) =>
      note || `${lab} accepted case ${code}.`,
  },
  in_progress: {
    titleAr: 'المعمل بدأ في العمل',
    titleEn: 'Lab Started Production',
    bodyAr: (code, lab, note) =>
      note || `${lab} بدأ في العمل على الحالة ${code} حالياً.`,
    bodyEn: (code, lab, note) =>
      note || `${lab} has started fabrication on case ${code}.`,
  },
  in_design: {
    titleAr: 'المعمل بدأ في التصميم',
    titleEn: 'CAD Design Started',
    bodyAr: (code, lab, note) =>
      note || `${lab} شغال على تصميم CAD لحالة ${code}.`,
    bodyEn: (code, lab, note) =>
      note || `${lab} is designing case ${code} in CAD.`,
  },
  milling: {
    titleAr: 'الحالة في التفريز والتصنيع',
    titleEn: 'Case in Milling',
    bodyAr: (code, lab, note) =>
      note || `${lab} شغال في تصنيع وتفريز الحالة ${code}.`,
    bodyEn: (code, lab, note) =>
      note || `${lab} is milling case ${code}.`,
  },
  quality_check: {
    titleAr: 'مستني موافقة الدكتور',
    titleEn: 'Awaiting Doctor Approval',
    bodyAr: (code, lab, note) =>
      note || `${lab} خلص الفحص ومستني موافقتك على الحالة ${code}.`,
    bodyEn: (code, lab, note) =>
      note || `${lab} completed QC and is awaiting your approval for ${code}.`,
  },
  awaiting_approval: {
    titleAr: 'مستني موافقة الدكتور',
    titleEn: 'Awaiting Your Approval',
    bodyAr: (code, lab, note) =>
      note || `التصميم أو البروفة من ${lab} للحالة ${code} جاهز ومستني موافقتك.`,
    bodyEn: (code, lab, note) =>
      note || `Try-in or design from ${lab} for ${code} is awaiting your approval.`,
  },
  out_for_delivery: {
    titleAr: 'الدليفري جاي لك بالشغل',
    titleEn: 'Delivery On The Way',
    bodyAr: (code, lab, note) =>
      note || `الدليفري طلع من ${lab} وجاي لك دلوقتي بالحالة ${code}.`,
    bodyEn: (code, lab, note) =>
      note || `Delivery courier left ${lab} and is on the way with case ${code}.`,
  },
  shipped: {
    titleAr: 'الدليفري جاي لك بالشغل',
    titleEn: 'Case Shipped to Clinic',
    bodyAr: (code, lab, note) =>
      note || `${lab} شحن الحالة ${code} وفي طريقها لعيادتك.`,
    bodyEn: (code, lab, note) =>
      note || `${lab} shipped case ${code} to your clinic.`,
  },
  completed: {
    titleAr: 'الشغل وصل والعميل جاهز',
    titleEn: 'Case Delivered & Completed',
    bodyAr: (code, lab, note) =>
      note || `تم تسليم وإنهاء الحالة ${code} من ${lab} بنجاح.`,
    bodyEn: (code, lab, note) =>
      note || `Case ${code} from ${lab} has been delivered and completed.`,
  },
  delivered: {
    titleAr: 'الشغل وصل للعيادة',
    titleEn: 'Case Delivered',
    bodyAr: (code, lab, note) =>
      note || `الحالة ${code} وصلت من ${lab} بنجاح.`,
    bodyEn: (code, lab, note) =>
      note || `Case ${code} has been delivered from ${lab}.`,
  },
  revision_requested: {
    titleAr: 'مطلوب تعديل من الدكتور',
    titleEn: 'Doctor Requested Revision',
    bodyAr: (code, _lab, note) =>
      note || `الدكتور طلب تعديل على الحالة ${code} قبل التسليم النهائي.`,
    bodyEn: (code, _lab, note) =>
      note || `Doctor requested a revision on case ${code}.`,
  },
  invoice_sent: {
    titleAr: 'فاتورة رقمية جديدة من المعمل',
    titleEn: 'New Digital Invoice Received',
    bodyAr: (code, lab, note) =>
      note || `أصدر ${lab} فاتورة رقمية جديدة للحالة المكتملة ${code}.`,
    bodyEn: (code, lab, note) =>
      note || `${lab} sent a digital invoice for completed case ${code}.`,
  },
  invoice_paid: {
    titleAr: 'تم سداد الفاتورة',
    titleEn: 'Invoice Marked Paid',
    bodyAr: (code, _lab, note) =>
      note || `تم تأكيد سداد فاتورة الحالة ${code} بنجاح.`,
    bodyEn: (code, _lab, note) =>
      note || `Payment was confirmed for case ${code} invoice.`,
  },
};

export async function sendCaseStatusNotification(params: {
  recipientUid: string;
  senderUid: string;
  caseId: string;
  caseCode: string;
  labName: string;
  clinicName: string;
  newStatus: NotificationEventStatus;
  customNote?: string;
}): Promise<void> {
  const copy = STATUS_NOTIFICATION_COPY[params.newStatus];
  const notifId = `notif-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const cleanNote = params.customNote?.trim();

  const titleAr = copy.titleAr.slice(0, VALIDATION.NOTIFICATION_TITLE_MAX);
  const titleEn = copy.titleEn.slice(0, VALIDATION.NOTIFICATION_TITLE_MAX);
  const bodyAr = copy
    .bodyAr(params.caseCode, params.labName, cleanNote)
    .slice(0, VALIDATION.NOTIFICATION_BODY_MAX);
  const bodyEn = copy
    .bodyEn(params.caseCode, params.labName, cleanNote)
    .slice(0, VALIDATION.NOTIFICATION_BODY_MAX);

  await setDoc(doc(db, 'notifications', notifId), {
    id: notifId,
    recipientUid: params.recipientUid,
    senderUid: params.senderUid,
    caseId: params.caseId,
    caseCode: params.caseCode,
    labName: params.labName.slice(0, VALIDATION.ORG_NAME_MAX),
    clinicName: params.clinicName.slice(0, VALIDATION.ORG_NAME_MAX),
    newStatus: params.newStatus,
    titleAr,
    titleEn,
    bodyAr,
    bodyEn,
    read: false,
    createdAt: serverTimestamp(),
  });
}
