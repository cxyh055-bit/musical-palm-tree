export interface AreaPreset {
  id: string;
  city: string;
  areaAr: string;
  areaEn: string;
  lat: number;
  lng: number;
}

export const AREA_PRESETS: AreaPreset[] = [
  { id: 'maadi', city: 'القاهرة', areaAr: 'المعادي، القاهرة', areaEn: 'Maadi, Cairo', lat: 29.9602, lng: 31.2569 },
  { id: 'nasr-city', city: 'القاهرة', areaAr: 'مدينة نصر، القاهرة', areaEn: 'Nasr City, Cairo', lat: 30.0511, lng: 31.3656 },
  { id: 'heliopolis', city: 'القاهرة', areaAr: 'مصر الجديدة، القاهرة', areaEn: 'Heliopolis, Cairo', lat: 30.0899, lng: 31.3282 },
  { id: 'new-cairo', city: 'القاهرة', areaAr: 'التجمع الخامس، القاهرة الجديدة', areaEn: 'Fifth Settlement, New Cairo', lat: 30.0074, lng: 31.4913 },
  { id: 'mohandessin', city: 'الجيزة', areaAr: 'المهندسين، الجيزة', areaEn: 'Mohandessin, Giza', lat: 30.0609, lng: 31.2001 },
  { id: 'dokki', city: 'الجيزة', areaAr: 'الدقي، الجيزة', areaEn: 'Dokki, Giza', lat: 30.0394, lng: 31.2025 },
  { id: 'zamalek', city: 'القاهرة', areaAr: 'الزمالك، القاهرة', areaEn: 'Zamalek, Cairo', lat: 30.0609, lng: 31.2197 },
  { id: 'sheikh-zayed', city: 'الجيزة', areaAr: 'الشيخ زايد، الجيزة', areaEn: 'Sheikh Zayed, Giza', lat: 30.0226, lng: 30.9854 },
  { id: 'smouha', city: 'الإسكندرية', areaAr: 'سموحة، الإسكندرية', areaEn: 'Smouha, Alexandria', lat: 31.2156, lng: 29.9553 },
  { id: 'mansoura', city: 'الدقهلية', areaAr: 'المنصورة، الدقهلية', areaEn: 'Mansoura, Dakahlia', lat: 31.0409, lng: 31.3785 },
];

export function calculateDistanceKm(
  lat1?: number,
  lng1?: number,
  lat2?: number,
  lng2?: number
): number | null {
  if (
    typeof lat1 !== 'number' ||
    typeof lng1 !== 'number' ||
    typeof lat2 !== 'number' ||
    typeof lng2 !== 'number' ||
    Number.isNaN(lat1) ||
    Number.isNaN(lng1) ||
    Number.isNaN(lat2) ||
    Number.isNaN(lng2)
  ) {
    return null;
  }

  const R = 6371;
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

export type ProximityBucket = 'nearest' | 'nearby' | 'regional' | 'unknown';

export function getProximityBucket(distanceKm: number | null): ProximityBucket {
  if (distanceKm === null) return 'unknown';
  if (distanceKm <= 6) return 'nearest';
  if (distanceKm <= 18) return 'nearby';
  return 'regional';
}

export function detectBrowserLocation(): Promise<{ lat: number; lng: number }> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported in this browser.'));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        resolve({
          lat: Math.round(pos.coords.latitude * 10000) / 10000,
          lng: Math.round(pos.coords.longitude * 10000) / 10000,
        });
      },
      (err) => {
        reject(new Error(err.message || 'Unable to detect GPS location.'));
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  });
}
