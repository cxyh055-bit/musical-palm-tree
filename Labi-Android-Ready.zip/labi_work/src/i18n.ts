import { createContext, useContext } from 'react';
import type { CaseStatus } from './types';

export type Lang = 'ar' | 'en';

export const LanguageContext = createContext<{
  lang: Lang;
  setLang: (l: Lang) => void;
}>({
  lang: 'ar',
  setLang: () => {},
});

export function useLang() {
  return useContext(LanguageContext);
}

export const STATUS_LABELS_BI: Record<Lang, Record<CaseStatus, string>> = {
  ar: {
    submitted: 'اتبعتت الروشتة',
    courier_picked_up: 'المندوب استلم من العيادة',
    courier_arrived_lab: 'المندوب وصل المعمل',
    received: 'المعمل استلم الشغل',
    accepted: 'المعمل استلم الشغل',
    in_progress: 'المعمل شغال فيه',
    in_design: 'المعمل شغال فيه',
    milling: 'المعمل شغال فيه',
    quality_check: 'مستني موافقة الدكتور',
    awaiting_approval: 'مستني موافقة الدكتور',
    out_for_delivery: 'الدليفري جاي لك بالشغل',
    shipped: 'الدليفري جاي لك بالشغل',
    completed: 'وصل والعميل جاي لك / خلص',
    delivered: 'وصل والعميل جاي لك / خلص',
    revision_requested: 'مطلوب تعديل',
  },
  en: {
    submitted: 'Submitted',
    courier_picked_up: 'Courier Picked Up',
    courier_arrived_lab: 'Courier Arrived at Lab',
    received: 'Lab Received',
    accepted: 'Lab Received',
    in_progress: 'In Progress',
    in_design: 'In Progress',
    milling: 'In Progress',
    quality_check: 'Awaiting Approval',
    awaiting_approval: 'Awaiting Approval',
    out_for_delivery: 'Delivery On The Way',
    shipped: 'Delivery On The Way',
    completed: 'Delivered & Completed',
    delivered: 'Delivered & Completed',
    revision_requested: 'Revision Requested',
  },
};

export const RESTORATION_LABELS_AR: Record<string, string> = {
  Crown: 'طربوش (Crown)',
  Bridge: 'كوبري (Bridge)',
  Veneer: 'عدسات / فينير (Veneer)',
  'Implant Abutment': 'دعامة زراعة (Implant)',
  'Clear Aligner': 'تقويم شفاف (Aligner)',
  Denture: 'طقم أسنان (Denture)',
  Nightguard: 'حارس ليلي (Nightguard)',
};

export const MATERIAL_LABELS_AR: Record<string, string> = {
  'Monolithic Zirconia': 'زيركون كامل (Zirconia)',
  'Layered E.max': 'إيماكس (Layered E.max)',
  PFM: 'بورسلين على معدن (PFM)',
  'Titanium Custom': 'تيتانيوم كاستم (Titanium)',
  'PMMA Provisional': 'مؤقت (PMMA)',
  '3D Printed Resin': 'ريزن 3D',
  'Thermoformed PETG': 'شفاف حراري (PETG)',
};

export const PROXIMITY_LABELS: Record<
  Lang,
  { nearest: string; nearby: string; regional: string; unknown: string }
> = {
  ar: {
    nearest: 'الأقرب لعيادتك (أقل من 6 كم)',
    nearby: 'قريب في نفس النطاق (6 – 18 كم)',
    regional: 'معامل في مناطق تانية (أكتر من 18 كم)',
    unknown: 'معامل بدون إحداثيات لوكيشن',
  },
  en: {
    nearest: 'Nearest to Your Clinic (≤ 6 km)',
    nearby: 'Nearby District (6 – 18 km)',
    regional: 'Wider Metro & Regional (> 18 km)',
    unknown: 'Location Coordinates Not Set',
  },
};
