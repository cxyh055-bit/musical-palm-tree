# Labi — Dental Doctor & Lab Network

React + Vite application prepared for Android packaging with Capacitor.

## Web development

- `npm install`
- `npm run dev`
- `npm run build`

## Android packaging

This repository includes `capacitor.config.ts` and a GitHub Actions workflow at `.github/workflows/build-apk.yml`.
The workflow builds a debug APK and uploads it as the `Labi-debug-APK` artifact. See `ANDROID-APK-GUIDE-AR.md` for phone-only instructions.

Important: Firebase Google sign-in currently uses `signInWithPopup`; validate or adapt this flow for native Android before production use.
