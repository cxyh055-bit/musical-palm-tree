# تجهيز Labi لإنتاج APK من الموبايل

تم تجهيز المشروع ليُغلّف كتطبيق Android باستخدام Capacitor، مع Workflow يبني APK تلقائياً على GitHub Actions.

## خطوات استخراج APK من الهاتف فقط

1. فك ضغط ملف ZIP على الهاتف.
2. افتح GitHub من المتصفح وأنشئ Repository جديداً باسم `labi-app`.
3. ارفع **محتويات** المجلد إلى المستودع (وليس مجلد ZIP نفسه). تأكد أن `package.json` و`capacitor.config.ts` و`src/` و`.github/workflows/build-apk.yml` في جذر المستودع.
4. افتح تبويب **Actions** في المستودع.
5. اختر **Build Labi Android APK** ثم **Run workflow**. إذا لم يظهر الخيار، تأكد أن ملف workflow موجود في `.github/workflows/` على الفرع الافتراضي.
6. انتظر انتهاء البناء بنجاح، ثم افتح نتيجة التشغيل (workflow run) ونزّل Artifact باسم `Labi-debug-APK`.
7. فك ضغط الـ Artifact على الهاتف، ثم افتح `app-debug.apk` وثبّته. قد يطلب Android السماح بالتثبيت من هذا المصدر.

## ملاحظات مهمة قبل الاستخدام الفعلي

- الناتج من هذا المسار هو **Debug APK** للتجربة والتثبيت المباشر، وليس نسخة Release موقّعة للنشر على Google Play.
- التطبيق يعتمد على Firebase. ملف `firebase-applet-config.json` موجود ضمن المشروع كما كان في المصدر.
- تسجيل الدخول الحالي يستخدم `signInWithPopup` من Firebase Authentication. هذا الأسلوب قد لا يعمل داخل Android WebView/Capacitor كما يعمل في المتصفح؛ يلزم اختبار تسجيل الدخول على جهاز فعلي، وقد يتطلب إعداد Google Sign-In أصلياً وربط SHA-1/SHA-256 في Firebase/Google Cloud قبل الاعتماد عليه.
- لا تضع مفاتيح خدمة خاصة أو Service Account داخل تطبيق الهاتف أو مستودع عام.
- راجع قواعد Firestore ومصادقة المستخدمين قبل إدخال بيانات مرضى حقيقية.
