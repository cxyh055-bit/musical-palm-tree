# Labi Security Specification (Payload-First TDD)

## 1. Data Invariants
1. **Identity Isolation (PII)**: `/users/{userId}` contains `email` and `phone` PII and may only be read or written by `request.auth.uid == userId` (with `email_verified == true` for writes) or a verified admin.
2. **Public Lab Integrity**: `/labs/{labId}` contains only non-PII business metadata and can only be created or updated by an authenticated, email-verified user whose `request.auth.uid == incoming().ownerUid`.
3. **Referential Case Consistency**: A `/cases/{caseId}` document cannot exist without a valid existing `/labs/{labId}` document whose `ownerUid` matches `incoming().labOwnerUid`.
4. **Doctor-Lab Authorization Partition**: Only `doctorUid` or `labOwnerUid` (or verified admin) can read or list a case.
5. **Action-Based Tiered Transitions**:
   - Doctors may only create cases with `status == 'submitted'`, edit clinical details while `'submitted'` or `'revision_requested'`, or confirm `'delivered'` / request `'revision_requested'` once `'shipped'`.
   - Labs may only advance fabrication stages (`'accepted'`, `'in_design'`, `'milling'`, `'quality_check'`, `'shipped'`) and update `trackingCode` / `estimatedFee`.
   - Once `status == 'delivered'`, the case is terminally locked against non-admin mutations.
6. **Master Gate Message Isolation**: Messages under `/cases/{caseId}/messages/{messageId}` must match the parent case's `doctorUid` and `labOwnerUid` and can only be posted by one of those two verified participants.
7. **Strict Temporal & Schema Boundaries**: All `createdAt`/`updatedAt` timestamps must equal `request.time`; all IDs match `^[a-zA-Z0-9_\-]+$` ($\le 128$ chars); shadow fields are rejected via `hasOnly()`.

## 2. The "Dirty Dozen" Adversarial Payloads
1. **PII Cross-Read Attack**: Authenticated User B attempts `get` on `/users/userA`. Must fail with `PERMISSION_DENIED`.
2. **Shadow Field Injection on User**: User A creates `/users/userA` with extra field `isAdmin: true`. Must fail with `PERMISSION_DENIED`.
3. **Unverified Email Write**: User A with `email_verified: false` attempts to create `/labs/lab1`. Must fail with `PERMISSION_DENIED`.
4. **Lab Owner Spoofing**: User A creates `/labs/lab1` with `ownerUid: 'userB'`. Must fail with `PERMISSION_DENIED`.
5. **Orphaned Case Creation**: Doctor A creates `/cases/case1` referencing non-existent `labId: 'ghost-lab'`. Must fail with `PERMISSION_DENIED`.
6. **Lab Owner Spoofing on Case**: Doctor A creates `/cases/case1` referencing valid `lab1` (owned by User B) but sets `labOwnerUid: 'userC'`. Must fail with `PERMISSION_DENIED`.
7. **Pre-Accepted Case Creation**: Doctor A creates `/cases/case1` with `status: 'shipped'` instead of `'submitted'`. Must fail with `PERMISSION_DENIED`.
8. **State Shortcutting (Doctor self-shipping)**: Doctor A updates `/cases/case1` from `'submitted'` to `'shipped'`. Must fail with `PERMISSION_DENIED`.
9. **Terminal State Mutation**: Lab B attempts to update `/cases/case1` after `status == 'delivered'`. Must fail with `PERMISSION_DENIED`.
10. **Immutable Field Tampering**: Lab B updates `/cases/case1` changing `doctorUid` or `createdAt`. Must fail with `PERMISSION_DENIED`.
11. **Path ID Poisoning**: User A attempts to write `/cases/bad$id..with.dots` or $> 128$ characters. Must fail with `PERMISSION_DENIED`.
12. **Subcollection Message Spoofing**: Outsider User C posts a message under `/cases/case1/messages/msg1` pretending `senderUid: 'doctorA'`. Must fail with `PERMISSION_DENIED`.
