import { useEffect, useState } from 'react';
import { collection, deleteDoc, doc, onSnapshot, query, serverTimestamp, setDoc, where } from 'firebase/firestore';
import { Box, ExternalLink, Plus, Trash2 } from 'lucide-react';
import { db } from '../firebase';
import type { DentalCase, UserProfile } from '../types';

interface Props {
  dentalCase: DentalCase;
  profile: UserProfile;
  role: 'doctor' | 'lab';
}

interface CaseFile {
  id: string;
  uploaderUid: string;
  uploaderRole: string;
  kind: string;
  fileName: string;
  url: string;
  note: string;
  createdMs: number;
}

export function CaseFilesPanel({ dentalCase, profile, role }: Props) {
  const [files, setFiles] = useState<CaseFile[]>([]);
  const [adding, setAdding] = useState(false);
  const [fileName, setFileName] = useState('');
  const [url, setUrl] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const field = dentalCase.doctorUid === profile.uid ? 'doctorUid' : 'labOwnerUid';
    const q = query(
      collection(db, 'caseFiles'),
      where('caseId', '==', dentalCase.id),
      where(field, '==', profile.uid)
    );
    return onSnapshot(
      q,
      (snap) => {
        const list = snap.docs.map((d) => {
          const x = d.data() as Record<string, unknown>;
          return {
            id: d.id,
            uploaderUid: String(x.uploaderUid ?? ''),
            uploaderRole: String(x.uploaderRole ?? ''),
            kind: String(x.kind ?? ''),
            fileName: String(x.fileName ?? ''),
            url: String(x.url ?? ''),
            note: String(x.note ?? ''),
            createdMs: (x.createdAt as { toMillis?: () => number } | undefined)?.toMillis?.() ?? Date.now(),
          } as CaseFile;
        });
        setFiles(list.sort((a, b) => a.createdMs - b.createdMs));
      },
      () => undefined
    );
  }, [dentalCase.id, dentalCase.doctorUid, profile.uid]);

  const kind = role === 'doctor' ? 'scan' : 'design';
  const kindLabel = (k: string) => (k === 'scan' ? 'سكان 3D' : k === 'design' ? 'تصميم 3D' : 'ملف');

  const save = async () => {
    const link = url.trim();
    if (!fileName.trim()) return setError('اكتب اسم الملف (مثلاً: upper-scan.stl).');
    if (!/^https:\/\/\S+$/.test(link) || link.length > 1000) return setError('الصق رابط صحيح يبدأ بـ https://');
    setBusy(true);
    setError(null);
    try {
      const id = `cf_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      await setDoc(doc(db, 'caseFiles', id), {
        id,
        caseId: dentalCase.id,
        doctorUid: dentalCase.doctorUid,
        labOwnerUid: dentalCase.labOwnerUid,
        uploaderUid: profile.uid,
        uploaderRole: role,
        kind,
        fileName: fileName.trim().slice(0, 120),
        url: link,
        note: note.trim().slice(0, 300),
        createdAt: serverTimestamp(),
      });
      setAdding(false);
      setFileName('');
      setUrl('');
      setNote('');
    } catch {
      setError('ما قدرناش نحفظ الملف. اتأكد إن القواعد اتحدثت.');
    } finally {
      setBusy(false);
    }
  };

  const input =
    'w-full rounded-2xl border border-[#CFE0EE] bg-white px-4 py-3 text-base text-[#0B1E3B] placeholder:text-[#8aa0b8] focus:outline-none focus:ring-2 focus:ring-[#00A8B5]';

  return (
    <div id="case-files" className="glass-surface rounded-xl p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-1.5 text-sm font-bold text-[#002B6B]">
            <Box className="h-4 w-4 text-[#00A8B5]" />
            ملفات 3D
          </div>
          <div className="text-[11px] text-slate-500">
            {role === 'doctor'
              ? 'ارفع ملف السكان (STL أو PLY أو OBJ) على Google Drive أو WeTransfer والصق الرابط هنا.'
              : 'ابعت تصميم الـ 3D للدكتور (STL) برابط Drive أو WeTransfer.'}
          </div>
        </div>
        <button
          type="button"
          onClick={() => {
            setError(null);
            setAdding(true);
          }}
          className="flex shrink-0 items-center gap-1 rounded-xl bg-[#002B6B] px-3 py-2 text-xs font-bold text-white"
        >
          <Plus className="h-3.5 w-3.5" />
          إضافة
        </button>
      </div>

      {files.length === 0 ? (
        <div className="text-xs text-slate-500">لسه مفيش ملفات على الطلب ده.</div>
      ) : (
        files.map((f) => (
          <div key={f.id} className="flex items-center gap-3 rounded-2xl bg-white p-3">
            <span className="rounded-lg bg-[#EEF5FA] px-2 py-1 text-[10px] font-bold text-[#007a84]">{kindLabel(f.kind)}</span>
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm font-bold text-[#002B6B]" dir="ltr">{f.fileName}</div>
              {f.note && <div className="truncate text-[11px] text-slate-500">{f.note}</div>}
            </div>
            <a
              href={f.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 rounded-xl bg-[#00A8B5] px-3 py-2 text-xs font-bold text-white"
            >
              <ExternalLink className="h-3.5 w-3.5" />
              فتح / تنزيل
            </a>
            {f.uploaderUid === profile.uid && (
              <button
                type="button"
                aria-label="مسح"
                onClick={() => deleteDoc(doc(db, 'caseFiles', f.id)).catch(() => undefined)}
                className="rounded-xl p-2 text-red-600"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            )}
          </div>
        ))
      )}

      {adding && (
        <div className="space-y-2 rounded-2xl bg-white p-3">
          <input className={input} dir="ltr" placeholder="upper-scan.stl" value={fileName} onChange={(e) => setFileName(e.target.value)} />
          <input className={input} dir="ltr" inputMode="url" placeholder="https://drive.google.com/..." value={url} onChange={(e) => setUrl(e.target.value)} />
          <input className={input} placeholder="ملاحظة (اختياري)" value={note} onChange={(e) => setNote(e.target.value)} />
          {error && <div className="rounded-xl border border-red-200 bg-red-50 p-2.5 text-xs text-red-800">{error}</div>}
          <div className="grid grid-cols-2 gap-2">
            <button type="button" onClick={() => setAdding(false)} className="rounded-2xl border border-[#CFE0EE] py-3 text-sm font-bold text-[#002B6B]">
              إلغاء
            </button>
            <button type="button" disabled={busy} onClick={save} className="rounded-2xl bg-[#002B6B] py-3 text-sm font-bold text-white disabled:opacity-60">
              {busy ? 'استنى...' : 'حفظ'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
