import { LABI_LOGO_SRC } from './BrandLogo';

export function SplashScreen({ leaving }: { leaving: boolean }) {
  return (
    <div
      className={`fixed inset-0 z-[300] flex flex-col items-center justify-center overflow-hidden bg-[linear-gradient(160deg,#002B6B_0%,#003F94_55%,#00A8B5_150%)] transition-opacity duration-500 ${
        leaving ? 'pointer-events-none opacity-0' : 'opacity-100'
      }`}
    >
      <div className="pointer-events-none absolute -top-24 -left-24 h-72 w-72 rounded-full bg-[#00A8B5]/30 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-24 -right-24 h-72 w-72 rounded-full bg-white/10 blur-3xl" />
      <div className="relative flex items-center justify-center">
        <span className="absolute h-36 w-36 rounded-full border-2 border-white/40 animate-splash-ring" />
        <span className="absolute h-36 w-36 rounded-full border-2 border-white/30 animate-splash-ring [animation-delay:.6s]" />
        <div className="relative flex h-32 w-32 items-center justify-center overflow-hidden rounded-[36px] bg-white shadow-[0_24px_60px_rgba(0,20,60,0.5)] animate-splash-logo">
          <img src={LABI_LOGO_SRC} alt="Labi" className="h-28 w-28 object-contain" />
        </div>
      </div>
      <div className="mt-10 text-center animate-splash-text">
        <div className="text-4xl font-extrabold tracking-wide text-white">لابي</div>
        <div className="mt-1.5 text-sm text-white/80">معامل أقرب.. جودة أعلى</div>
      </div>
    </div>
  );
}
