import { useEffect, useRef, useState } from 'react';
import { collection, doc, onSnapshot, query, serverTimestamp, setDoc, where } from 'firebase/firestore';
import { Mic, Send, Square, X } from 'lucide-react';
import { db } from '../firebase';
import type { DentalCase, UserProfile } from '../types';
import { decryptCaseMessage, encryptCaseMessage } from '../utils/crypto';

interface Props {
  dentalCase: DentalCase;
  profile: UserProfile;
  role: 'doctor' | 'lab';
}

interface Note {
  id: string;
  senderUid: string;
  senderRole: string;
  seconds: number;
  createdMs: number;
  audio: string;
}

const MAX_SECONDS = 60;

export function CaseVoiceNotes({ dentalCase, profile, role }: Props) {
  const [notes, setNotes] = useState<Note[]>([]);
  const [recording, setRecording] = useState(false);
  const [secs, setSecs] = useState(0);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const recRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);
  const cancelRef = useRef(false);
  const secsRef = useRef(0);

  useEffect(() => {
    const field = dentalCase.doctorUid === profile.uid ? 'doctorUid' : 'labOwnerUid';
    const q = query(
      collection(db, 'caseVoice'),
      where('caseId', '==', dentalCase.id),
      where(field, '==', profile.uid)
    );
    let alive = true;
    const unsub = onSnapshot(
      q,
      async (snap) => {
        const list = await Promise.all(
          snap.docs.map(async (d) => {
            const data = d.data() as Record<string, unknown>;
            const audio = dentalCase.encryptionKeyB64
              ? await decryptCaseMessage(
                  String(data.ciphertext ?? ''),
                  String(data.iv ?? ''),
                  dentalCase.encryptionKeyB64,
                  dentalCase.id
                )
              : '';
            return {
              id: d.id,
              senderUid: String(data.senderUid ?? ''),
              senderRole: String(data.senderRole ?? ''),
              seconds: Number(data.seconds ?? 0),
              createdMs: (data.createdAt as { toMillis?: () => number } | undefined)?.toMillis?.() ?? Date.now(),
              audio: audio.startsWith('data:audio') ? audio : '',
            } as Note;
          })
        );
        if (alive) setNotes(list.sort((a, b) => a.createdMs - b.createdMs));
      },
      () => undefined
    );
    return () => {
      alive = false;
      unsub();
    };
  }, [dentalCase.id, dentalCase.doctorUid, dentalCase.encryptionKeyB64, profile.uid]);

  useEffect(
    () => () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
      recRef.current?.stream.getTracks().forEach((t) => t.stop());
    },
    []
  );

  const send = async (blob: Blob, seconds: number) => {
    setBusy(true);
    try {
      const dataUrl: string = await new Promise((resolve, reject) => {
        const r = new FileReader();
        r.onload = () => resolve(String(r.result));
        r.onerror = () => reject(new Error('read'));
        r.readAsDataURL(blob);
      });
      if (dataUrl.length > 480000) {
        setError('التسجيل طويل. سجّل رسالة أقصر.');
        return;
      }
      const enc = await encryptCaseMessage(dataUrl, dentalCase.encryptionKeyB64, dentalCase.id);
      const id = `vn_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      await setDoc(doc(db, 'caseVoice', id), {
        id,
        caseId: dentalCase.id,
        doctorUid: dentalCase.doctorUid,
        labOwnerUid: dentalCase.labOwnerUid,
        senderUid: profile.uid,
        senderRole: role,
        seconds: Math.max(1, Math.min(90, Math.round(seconds))),
        ciphertext: enc.ciphertext,
        iv: enc.iv,
        createdAt: serverTimestamp(),
      });
    } catch {
      setError('ما قدرناش نبعت الرسالة الصوتية. اتأكد إن القواعد اتحدثت.');
    } finally {
      setBusy(false);
    }
  };

  const stopTimer = () => {
    if (timerRef.current) window.clearInterval(timerRef.current);
    timerRef.current = null;
  };

  const start = async () => {
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mime = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4'].find(
        (m) => typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported(m)
      );
      const rec = new MediaRecorder(stream, { ...(mime ? { mimeType: mime } : {}), audioBitsPerSecond: 16000 });
      chunksRef.current = [];
      cancelRef.current = false;
      rec.ondataavailable = (e) => e.data.size > 0 && chunksRef.current.push(e.data);
      rec.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        stopTimer();
        setRecording(false);
        if (cancelRef.current) return;
        const blob = new Blob(chunksRef.current, { type: rec.mimeType || 'audio/webm' });
        void send(blob, secsRef.current);
      };
      rec.start();
      recRef.current = rec;
      secsRef.current = 0;
      setSecs(0);
      setRecording(true);
      timerRef.current = window.setInterval(() => {
        secsRef.current += 1;
        setSecs(secsRef.current);
        if (secsRef.current >= MAX_SECONDS) recRef.current?.stop();
      }, 1000);
    } catch {
      setError('ما قدرناش نفتح الميكروفون. اسمح للتطبيق بالميكروفون من إعدادات الموبايل.');
    }
  };

  const stopAndSend = () => {
    cancelRef.current = false;
    recRef.current?.stop();
  };
  const cancel = () => {
    cancelRef.current = true;
    recRef.current?.stop();
  };

  const mm = (n: number) => `${Math.floor(n / 60)}:${String(n % 60).padStart(2, '0')}`;

  return (
    <div id="case-voice" className="mt-4 space-y-3 rounded-2xl bg-white/70 p-4">
      <div className="flex items-center justify-between">
        <div className="text-sm font-bold text-[#002B6B]">رسائل صوتية</div>
        {recording ? (
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1.5 text-sm font-bold text-red-600">
              <span className="h-2.5 w-2.5 animate-pulse rounded-full bg-red-600" />
              {mm(secs)}
            </span>
            <button type="button" onClick={cancel} aria-label="إلغاء" className="rounded-xl p-2 text-slate-500">
              <X className="h-4 w-4" />
            </button>
            <button type="button" onClick={stopAndSend} className="flex items-center gap-1.5 rounded-xl bg-[#002B6B] px-3 py-2 text-sm font-bold text-white">
              <Send className="h-4 w-4" />
              إرسال
            </button>
          </div>
        ) : (
          <button
            type="button"
            disabled={busy}
            onClick={start}
            className="flex items-center gap-1.5 rounded-xl bg-[#00A8B5] px-3.5 py-2 text-sm font-bold text-white disabled:opacity-60"
          >
            {busy ? <Square className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
            {busy ? 'بيتبعت...' : 'سجّل رسالة'}
          </button>
        )}
      </div>
      {error && <div className="rounded-xl border border-red-200 bg-red-50 p-2.5 text-xs text-red-800">{error}</div>}
      {notes.length === 0 ? (
        <div className="text-xs text-slate-500">لسه مفيش رسائل صوتية. اضغط "سجّل رسالة" وتكلم.</div>
      ) : (
        <div className="space-y-2">
          {notes.map((n) => {
            const mine = n.senderUid === profile.uid;
            return (
              <div key={n.id} className={`rounded-2xl p-2.5 ${mine ? 'bg-[#E4EEF7]' : 'bg-white border border-[#E1ECF5]'}`}>
                <div className="mb-1 flex justify-between text-[11px] text-slate-500">
                  <span>{mine ? 'أنا' : n.senderRole === 'lab' ? 'المعمل' : 'الدكتور'}</span>
                  <span>{mm(n.seconds)}</span>
                </div>
                {n.audio ? (
                  <audio controls preload="none" src={n.audio} className="h-9 w-full" />
                ) : (
                  <div className="text-xs text-slate-500">مش قادرين نفك تشفير الرسالة دي.</div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
