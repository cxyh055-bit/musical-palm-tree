import { cpSync, existsSync } from 'node:fs';

const src = 'android-assets/res';
const dst = 'android/app/src/main/res';
if (existsSync(src) && existsSync(dst)) {
  cpSync(src, dst, { recursive: true, force: true });
  console.log('Labi: launcher icons applied');
}
